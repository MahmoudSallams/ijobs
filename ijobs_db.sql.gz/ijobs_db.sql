-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 13, 2018 at 01:34 PM
-- Server version: 5.7.24-0ubuntu0.16.04.1
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ijobs_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `region` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `companies`
--

INSERT INTO `companies` (`id`, `name`, `region`, `country`, `city`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Company', 'Company', 'Egypt', 'cairo', NULL, '2018-01-26 13:20:20', '2018-01-26 13:20:20', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `mobile`, `email`, `job_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Test', 'Test', 'test@test.com', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `members_counts` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `image`, `members_counts`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'test group 1', NULL, NULL, 1, '2018-02-07 18:39:51', '2018-02-07 18:53:34', NULL),
(2, 'test group 2', NULL, NULL, -1, '2018-02-07 18:51:43', '2018-02-07 18:51:43', NULL),
(3, 'New Test Group', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', NULL, 1, '2018-03-03 11:11:24', '2018-03-03 11:11:24', NULL),
(4, 'new test reda', NULL, NULL, -1, NULL, NULL, NULL),
(5, 'test 2 group', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', NULL, 1, '2018-03-05 18:24:05', '2018-03-05 18:24:05', NULL),
(6, 'test 3', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', NULL, 1, '2018-03-05 18:24:33', '2018-03-05 18:24:33', NULL),
(7, 'test final', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', NULL, -1, '2018-03-05 18:35:23', '2018-03-05 18:35:23', NULL),
(8, 'it group', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, -1, '2018-03-21 15:39:15', '2018-03-21 15:39:15', NULL),
(9, 'test group 2', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-03-25 22:35:53', '2018-03-25 22:35:53', NULL),
(10, 'attia group edit11', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-03-25 22:37:42', '2018-04-04 12:18:37', NULL),
(11, 'test admin group', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-03-27 16:42:53', '2018-03-27 16:42:53', NULL),
(12, 'test2', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-03-27 16:44:11', '2018-03-27 16:44:11', NULL),
(13, 'Test Group 113', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 7, 1, '2018-03-27 18:52:37', '2018-06-22 22:51:08', NULL),
(14, 'aaaaa', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-03-27 20:21:58', '2018-03-27 20:21:58', NULL),
(15, 'ttttt', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-03-28 12:12:26', '2018-03-28 12:12:26', NULL),
(16, 'yu', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-03-30 13:26:30', '2018-03-30 13:26:30', NULL),
(17, 'SallyG', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 3, 1, '2018-03-30 17:53:58', '2018-05-05 14:29:09', NULL),
(18, 'Tezt', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, -1, '2018-03-30 17:54:22', '2018-03-30 17:54:22', NULL),
(19, 'testx2', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 0, 1, '2018-04-02 10:43:20', '2018-04-02 10:49:18', NULL),
(20, 'cuvu2', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-04-02 13:22:50', '2018-04-02 13:23:47', NULL),
(21, 'biojeddah', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-04-03 19:26:14', '2018-04-03 19:26:14', NULL),
(22, 'test admin group', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, -1, '2018-04-03 20:33:58', '2018-04-03 20:33:58', NULL),
(23, 'test admin group', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, -1, '2018-04-03 20:33:58', '2018-04-03 20:33:58', NULL),
(24, 'test admin group', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, -1, '2018-04-03 20:34:08', '2018-04-03 20:34:08', NULL),
(25, 'test admin', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, -1, '2018-04-03 20:36:33', '2018-04-03 20:36:33', NULL),
(26, 'test admin group', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-04-03 20:37:49', '2018-04-03 20:37:49', NULL),
(27, 'yxyxucuf', NULL, 1, -1, '2018-04-08 20:57:07', '2018-04-08 20:57:07', NULL),
(28, 'zss2', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-04-08 21:33:00', '2018-04-08 21:35:47', NULL),
(29, 'eee', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-04-13 16:18:47', '2018-04-14 17:21:18', NULL),
(30, 'sg', NULL, 1, 1, '2018-04-13 16:45:01', '2018-04-13 16:45:01', NULL),
(31, 'ghn', NULL, 1, 1, '2018-04-13 16:45:15', '2018-04-13 16:45:15', NULL),
(32, 'Test Group', NULL, 1, 1, '2018-04-14 21:23:33', '2018-04-14 21:23:33', NULL),
(33, 'Me Group', NULL, 1, 1, '2018-04-14 21:40:43', '2018-04-14 21:40:43', NULL),
(34, 't yuvin', NULL, 1, 1, '2018-04-23 14:39:26', '2018-04-23 14:39:26', NULL),
(35, 'Fgggh', NULL, 1, 1, '2018-04-23 18:23:54', '2018-04-23 18:23:54', NULL),
(36, 'zz', NULL, 1, 1, '2018-04-24 09:04:00', '2018-04-24 09:04:00', NULL),
(37, 'ايوينسن', NULL, 1, 1, '2018-04-24 11:29:26', '2018-04-24 11:29:26', NULL),
(38, '12', NULL, 1, 1, '2018-04-26 12:06:20', '2018-04-26 12:06:20', NULL),
(39, 'Biomedical Jobs', NULL, 1, 1, '2018-04-26 15:48:25', '2018-04-26 15:48:25', NULL),
(40, 'Cairo jobs', NULL, 1, 1, '2018-04-27 18:06:24', '2018-04-27 18:06:24', NULL),
(41, '13', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/image_1525533609700.jpg', 1, 1, '2018-05-05 15:20:14', '2018-05-05 15:20:14', NULL),
(42, 'gt', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-05-13 22:46:36', '2018-05-13 22:46:36', NULL),
(43, 'zz', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-05-16 20:57:10', '2018-05-16 20:57:10', NULL),
(44, 'jobs', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-05-16 20:57:56', '2018-05-16 20:57:56', NULL),
(45, 'Systems integration', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 2, 1, '2018-05-27 23:07:55', '2018-06-25 23:18:49', NULL),
(46, 'zyvzubain', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-05-30 23:56:25', '2018-05-30 23:56:25', NULL),
(47, 'yvyvuv', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-05-30 23:59:29', '2018-05-30 23:59:29', NULL),
(48, 'bxbdnx', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-05-31 09:02:15', '2018-05-31 09:02:15', NULL),
(49, 'grouptest', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-05-31 22:59:13', '2018-05-31 22:59:13', NULL),
(50, 'saudi group', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 4, 1, '2018-06-10 19:11:30', '2018-06-11 12:56:15', NULL),
(51, 'ghh', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/image_15296109382701529610940715.jpg', 1, 1, '2018-06-21 19:56:11', '2018-06-21 19:56:11', NULL),
(52, 'no hesham', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 2, 1, '2018-06-21 19:56:56', '2018-06-21 20:16:48', NULL),
(53, 'Yes H', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 2, 1, '2018-06-21 20:18:19', '2018-06-21 20:22:01', NULL),
(54, 'fgg', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 1, 1, '2018-06-23 12:59:03', '2018-06-23 12:59:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `group_jobs`
--

CREATE TABLE `group_jobs` (
  `id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `group_jobs`
--

INSERT INTO `group_jobs` (`id`, `group_id`, `job_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 17, 98, 1, '2018-05-01 14:00:19', NULL, NULL),
(2, 13, 99, 1, '2018-05-04 09:33:21', NULL, NULL),
(3, 13, 100, 1, '2018-05-04 09:33:24', NULL, NULL),
(4, 13, 101, 1, '2018-05-05 11:40:40', NULL, NULL),
(5, 13, 102, 1, '2018-05-05 13:26:24', NULL, NULL),
(6, 13, 103, 1, '2018-05-05 14:07:51', NULL, NULL),
(7, 13, 104, 1, '2018-05-05 14:08:42', NULL, NULL),
(8, 13, 105, 1, '2018-05-05 14:11:07', NULL, NULL),
(9, 13, 106, 1, '2018-05-05 14:13:30', NULL, NULL),
(10, 13, 107, 1, '2018-05-05 16:13:06', NULL, NULL),
(11, 13, 109, 1, '2018-05-07 14:28:35', NULL, NULL),
(12, 39, 113, 1, '2018-05-13 22:25:23', NULL, NULL),
(13, 13, 114, 1, '2018-05-16 20:57:55', NULL, NULL),
(14, 13, 115, 1, '2018-05-22 23:00:17', NULL, NULL),
(15, 17, 116, 1, '2018-05-22 23:52:15', NULL, NULL),
(16, 17, 117, 1, '2018-05-22 23:52:39', NULL, NULL),
(17, 13, 121, 1, '2018-05-23 12:57:44', NULL, NULL),
(18, 13, 125, 1, '2018-05-23 22:07:33', NULL, NULL),
(19, 13, 127, 1, '2018-05-24 06:41:12', NULL, NULL),
(20, 13, 128, 1, '2018-05-24 06:49:08', NULL, NULL),
(21, 13, 129, 1, '2018-05-24 07:00:15', NULL, NULL),
(22, 13, 130, 1, '2018-05-24 07:20:09', NULL, NULL),
(23, 13, 131, 1, '2018-05-24 07:22:37', NULL, NULL),
(24, 13, 132, 1, '2018-05-24 07:23:47', NULL, NULL),
(25, 13, 133, 1, '2018-05-24 07:24:41', NULL, NULL),
(26, 13, 134, 1, '2018-05-24 07:26:26', NULL, NULL),
(27, 13, 137, 1, '2018-05-24 10:26:52', NULL, NULL),
(28, 13, 138, 1, '2018-05-24 10:27:42', NULL, NULL),
(29, 13, 142, 1, '2018-05-25 11:46:44', NULL, NULL),
(30, 13, 143, 1, '2018-05-25 11:48:51', NULL, NULL),
(31, 13, 149, 1, '2018-05-25 15:15:30', NULL, NULL),
(32, 13, 150, 1, '2018-05-25 15:15:57', NULL, NULL),
(33, 13, 151, 1, '2018-05-25 15:20:30', NULL, NULL),
(34, 39, 158, 1, '2018-05-27 14:08:28', NULL, NULL),
(35, 39, 159, 1, '2018-05-28 01:23:07', NULL, NULL),
(36, 13, 161, 1, '2018-05-30 22:38:30', NULL, NULL),
(37, 38, 163, 1, '2018-05-30 22:44:37', NULL, NULL),
(38, 46, 168, 1, '2018-05-30 23:56:39', NULL, NULL),
(39, 47, 169, 1, '2018-05-30 23:59:32', NULL, NULL),
(40, 48, 171, 1, '2018-05-31 09:02:17', NULL, NULL),
(41, 49, 174, 1, '2018-05-31 22:59:30', NULL, NULL),
(42, 40, 175, 1, '2018-06-01 19:44:16', NULL, NULL),
(43, 13, 193, 1, '2018-06-21 19:14:13', NULL, NULL),
(44, 52, 201, 1, '2018-06-21 19:58:11', NULL, NULL),
(45, 53, 204, 1, '2018-06-21 20:18:55', NULL, NULL),
(46, 45, 208, 1, '2018-06-24 23:13:10', NULL, NULL),
(47, 50, 215, 1, '2018-06-26 19:20:29', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `group_users`
--

CREATE TABLE `group_users` (
  `id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `profile_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `group_users`
--

INSERT INTO `group_users` (`id`, `group_id`, `profile_id`, `status`, `is_admin`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 8, 19, 1, 1, '2018-03-21 15:39:15', '2018-03-21 15:39:15', NULL),
(2, 9, 19, 1, 1, '2018-03-25 22:35:53', '2018-03-25 22:35:53', NULL),
(3, 10, 18, 1, 1, '2018-03-25 22:37:42', '2018-03-25 22:37:42', NULL),
(4, 11, 19, 1, 2, '2018-03-27 16:42:53', '2018-03-27 16:42:53', NULL),
(5, 12, 19, 1, 1, '2018-03-27 16:44:11', '2018-03-27 16:44:11', NULL),
(6, 13, 26, 1, 1, '2018-03-27 18:52:37', '2018-03-27 18:52:37', NULL),
(7, 14, 18, 1, 1, '2018-03-27 20:21:58', '2018-03-27 20:21:58', NULL),
(8, 15, 19, 1, 1, '2018-03-28 12:12:26', '2018-03-28 12:12:26', NULL),
(9, 16, 18, 1, 1, '2018-03-30 13:26:30', '2018-03-30 13:26:30', NULL),
(10, 17, 28, 1, 1, '2018-03-30 17:53:58', '2018-03-30 17:53:58', NULL),
(11, 18, 28, 1, 1, '2018-03-30 17:54:22', '2018-03-30 17:54:22', NULL),
(12, 10, 19, 1, 0, '2018-03-31 19:19:23', '2018-04-06 00:00:01', NULL),
(13, 19, 32, -1, 2, '2018-04-02 10:43:20', '2018-04-02 10:43:20', NULL),
(14, 20, 32, 1, 1, '2018-04-02 13:22:50', '2018-04-02 13:22:50', NULL),
(15, 10, 24, 1, 0, '2018-04-03 09:09:01', '2018-04-06 00:00:01', NULL),
(16, 14, 24, 1, 0, '2018-04-03 17:41:09', '2018-04-06 00:00:01', NULL),
(17, 21, 6, 1, 2, '2018-04-03 19:26:14', '2018-04-03 19:26:14', NULL),
(18, 22, 24, 1, 1, '2018-04-03 20:33:58', '2018-04-03 20:33:58', NULL),
(19, 23, 24, 1, 1, '2018-04-03 20:33:58', '2018-04-03 20:33:58', NULL),
(20, 24, 24, 1, 1, '2018-04-03 20:34:08', '2018-04-03 20:34:08', NULL),
(21, 25, 24, 1, 1, '2018-04-03 20:36:33', '2018-04-03 20:36:33', NULL),
(22, 26, 24, 1, 2, '2018-04-03 20:37:49', '2018-04-03 20:37:49', NULL),
(23, 16, 24, 1, 0, '2018-04-04 21:49:58', '2018-04-06 00:00:01', NULL),
(24, 27, 29, 1, 1, '2018-04-08 20:57:07', '2018-04-08 20:57:07', NULL),
(25, 28, 29, 1, 2, '2018-04-08 21:33:00', '2018-04-08 21:33:00', NULL),
(26, 26, 18, 1, 0, '2018-04-10 21:55:45', '2018-04-12 00:00:01', NULL),
(27, 29, 29, 1, 1, '2018-04-13 16:18:47', '2018-04-13 16:18:47', NULL),
(28, 30, 56, 1, 1, '2018-04-13 16:45:01', '2018-04-13 16:45:01', NULL),
(29, 31, 56, 1, 1, '2018-04-13 16:45:15', '2018-04-13 16:45:15', NULL),
(30, 31, 29, 1, 0, '2018-04-13 21:20:10', '2018-04-15 00:00:02', NULL),
(31, 32, 59, 1, 1, '2018-04-14 21:23:33', '2018-04-14 21:23:33', NULL),
(32, 33, 65, 1, 1, '2018-04-14 21:40:43', '2018-04-14 21:40:43', NULL),
(33, 29, 59, 1, 0, '2018-04-14 21:47:48', '2018-04-16 00:00:01', NULL),
(34, 34, 56, 1, 1, '2018-04-23 14:39:26', '2018-04-23 14:39:26', NULL),
(35, 35, 73, 1, 1, '2018-04-23 18:23:54', '2018-04-23 18:23:54', NULL),
(36, 36, 29, 1, 1, '2018-04-24 09:04:00', '2018-04-24 09:04:00', NULL),
(37, 37, 29, 1, 1, '2018-04-24 11:29:26', '2018-04-24 11:29:26', NULL),
(38, 38, 26, 1, 1, '2018-04-26 12:06:20', '2018-04-26 12:06:20', NULL),
(39, 13, 1, -1, 0, '2018-04-26 15:40:57', '2018-04-26 15:40:57', NULL),
(40, 13, 2, 1, 0, '2018-04-26 15:43:15', '2018-04-26 15:43:15', NULL),
(41, 13, 3, 1, 0, '2018-04-26 15:43:15', '2018-04-26 15:43:15', NULL),
(42, 39, 77, 1, 1, '2018-04-26 15:48:25', '2018-04-26 15:48:25', NULL),
(43, 40, 77, 1, 1, '2018-04-27 18:06:24', '2018-04-27 18:06:24', NULL),
(44, 13, 29, 1, 2, '2018-04-29 20:13:30', '2018-04-29 20:13:30', NULL),
(45, 13, 59, 1, 0, '2018-04-29 20:13:30', '2018-04-29 20:13:30', NULL),
(46, 13, 17, 1, 0, '2018-05-01 14:01:43', '2018-05-01 14:01:43', NULL),
(47, 17, 6, 1, 0, '2018-05-05 14:28:58', '2018-05-05 14:28:58', NULL),
(48, 17, 5, 1, 0, '2018-05-05 14:29:09', '2018-05-05 14:29:09', NULL),
(49, 13, 6, 1, 0, '2018-05-05 14:30:00', '2018-05-05 14:30:00', NULL),
(50, 13, 5, 1, 0, '2018-05-05 14:30:00', '2018-05-05 14:30:00', NULL),
(51, 13, 65, -1, 0, '2018-05-05 14:31:21', '2018-05-05 14:31:21', NULL),
(52, 41, 26, 1, 1, '2018-05-05 15:20:14', '2018-05-05 15:20:14', NULL),
(53, 32, 86, 1, 0, '2018-05-07 14:29:35', '2018-05-09 00:00:02', NULL),
(54, 41, 86, 1, 0, '2018-05-07 14:33:04', '2018-05-09 00:00:02', NULL),
(55, 42, 77, 1, 1, '2018-05-13 22:46:36', '2018-05-13 22:46:36', NULL),
(56, 43, 86, 1, 1, '2018-05-16 20:57:10', '2018-05-16 20:57:10', NULL),
(57, 44, 77, 1, 1, '2018-05-16 20:57:56', '2018-05-16 20:57:56', NULL),
(58, 45, 12, 1, 1, '2018-05-27 23:07:55', '2018-05-27 23:07:55', NULL),
(59, 46, 103, 1, 1, '2018-05-30 23:56:25', '2018-05-30 23:56:25', NULL),
(60, 47, 104, 1, 1, '2018-05-30 23:59:29', '2018-05-30 23:59:29', NULL),
(61, 48, 107, 1, 1, '2018-05-31 09:02:15', '2018-05-31 09:02:15', NULL),
(62, 49, 110, 1, 1, '2018-05-31 22:59:13', '2018-05-31 22:59:13', NULL),
(63, 50, 111, 1, 1, '2018-06-10 19:11:30', '2018-06-10 19:11:30', NULL),
(64, 50, 6, 1, 0, '2018-06-10 19:16:04', '2018-06-10 19:16:04', NULL),
(65, 50, 12, 1, 0, '2018-06-11 01:52:54', '2018-06-11 01:52:54', NULL),
(66, 50, 29, 1, 0, '2018-06-11 12:56:15', '2018-06-11 12:56:15', NULL),
(67, 13, 111, 1, 0, '2018-06-13 15:26:50', '2018-06-15 00:00:01', NULL),
(68, 51, 29, 1, 1, '2018-06-21 19:56:11', '2018-06-21 19:56:11', NULL),
(69, 52, 29, 1, 1, '2018-06-21 19:56:56', '2018-06-21 19:56:56', NULL),
(70, 52, 7, 1, 0, '2018-06-21 20:00:31', '2018-06-21 20:16:48', NULL),
(71, 53, 7, 1, 1, '2018-06-21 20:18:19', '2018-06-21 20:18:19', NULL),
(72, 53, 29, 1, 0, '2018-06-21 20:22:01', '2018-06-21 20:22:01', NULL),
(73, 26, 115, 1, 0, '2018-06-22 03:15:41', '2018-06-24 00:00:01', NULL),
(74, 54, 29, 1, 1, '2018-06-23 12:59:03', '2018-06-23 12:59:03', NULL),
(75, 50, 116, 1, 0, '2018-06-23 18:29:22', '2018-06-25 00:00:02', NULL),
(76, 10, 116, 1, 0, '2018-06-23 18:29:31', '2018-06-25 00:00:02', NULL),
(77, 45, 6, 1, 0, '2018-06-25 23:18:49', '2018-06-25 23:18:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_url` text COLLATE utf8mb4_unicode_ci,
  `applied_count` int(11) DEFAULT '0',
  `forwarded_count` int(11) DEFAULT '0',
  `shared_count` int(11) DEFAULT '0',
  `profile_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `description`, `image`, `file_url`, `applied_count`, `forwarded_count`, `shared_count`, `profile_id`, `group_id`, `parent_id`, `contact_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'dsad4', 'das', NULL, NULL, 4, 5, 0, 1, 0, 0, 1, 1, NULL, '2018-04-24 10:40:39', NULL),
(2, 'wqe', 'eqw', '', NULL, 1, 0, 0, 1, 0, 0, NULL, 1, NULL, '2018-04-22 20:49:01', NULL),
(3, 'eqw', 'ewqewqewq', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-04-22 21:17:01', NULL),
(4, '321321', '312321321321', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-04-22 21:21:32', NULL),
(5, 'title', 'description', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2018-02-07 18:46:52', '2018-04-22 21:21:44', NULL),
(6, 'test', 'test add job', 'http://', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2018-03-10 12:12:35', '2018-03-10 12:12:35', NULL),
(7, 'title', 'test without image url', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2018-03-10 12:16:52', '2018-03-10 12:16:52', NULL),
(8, 'title', 'add new job with long description for testing new API with changes in job item when adding only description without image \ncompatitive salaries Harry up', NULL, NULL, 4, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2018-03-10 19:56:19', '2018-03-30 17:57:25', NULL),
(9, '', 'description 6', NULL, NULL, NULL, NULL, NULL, 11, NULL, NULL, NULL, -1, '2018-03-12 23:00:49', '2018-03-12 23:03:06', NULL),
(10, '', 'description 6', NULL, NULL, 1, NULL, NULL, 11, NULL, NULL, NULL, 1, '2018-03-12 23:25:52', '2018-04-22 21:23:35', NULL),
(11, 'title', 'test', NULL, NULL, NULL, NULL, NULL, 16, NULL, NULL, NULL, 1, '2018-03-17 18:14:23', '2018-03-17 18:14:23', NULL),
(12, 'title', 'test job', NULL, NULL, NULL, NULL, NULL, 16, NULL, NULL, NULL, 1, '2018-03-17 18:16:30', '2018-03-17 18:16:30', NULL),
(13, 'title', 'aa', NULL, NULL, NULL, NULL, NULL, 18, NULL, NULL, NULL, 1, '2018-03-20 20:47:08', '2018-03-24 13:55:24', '2018-03-24 13:55:24'),
(14, 'title', 'test', NULL, NULL, NULL, NULL, NULL, 18, NULL, NULL, NULL, -1, '2018-03-20 20:57:43', '2018-03-25 20:59:39', NULL),
(15, 'title', 'eeee', NULL, NULL, NULL, NULL, NULL, 19, NULL, NULL, NULL, 1, '2018-03-21 15:36:15', '2018-03-21 15:36:15', NULL),
(16, 'title', 'dddd', NULL, NULL, NULL, NULL, NULL, 19, NULL, NULL, NULL, 1, '2018-03-21 15:36:21', '2018-03-21 15:36:21', NULL),
(17, 'title', 'aaas', NULL, NULL, NULL, NULL, NULL, 19, NULL, NULL, NULL, 1, '2018-03-21 15:37:30', '2018-03-21 15:37:30', NULL),
(18, 'title', 'hhjj', NULL, NULL, NULL, NULL, NULL, 19, NULL, NULL, NULL, 1, '2018-03-21 15:59:53', '2018-03-21 15:59:53', NULL),
(19, 'title', 'test add job', NULL, NULL, NULL, NULL, NULL, 19, NULL, NULL, NULL, 1, '2018-03-21 16:00:17', '2018-03-21 16:00:17', NULL),
(20, 'title', 'ggghhhjjjj', NULL, NULL, NULL, NULL, NULL, 19, NULL, NULL, NULL, 1, '2018-03-21 16:12:33', '2018-03-21 16:12:33', NULL),
(21, 'title', 'ttttttttt', NULL, NULL, NULL, NULL, NULL, 19, NULL, NULL, NULL, 1, '2018-03-21 16:13:09', '2018-03-21 16:13:09', NULL),
(22, 'title', 'test add', NULL, NULL, NULL, NULL, NULL, 18, NULL, NULL, NULL, 1, '2018-03-22 20:36:28', '2018-03-24 12:59:13', '2018-03-24 12:59:13'),
(23, 'title', 'qq', NULL, NULL, NULL, NULL, NULL, 18, NULL, NULL, NULL, 1, '2018-03-23 12:33:47', '2018-03-24 12:42:53', '2018-03-24 12:42:53'),
(24, 'title', 'test', NULL, NULL, 1, 3, 0, 18, NULL, NULL, NULL, 1, '2018-03-25 21:01:53', '2018-03-30 14:57:20', NULL),
(25, 'title', 'zx', NULL, NULL, 0, 0, 0, 18, NULL, NULL, NULL, 1, '2018-03-30 12:30:06', '2018-03-30 12:30:06', NULL),
(26, 'title', 'rrr', NULL, NULL, 1, 0, 0, 18, NULL, NULL, NULL, 1, '2018-03-30 14:42:32', '2018-03-30 19:38:20', NULL),
(27, 'title', 'Test', NULL, NULL, 4, 1, 0, 28, NULL, NULL, NULL, 1, '2018-03-30 18:00:11', '2018-04-24 10:40:52', NULL),
(28, 'title', 'Sall6', NULL, NULL, 0, 0, 0, 29, NULL, NULL, NULL, 1, '2018-03-30 19:38:06', '2018-04-24 12:43:01', '2018-04-24 12:43:01'),
(29, 'title', 'Ss', NULL, NULL, 0, 0, 0, 28, NULL, NULL, NULL, 1, '2018-03-30 20:27:11', '2018-03-30 20:27:11', NULL),
(30, 'title', 'hgdd', NULL, NULL, 0, 0, 0, 6, NULL, NULL, NULL, -1, '2018-04-02 09:36:58', '2018-04-03 19:26:38', NULL),
(31, 'title', 'eng1', NULL, NULL, 0, 0, 0, 12, NULL, NULL, NULL, -1, '2018-04-02 13:34:40', '2018-04-26 21:41:30', NULL),
(32, 'title', 'ttt', NULL, NULL, 0, 0, 0, 32, NULL, NULL, NULL, 1, '2018-04-02 13:51:39', '2018-04-02 13:51:39', NULL),
(33, 'title', 'fg', NULL, NULL, 0, 0, 0, 32, NULL, NULL, NULL, 1, '2018-04-02 13:51:46', '2018-04-02 13:51:46', NULL),
(34, 'title', 'tedssddd', NULL, NULL, 1, 0, 0, 29, NULL, NULL, NULL, 1, '2018-04-02 14:55:09', '2018-04-14 18:19:06', NULL),
(35, 'title', 'ggggg', NULL, NULL, 0, 0, 0, 6, NULL, NULL, NULL, 1, '2018-04-03 19:13:28', '2018-04-03 19:13:28', NULL),
(36, 'title', 'bbbbbbbbb\nnnjjkkkll\nbbbnm\nbbnkjkkkfg\ncghjjkk\ncghjkkdsartyuii\nxffghjkkkldfhj\ndfghjkkkll\nxvhhjkklcfhjj\ndfghjkkl', NULL, NULL, 0, 0, 0, 6, NULL, NULL, NULL, 1, '2018-04-03 19:24:15', '2018-04-03 19:24:15', NULL),
(37, 'title', 'z', NULL, NULL, 0, 0, 0, 37, NULL, NULL, NULL, -1, '2018-04-04 20:51:29', '2018-04-04 20:56:04', NULL),
(38, 'title', 'hgfxszvbb', NULL, NULL, 0, 0, 0, 6, NULL, NULL, NULL, 1, '2018-04-04 22:50:04', '2018-04-04 22:50:04', NULL),
(39, 'title', 'bgfcds', NULL, NULL, 0, 0, 0, 6, NULL, NULL, NULL, 1, '2018-04-04 22:50:18', '2018-04-04 22:50:18', NULL),
(40, 'title', 'ffdxcc\nvffds\ncxzgds\nfdsaahgf\ncdsahhgf', NULL, NULL, 1, 0, 0, 6, NULL, NULL, NULL, 1, '2018-04-04 22:50:49', '2018-04-13 14:42:12', NULL),
(41, 'title', 'aa', NULL, NULL, 0, 1, 0, 18, NULL, NULL, NULL, 1, '2018-04-07 09:30:53', '2018-04-13 23:09:05', NULL),
(42, 'title', 'dff', NULL, NULL, 1, 0, 0, 18, NULL, NULL, NULL, 1, '2018-04-07 09:34:36', '2018-04-08 21:04:15', NULL),
(43, 'title', 'aa', NULL, NULL, 0, 0, 0, 18, NULL, NULL, NULL, 1, '2018-04-07 09:34:53', '2018-04-07 09:34:53', NULL),
(44, 'title', 'duyxuc', NULL, NULL, 1, 0, 0, 29, NULL, NULL, NULL, -1, '2018-04-08 20:57:17', '2018-04-13 15:49:40', NULL),
(45, 'title', 'New test j8b', NULL, NULL, 2, 1, 0, 29, NULL, NULL, NULL, -1, '2018-04-08 20:58:19', '2018-04-13 15:46:36', NULL),
(46, 'title', 'jewkjewjkewjk hjewjewjejkwkewkkl ewhjjhewjewj', NULL, NULL, 0, 0, 0, 58, NULL, NULL, NULL, 1, '2018-04-13 12:59:26', '2018-04-13 12:59:26', NULL),
(47, 'title', 'kj', NULL, NULL, 0, 0, 0, 58, NULL, NULL, NULL, 1, '2018-04-13 13:02:30', '2018-04-13 13:02:30', NULL),
(48, 'title', 'kj', NULL, NULL, 0, 0, 0, 58, NULL, NULL, NULL, 1, '2018-04-13 13:02:34', '2018-04-13 13:02:34', NULL),
(49, 'title', 'kzlxp', NULL, NULL, 0, 0, 0, 58, NULL, NULL, NULL, 1, '2018-04-13 13:04:44', '2018-04-13 13:04:44', NULL),
(50, 'title', 'jcjc', NULL, NULL, 1, 0, 0, 58, NULL, NULL, NULL, 1, '2018-04-13 13:05:00', '2018-04-13 15:06:06', NULL),
(51, 'title', 'gg', NULL, NULL, 0, 2, 0, 58, NULL, NULL, NULL, 1, '2018-04-13 13:10:00', '2018-04-13 15:38:25', NULL),
(52, 'title', 'bhg', NULL, NULL, 0, 0, 0, 56, NULL, NULL, NULL, 1, '2018-04-13 15:15:56', '2018-04-13 15:16:24', '2018-04-13 15:16:24'),
(53, 'title', 'tttt', NULL, NULL, 0, 0, 0, 56, NULL, NULL, NULL, -1, '2018-04-13 15:17:16', '2018-04-13 15:17:58', NULL),
(54, 'title', 'xx', NULL, NULL, 0, 1, 0, 56, NULL, NULL, NULL, 1, '2018-04-13 15:18:30', '2018-04-23 14:34:50', '2018-04-23 14:34:50'),
(55, 'title', 'ff', NULL, NULL, 2, 0, 0, 29, NULL, NULL, NULL, 1, '2018-04-13 16:04:02', '2018-04-15 10:54:42', NULL),
(56, 'title', 'Ffg', NULL, NULL, 0, 1, 0, 59, NULL, NULL, NULL, 1, '2018-04-14 08:39:31', '2018-04-14 20:39:31', NULL),
(57, 'title', 'Qq', NULL, NULL, 0, 0, 0, 59, NULL, NULL, NULL, 1, '2018-04-14 20:31:52', '2018-04-14 20:31:52', NULL),
(58, 'title', 'vhfddgvb\nhhbfdgh\nvbjmmmi\nvbhjklhfdd\ncfghkll\ncfhjkjvfss\ndfgjkdfhjk\ncgjklcgjkk', NULL, NULL, 1, 0, 0, 6, NULL, NULL, NULL, 1, '2018-04-16 15:41:43', '2018-04-24 11:56:27', NULL),
(59, 'title', 'vcxxcvnmx\ncchjkcdghj\ncvjsdghjk\ncgbjkcxx', NULL, NULL, 0, 0, 0, 6, NULL, NULL, NULL, 1, '2018-04-16 15:42:12', '2018-04-16 15:42:12', NULL),
(60, 'title', 'جروب', NULL, NULL, 1, 0, 0, 26, NULL, NULL, NULL, 1, '2018-04-26 02:16:44', '2018-04-26 14:16:44', NULL),
(61, 'title', 'الل', NULL, NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-04-20 22:30:31', '2018-04-24 21:10:26', '2018-04-24 21:10:26'),
(62, 'title', 'Aaa', NULL, NULL, 2, 0, 0, 68, NULL, NULL, NULL, 1, '2018-04-22 19:51:27', '2018-04-24 21:13:56', NULL),
(63, 'title', '0 l', NULL, NULL, 0, 0, 0, 29, NULL, NULL, NULL, 1, '2018-04-22 23:29:32', '2018-04-24 12:34:07', '2018-04-24 12:34:07'),
(64, 'title', 'Aaa', NULL, NULL, 0, 0, 0, 73, NULL, NULL, NULL, 1, '2018-04-23 18:23:27', '2018-04-23 18:23:27', NULL),
(65, 'title', 'New one', NULL, NULL, 0, 0, 0, 29, NULL, NULL, NULL, 1, '2018-04-24 09:02:49', '2018-04-24 09:02:49', NULL),
(66, 'title', 'zzzzs', NULL, NULL, 0, 0, 0, 29, NULL, NULL, NULL, 1, '2018-04-24 09:03:25', '2018-04-24 10:20:51', '2018-04-24 10:20:51'),
(67, 'title', 'job in group', NULL, NULL, 1, 0, 0, 29, NULL, NULL, NULL, 1, '2018-04-24 09:04:13', '2018-04-24 21:13:51', NULL),
(68, 'title', 'Dr. Evil hatches a time-traveling scheme to take over the world, one that involves the kidnapping of Nigel Powers, Austin\'s beloved father and England\'s most renowned spy. As he chases the vi', NULL, NULL, 1, 1, 0, 29, NULL, NULL, NULL, -1, '2018-04-24 09:22:30', '2018-04-24 10:56:07', NULL),
(69, 'title', 'Dr. Evil hatches a time-traveling scheme to take over the world, one that involves the kidnapping of Nigel Powers, Austin\'s beloved father and England\'s most renowned spy. As he chases the vi', NULL, NULL, 1, 0, 0, 29, NULL, NULL, NULL, 1, '2018-04-24 09:22:41', '2018-04-24 12:36:28', '2018-04-24 12:36:28'),
(70, 'title', 'zzzz1', NULL, NULL, 3, 1, 0, 29, NULL, NULL, NULL, 1, '2018-04-24 10:41:32', '2018-06-13 22:17:57', NULL),
(71, 'title', 'zzzz2', NULL, NULL, 0, 0, 0, 29, NULL, NULL, NULL, 1, '2018-04-24 10:41:18', '2018-04-24 12:26:38', '2018-04-24 12:26:38'),
(72, 'title', 'zzzz3', NULL, NULL, 2, 3, 0, 29, NULL, NULL, NULL, 1, '2018-04-24 10:36:01', '2018-04-25 22:20:47', NULL),
(73, 'title', 'ؤؤؤؤ', NULL, NULL, 1, 0, 0, 29, NULL, NULL, NULL, -1, '2018-04-24 11:30:39', '2018-04-24 12:41:40', NULL),
(74, 'title', 'PDF test', NULL, NULL, 0, 0, 0, 29, NULL, NULL, NULL, -1, '2018-04-24 12:11:29', '2018-04-24 12:40:46', NULL),
(75, 'title', 'xbjdknsks', NULL, NULL, 1, 0, 0, 29, NULL, NULL, NULL, 1, '2018-04-24 12:39:08', '2018-04-24 12:40:25', '2018-04-24 12:40:25'),
(76, 'title', 'Aaa', NULL, NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-04-26 02:16:36', '2018-04-26 20:43:00', '2018-04-26 20:43:00'),
(77, 'title', '123', NULL, NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-04-24 21:11:27', '2018-04-24 21:11:33', '2018-04-24 21:11:33'),
(78, 'title', 'thbbb \nfcvbbm\nxcvbnnm\nxghjnhj\ncvnn', NULL, NULL, 0, 0, 0, 77, NULL, NULL, NULL, 1, '2018-04-25 22:19:14', '2018-04-25 22:19:14', NULL),
(79, 'title', 'bvcdszbnn\ndgbjm\nxchjk\nxchczzhjjk\ncvbnghhjj', NULL, NULL, 0, 0, 0, 77, NULL, NULL, NULL, 1, '2018-04-25 22:21:48', '2018-04-25 22:21:48', NULL),
(80, 'title', 'Qqqq', NULL, NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-04-26 12:03:18', '2018-04-26 14:11:37', '2018-04-26 14:11:37'),
(81, 'title', 'وظيفة', NULL, NULL, 0, 0, 0, 77, NULL, NULL, NULL, 1, '2018-04-26 15:55:14', '2018-04-26 15:55:14', NULL),
(82, 'title', 'وظيفة', NULL, NULL, 0, 0, 0, 77, NULL, NULL, NULL, -1, '2018-04-26 21:54:35', '2018-04-27 17:44:51', NULL),
(83, 'title', 'jgdzz\nbcxzz\ngczXGHJ\nGCXZCVJ\nVCXXVBN', NULL, NULL, 0, 0, 0, 77, NULL, NULL, NULL, 1, '2018-04-26 22:00:32', '2018-04-26 22:00:32', NULL),
(84, 'title', 'وظيفة', NULL, NULL, 0, 0, 0, 77, NULL, NULL, NULL, 1, '2018-04-27 17:55:17', '2018-04-27 17:55:17', NULL),
(85, 'title', 'وظيفة', NULL, NULL, 0, 0, 0, 77, NULL, NULL, NULL, 1, '2018-04-27 17:57:42', '2018-04-27 17:57:42', NULL),
(86, 'title', '11', NULL, NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-04-28 14:52:22', '2018-04-28 14:52:22', NULL),
(87, 'title', '1245', NULL, NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-04-28 14:53:01', '2018-04-28 14:53:01', NULL),
(88, 'title', 'Qsdrd', NULL, NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-04-28 14:54:15', '2018-04-28 14:54:15', NULL),
(89, 'title', 'Dfg', NULL, NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-04-28 15:19:53', '2018-04-28 15:19:53', NULL),
(90, 'title', 'Dfg', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-04-28 15:20:50', '2018-04-28 15:20:50', NULL),
(91, 'title', 'Dfg', NULL, NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-04-28 15:21:09', '2018-04-28 15:21:09', NULL),
(92, 'title', 'Dfg', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-04-28 16:08:01', '2018-04-28 16:08:01', NULL),
(93, 'title', 'Dfg', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-04-28 16:08:11', '2018-04-28 16:08:11', NULL),
(94, 'title', 'Qqq', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-04-29 23:33:46', '2018-04-29 23:33:46', NULL),
(95, 'title', 'Qqq', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-04-29 23:34:27', '2018-04-29 23:34:27', NULL),
(96, 'title', 'Qqq', NULL, NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-04-29 23:34:32', '2018-04-29 23:34:32', NULL),
(97, '', 'description 8', NULL, NULL, 0, 0, 0, 7, 17, NULL, NULL, 1, '2018-05-01 13:53:26', '2018-05-01 13:53:26', NULL),
(98, '', 'description 8', NULL, NULL, 0, 0, 0, 7, 17, NULL, NULL, 1, '2018-05-01 14:00:19', '2018-05-01 14:00:19', NULL),
(99, 'title', '11', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-04 09:33:21', '2018-05-04 09:33:21', NULL),
(100, 'title', '11', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-04 09:33:24', '2018-05-04 09:33:24', NULL),
(101, 'title', '12341', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-05 11:40:40', '2018-05-05 11:40:40', NULL),
(102, 'title', '123', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-05 13:26:24', '2018-05-05 13:26:24', NULL),
(103, 'title', '122', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-05 14:07:51', '2018-05-05 14:07:51', NULL),
(104, '', NULL, NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-05 14:08:42', '2018-05-05 14:08:42', NULL),
(105, 'title', 'Qqq', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-05 14:11:07', '2018-05-05 14:11:07', NULL),
(106, 'title', '111', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-05 14:13:30', '2018-05-05 14:13:30', NULL),
(107, 'title', '111113', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/image_1525536772808.jpg', NULL, 1, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-05 16:13:06', '2018-05-07 14:27:26', NULL),
(108, 'title', 'fuucgioh', NULL, NULL, 0, 0, 0, 86, NULL, NULL, NULL, 1, '2018-05-07 14:13:31', '2018-05-07 14:13:31', NULL),
(109, 'title', 'Heyyyyy', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/image_1525703285051.jpg', NULL, 0, 0, 0, 86, 13, NULL, NULL, 1, '2018-05-07 14:28:35', '2018-05-07 14:28:35', NULL),
(110, 'title', 'cvhhfss\ncghhjk\nxvhhjkklcfhjj gfxzzz vxzzdffghhjjvccxxzzz\nccvbbnnmxfhnmnjkmnm bvccxzzzz\nxcgbjjkkgddssfhhjkl\nchbjmmmdghjkkfghjjkkkv\nxcghjjmmmxghjj', NULL, NULL, 0, 0, 0, 77, NULL, NULL, NULL, 1, '2018-05-13 14:55:21', '2018-05-13 14:55:21', NULL),
(111, 'title', 'gggggkbvcxzsghhjncxcbvsasfgjkllpjgdsdvxzAasdfg\nsdfghhfdfghjkghxzdgh bvxzaaaadfghhjjkvvbnnmvbn\nsdghjkkdfhhjndghhjsghjdfhjj vxAsfghjkmfdghxxzsaafghhjjjkkkkghjkkfghjmdghmgj', NULL, NULL, 0, 0, 0, 77, NULL, NULL, NULL, 1, '2018-05-13 20:27:59', '2018-05-13 20:27:59', NULL),
(112, 'title', 'ggbfzssdghh\nvczzafhhjkk\nxchhjkkklghh\nsfghjjkfhjkll\ndfghjkllfh', NULL, NULL, 0, 0, 0, 77, NULL, NULL, NULL, 1, '2018-05-13 21:29:01', '2018-05-13 21:29:01', NULL),
(113, 'title', 'job', NULL, NULL, 0, 0, 0, 77, 39, NULL, NULL, 1, '2018-05-13 22:25:23', '2018-05-13 22:25:23', NULL),
(114, 'title', 'ghh', NULL, NULL, 0, 0, 0, 86, 13, NULL, NULL, 1, '2018-05-16 20:57:55', '2018-05-16 20:57:55', NULL),
(115, 'title', 'He\'d djdv jsvbd jdvddb jkwbdn kbwbdn jsvbd jheننث ي مري jebdb jeb d jebdb jobs d jjdbd job sejb jjd d jobs dj d dnj  Jens k d Jen I d djb sjebb knew ekbe s j d  dj  djb', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-22 23:00:17', '2018-05-22 23:00:17', NULL),
(116, 'title', 'job1', NULL, NULL, 0, 0, 0, 7, 17, NULL, NULL, 1, '2018-05-22 23:52:15', '2018-05-22 23:52:15', NULL),
(117, 'title', 'hsjssjns sbdnkdjdjdn dbsjkebsbdv', NULL, NULL, 0, 0, 0, 7, 17, NULL, NULL, 1, '2018-05-22 23:52:39', '2018-05-22 23:52:39', NULL),
(118, '', 'description 8', NULL, NULL, 0, 0, 0, 7, NULL, NULL, NULL, 1, '2018-05-23 04:57:16', '2018-05-23 04:57:16', NULL),
(119, '', 'description 8', NULL, 'asd', 0, 0, 0, 7, NULL, NULL, NULL, 1, '2018-05-23 05:09:45', '2018-05-23 05:09:45', NULL),
(120, 'title', 'fuicivvi', NULL, NULL, 0, 0, 0, 86, NULL, NULL, NULL, 1, '2018-05-23 12:57:12', '2018-05-23 12:57:12', NULL),
(121, 'title', 'd6ufigig ydufigig duufifigog cuufigog ufifogohoh udu\nysfiigog jxifigkg\nufifogohoh ufifogohoh xuifkgkgkg ixicjcjv\nxuhxjckgkv dujfickglb jxuxjcjcjv jxjcjcjg\nududifogig ufufigigig uxuxjfigog hxjxkckc\nhxudif', NULL, NULL, 0, 0, 0, 86, 13, NULL, NULL, 1, '2018-05-23 12:57:57', '2018-05-23 12:57:57', NULL),
(122, 'title', 'yydufog', NULL, NULL, 0, 0, 0, 96, NULL, NULL, NULL, 1, '2018-05-23 13:02:47', '2018-05-23 13:02:47', NULL),
(123, 'title', '7rufigjfjcgxfzhxkv cuufur', NULL, NULL, 0, 0, 0, 96, NULL, NULL, NULL, 1, '2018-05-23 13:03:28', '2018-05-23 13:03:28', NULL),
(124, 'title', 'uzxikvicxuyd', NULL, NULL, 0, 0, 0, 96, NULL, NULL, NULL, 1, '2018-05-23 14:14:49', '2018-05-23 14:14:49', NULL),
(125, 'title', 'Qwee', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/magazine-unlock-01-2.3.976-_b208859b5ea64fbb97f7f381e8e3430e.jpg', NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-23 22:07:33', '2018-05-23 22:07:33', NULL),
(126, 'title', 'ucuvig', NULL, NULL, 0, 0, 0, 96, NULL, NULL, NULL, 1, '2018-05-23 23:23:17', '2018-05-23 23:23:17', NULL),
(127, 'title', 'Pdf', NULL, 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IJob.pdf', 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-24 06:41:12', '2018-05-24 06:41:12', NULL),
(128, 'title', 'Pdf2', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/Pic.jpg', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IJob.pdf', 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-24 06:49:08', '2018-05-24 06:49:08', NULL),
(129, 'title', 'Pdf img', NULL, 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IJob.pdf1527145205910', 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-24 07:00:15', '2018-05-24 07:00:15', NULL),
(130, 'title', 'Test img', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-24 07:20:09', '2018-05-24 07:20:09', NULL),
(131, 'title', 'Trst', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/Pic1527146488785.jpg', NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-24 07:22:37', '2018-05-24 07:22:37', NULL),
(132, 'title', 'Ed', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/Pic1527146590055.jpg', NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-24 07:23:47', '2018-05-24 07:23:47', NULL),
(133, 'title', 'Fgg', NULL, 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IJob1527146659431.pdf', 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-24 07:24:41', '2018-05-24 07:24:41', NULL),
(134, 'title', 'Ghh', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/Pic1527146771259.jpg', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IJob1527146762457.pdf', 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-24 07:26:26', '2018-05-24 07:26:26', NULL),
(135, 'title', 'cufuufugug8g8guf8g', NULL, NULL, 0, 0, 0, 97, NULL, NULL, NULL, 1, '2018-05-24 10:04:11', '2018-05-24 10:04:11', NULL),
(136, 'title', 'ycucugiv', NULL, NULL, 0, 0, 0, 97, NULL, NULL, NULL, 1, '2018-05-24 10:05:56', '2018-05-24 10:05:56', NULL),
(137, 'title', '123', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/magazine-unlock-01-2.3.969-_b05ad63e6aa945858a0d25fda10fac061527157603365.jpg', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IJob1527157608352.pdf', 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-24 10:26:52', '2018-05-24 10:26:52', NULL),
(138, 'title', 'Test', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/Pic1527157649129.jpg', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IJob1527157653140.pdf', 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-24 10:27:42', '2018-05-24 10:27:42', NULL),
(139, 'title', 'xxxx', NULL, NULL, 0, 0, 0, 97, NULL, NULL, NULL, 1, '2018-05-24 10:59:14', '2018-05-24 10:59:14', NULL),
(140, 'title', 'txucuc', NULL, NULL, 0, 0, 0, 97, NULL, NULL, NULL, 1, '2018-05-24 11:41:08', '2018-05-24 11:41:08', NULL),
(141, 'title', 'ttvyv7bb7', NULL, NULL, 0, 0, 0, 98, NULL, NULL, NULL, 1, '2018-05-25 09:21:11', '2018-05-25 09:21:11', NULL),
(142, 'title', 'dcscd', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-25 11:46:44', '2018-05-25 11:46:44', NULL),
(143, 'title', 'dcdfsc', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IMG_20180525_0858591527248861510.jpg', NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-25 11:48:51', '2018-05-25 11:48:51', NULL),
(144, 'title', 'test', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IMG_20180525_0858591527249999218.jpg', NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-05-25 12:07:58', '2018-05-25 12:07:58', NULL),
(145, 'title', 'test', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IMG_20180525_0858591527249999218.jpg', NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-05-25 12:07:59', '2018-05-25 12:07:59', NULL),
(146, 'title', 'txyccuuc', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/car1527257480485.jpg', NULL, 0, 0, 0, 99, NULL, NULL, NULL, 1, '2018-05-25 14:11:26', '2018-05-25 14:11:26', NULL),
(147, 'title', 'vyyvuvu', NULL, NULL, 0, 0, 0, 101, NULL, NULL, NULL, 1, '2018-05-25 14:17:49', '2018-05-25 14:17:49', NULL),
(148, 'title', 'aa', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IMG_20180525_0858591527249999218.jpg', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/android_tutorial1527258750888.pdf', 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-05-25 14:34:37', '2018-05-25 14:34:37', NULL),
(149, 'title', 'Test pad', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-25 15:15:30', '2018-05-25 15:15:30', NULL),
(150, 'title', 'Qq', NULL, 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IJob1527261350748.pdf', 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-25 15:15:57', '2018-05-25 15:15:57', NULL),
(151, 'title', 'Test pdf', NULL, 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IJob1527261625335.pdf', 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-25 15:20:30', '2018-05-25 15:20:30', NULL),
(152, 'title', 'cyctc', NULL, NULL, 0, 0, 0, 101, NULL, NULL, NULL, 1, '2018-05-25 19:03:37', '2018-05-25 19:03:37', NULL),
(153, 'title', 'tcctycyvyvyvyv', NULL, NULL, 0, 0, 0, 101, NULL, NULL, NULL, 1, '2018-05-25 19:04:14', '2018-05-25 19:04:14', NULL),
(154, 'title', 'ycuvibib', NULL, NULL, 0, 0, 0, 101, NULL, NULL, NULL, 1, '2018-05-25 19:04:49', '2018-05-25 19:04:49', NULL),
(155, 'title', 'ycuvibib', NULL, NULL, 0, 0, 0, 101, NULL, NULL, NULL, 1, '2018-05-25 19:04:49', '2018-05-25 19:04:49', NULL),
(156, 'title', 'chn', NULL, 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/Design Options1527275238631.pdf', 1, 0, 0, 101, NULL, NULL, NULL, 1, '2018-05-25 19:07:26', '2018-05-27 14:06:56', NULL),
(157, 'title', 'ghnnffddc\nfgghjnbn\nfghjjkkll\nxgbjkkllghj\nxchjnmkk', NULL, NULL, 0, 0, 0, 77, NULL, NULL, NULL, 1, '2018-05-27 14:06:38', '2018-05-27 14:06:38', NULL),
(158, 'title', 'hccdfgvv\nfghhjkbh\nxfghhjk\nfvbnnmm', NULL, NULL, 1, 0, 0, 77, 39, NULL, NULL, 1, '2018-05-27 14:08:28', '2018-05-27 23:10:31', NULL),
(159, 'title', 'job test', NULL, 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/asa_hiro 3.01527470522482.pdf', 0, 0, 0, 77, 39, NULL, NULL, 1, '2018-05-28 01:23:07', '2018-05-28 01:23:07', NULL),
(160, 'title', 'zfgvb\nvghhjb\ncvbnnm\nxgbj', NULL, NULL, 0, 0, 0, 77, NULL, NULL, NULL, -1, '2018-05-29 18:49:52', '2018-06-08 01:55:01', NULL),
(161, 'title', 'Test1', NULL, NULL, 0, 0, 0, 26, 13, NULL, NULL, 1, '2018-05-30 22:38:30', '2018-05-30 22:38:30', NULL),
(162, 'title', 'Test1', NULL, NULL, 0, 0, 0, 26, NULL, NULL, NULL, 1, '2018-05-30 22:44:22', '2018-05-30 22:44:22', NULL),
(163, 'title', 'Test2', NULL, NULL, 0, 0, 0, 26, 38, NULL, NULL, 1, '2018-05-30 22:44:37', '2018-05-30 22:44:37', NULL),
(164, 'title', 'zshsisis', NULL, NULL, 0, 0, 0, 103, NULL, NULL, NULL, 1, '2018-05-30 23:55:26', '2018-05-30 23:55:26', NULL),
(165, 'title', 'zhsjzksoos', NULL, NULL, 0, 0, 0, 103, NULL, NULL, NULL, 1, '2018-05-30 23:55:36', '2018-05-30 23:55:36', NULL),
(166, 'title', 'zzbsnsk', NULL, NULL, 0, 0, 0, 103, NULL, NULL, NULL, 1, '2018-05-30 23:56:10', '2018-05-30 23:56:10', NULL),
(167, 'title', 'vyzubzibzisn', NULL, NULL, 0, 0, 0, 103, NULL, NULL, NULL, 1, '2018-05-30 23:56:26', '2018-05-30 23:56:26', NULL),
(168, 'title', 'zb7zibaib', NULL, NULL, 0, 0, 0, 103, 46, NULL, NULL, 1, '2018-05-30 23:56:39', '2018-05-30 23:56:39', NULL),
(169, 'title', 'yvvyub k', NULL, NULL, 0, 0, 0, 104, 47, NULL, NULL, 1, '2018-05-30 23:59:32', '2018-05-30 23:59:32', NULL),
(170, 'title', 'zztsyus', NULL, NULL, 0, 0, 0, 107, NULL, NULL, NULL, 1, '2018-05-31 09:01:52', '2018-05-31 09:01:52', NULL),
(171, 'title', 'hxjdjd', NULL, NULL, 1, 0, 0, 107, 48, NULL, NULL, 1, '2018-05-31 09:02:17', '2018-06-08 21:24:49', NULL),
(172, 'title', 'looking for job', NULL, NULL, 0, 0, 0, 110, NULL, NULL, NULL, 1, '2018-05-31 22:58:47', '2018-05-31 22:58:47', NULL),
(173, 'title', 'looking for job', NULL, NULL, 0, 0, 0, 110, NULL, NULL, NULL, 1, '2018-05-31 22:59:14', '2018-05-31 22:59:14', NULL),
(174, 'title', 'looking for v h', NULL, NULL, 0, 0, 0, 110, 49, NULL, NULL, 1, '2018-05-31 22:59:30', '2018-05-31 22:59:30', NULL),
(175, 'title', 'job test2', NULL, NULL, 2, 1, 0, 77, 40, NULL, NULL, 1, '2018-06-01 19:44:16', '2018-06-11 01:41:46', NULL),
(176, 'title', '#الجالية_وظائف\nمكتب استشارى كبير بالرياض\nبحاجة الى :\n- مدراء مشاريع خبرات من 5 الى 10 سنوات منها لا يقل عن 10 سنوات استشارى\n- مهندسين مدنى/ ميكانيكا / معمارى / كهرباء / ضبط جوده خبرة لا تقل عن 5 سنوات كاستشارى \n- مراقبين ومساحين وحاسبين كميات خبرة لا تقل عن 5 سنوات كاستشارى\nالتعاقد بنظام نقل الكفالة\nللتواصل وارسال السيرة الذاتية على\nhr.specialist@ecec.com.sa\n011 4772215. Ext : 104', NULL, NULL, 1, 0, 0, 111, NULL, NULL, NULL, 1, '2018-06-07 17:03:59', '2018-06-08 01:55:41', NULL),
(177, 'title', 'لمكتب استشارى مطلوب', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IMG-20180607-WA00421528391105414.jpg', NULL, 1, 0, 0, 111, NULL, NULL, NULL, 1, '2018-06-07 17:05:31', '2018-06-07 17:15:37', NULL),
(178, 'title', 'vccdf\ndgghj\nfgbn', NULL, NULL, 1, 0, 0, 77, NULL, NULL, NULL, 1, '2018-06-07 17:15:23', '2018-06-08 01:53:42', NULL),
(179, 'title', 'Vacancy Announcement\nConstruction Services Business Unit\n\nC.S.B.U seeks to hire the following positions:\n\n1. Construction Manager / Project Manager /Resident Engineer (Civil/Architect):  15+ yrs of experience in construction management, FIDIC Contract experience is a must\n2. Documents Controller: 3 to 10 yrs of experience. Practical experience in Word and Excel.\n3. Technical Office Engineer:  7 to 15 yrs of experience\n• For Technical Office Structural/Civil Engineer: Roads, Highways, Concrete Piles, Geotechnical or Tunnels or Bridges or High Rise Buildings or Steel Structure experience is recommended\n• For Technical Office Architect: High Rise Buildings, Hospitals, Hotels, Compounds experience is recommended\n• For Technical Office Mechanical Engineer: Tunnels or Infrastructure Utilities Networks or HVAC Works is recommended\n• For Technical Office Electrical Engineer : Tunnels or Power Stations or Transmission Lines or Infrastructure Utilities Networks experience is recommended, Light Current, Signaling and Telecommunication experience is a plus\n4. Site Engineers: Mechanical : 3+,5+, 10+ & 15+ yrs of experience in all projects’ phases including Engineering and Construction activities and Quality Assurance Implementation, as well as review of project’s technical submittals is a plus\n5. Contract Administrator:  10+ & 15+yrs of experience in Contract Administration, and claims assessments - FIDIC Contract experience is recommended\n6. Site Civil Infrastructure Engineer:  7+ , 10+ & 15+yrs of experience in site construction supervision and Quality Assurance for Infrastructure utilities Networks\n7. Site Quantity Surveyor:  5+,7+ &  10+ yrs of experience in all Quantity Surveying and Cost Control issues\n8. Planning Engineer:  5+, 10+ & 15+ yrs of experience (out of which min. 2 years in Planning and/or Cost Control field, and follow up of Construction Projects, Primavera Enterprise; Project management certification is recommended\n9. Safety Officer / Safety Engineer– Construction: 7+ & 10+ yrs of experience in managing safety in construction sites, safety certificates is a plus\n\nGENERAL REQUIREMENTS:\n\n•  B.Sc. in related discipline with a minimum grade of “Good”, M.Sc. is a plus\n•  PMP / Masters / Certification is an advantage\n•  Good command of related Egyptian, and international Codes\n•  Good Computer skills and command of relevant applications\n•  Good command in English (writing – speaking)\n•  Experience in Large Scale & Mega Projects such as, 5 Stars Hotels or Malls or Hospitals or Airports … etc\n\nN.B: ECG employees are welcomed to refer high caliber CVs (from outside the company) to the Construction Services Business Unit\n\nVacancies are for Egyptians Only \n\nHOW TO APPLY\n\nCandidates meeting the above requirements are requested to send their updated CVs (with a recent formal photo); indicating position applied for, to the following emails/ contact persons:\n\nmoustafa.abbas@ecgsa.com', NULL, NULL, 1, 0, 0, 111, NULL, NULL, NULL, 1, '2018-06-08 01:58:38', '2018-06-08 21:24:55', NULL),
(180, 'title', 'ksa job', NULL, 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/ey-ksa-white-land-tax1528423289481.pdf', 1, 0, 0, 111, NULL, NULL, NULL, 1, '2018-06-08 02:02:20', '2018-06-13 12:30:55', NULL),
(181, 'title', 'يحتاج مبرمج ابعتها للى يهمك', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IMG-20180610-WA00141528645239879.jpg', NULL, 1, 0, 0, 111, NULL, NULL, NULL, 1, '2018-06-10 15:41:16', '2018-06-11 13:07:25', NULL),
(182, 'title', 'ابعت للتعرفة محتاجين توصيل طلبات مطاعم', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IMG-20180610-WA00151528645312715.jpg', NULL, 0, 0, 0, 111, NULL, NULL, NULL, 1, '2018-06-10 15:42:37', '2018-06-10 15:42:37', NULL),
(183, 'title', 'Saudi group', NULL, NULL, 0, 0, 0, 111, NULL, NULL, NULL, 1, '2018-06-10 19:09:39', '2018-06-10 19:10:03', '2018-06-10 19:10:03'),
(184, 'title', 'job', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/Screenshot_20180611-0416171528684856741.png', NULL, 1, 0, 0, 77, NULL, NULL, NULL, 1, '2018-06-11 02:41:21', '2018-06-11 13:08:04', NULL),
(185, 'title', 'يبحث عن عمل', NULL, 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/cv mth1528719777356.pdf', 0, 0, 0, 77, NULL, NULL, NULL, 1, '2018-06-11 12:23:31', '2018-06-11 12:23:31', NULL),
(186, 'title', 'hvcxcbbvc\nvccxvbn\nvccvbnn', NULL, NULL, 1, 0, 0, 111, NULL, NULL, NULL, 1, '2018-06-11 14:48:45', '2018-06-11 14:49:16', NULL),
(187, 'title', 'test', NULL, NULL, 1, 0, 0, 111, NULL, NULL, NULL, 1, '2018-06-11 14:52:45', '2018-06-11 14:53:25', NULL),
(188, 'title', 'Jobs', NULL, NULL, 2, 0, 0, 77, NULL, NULL, NULL, 1, '2018-06-11 20:28:08', '2018-06-13 12:34:59', NULL),
(189, 'title', 'Tt', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/magazine-unlock-05-2.3.1004-_DFCFE7EF9B663939CE39DD186A88ECF01528837565303.jpg', NULL, 0, 1, 0, 26, NULL, NULL, NULL, 1, '2018-06-12 21:06:23', '2018-06-22 22:35:51', NULL),
(190, 'title', 'Job test 2', NULL, NULL, 2, 0, 0, 115, NULL, NULL, NULL, 1, '2018-06-13 12:34:34', '2018-06-13 15:55:21', NULL),
(191, 'title', 'dfvvbjkbbb', NULL, NULL, 4, 2, 0, 115, NULL, NULL, NULL, 1, '2018-06-13 15:58:01', '2018-06-26 00:13:01', NULL),
(192, 'title', 'مطلوب فنى أجهزة طبية  خبر ة خمس  سنوات ولديه  الهيئة السعودية للمهندسين والإقامة فنى أجهزة طبية ولديه نقل كفالة والراتب 4500ريال لمستشفى العمران بالأحساء ومطلوب مهندس أجهزة طبية خبرة خمس سنوا', NULL, NULL, 1, 0, 0, 116, NULL, NULL, NULL, 1, '2018-06-13 21:20:20', '2018-06-13 21:22:39', NULL),
(193, 'title', 'uvobon', NULL, NULL, 1, 0, 0, 29, 13, NULL, NULL, 1, '2018-06-21 19:14:13', '2018-06-21 19:14:45', NULL),
(194, 'title', 'New job', NULL, NULL, 0, 1, 0, 29, NULL, NULL, NULL, 1, '2018-06-21 19:20:15', '2018-06-24 21:45:28', NULL),
(195, 'title', 'Test job H1', NULL, NULL, 1, 6, 0, 7, NULL, NULL, NULL, 1, '2018-06-21 19:35:05', '2018-06-29 14:38:15', NULL),
(196, 'title', 'tezt', NULL, NULL, 1, 0, 0, 29, NULL, NULL, NULL, 1, '2018-06-21 19:43:52', '2018-06-21 19:44:43', NULL),
(197, 'title', 'hjkk', NULL, NULL, 0, 0, 0, 29, NULL, NULL, NULL, 1, '2018-06-21 19:47:57', '2018-06-21 19:47:57', NULL),
(198, 'title', 'hc', NULL, NULL, 1, 0, 0, 29, NULL, NULL, NULL, 1, '2018-06-21 19:50:13', '2018-06-21 19:50:26', NULL),
(199, 'title', 'bnn', NULL, NULL, 1, 0, 0, 29, NULL, NULL, NULL, 1, '2018-06-21 19:52:52', '2018-06-21 19:53:03', NULL),
(200, 'title', 'no hesham', NULL, NULL, 0, 0, 0, 29, NULL, NULL, NULL, 1, '2018-06-21 19:56:58', '2018-06-21 19:56:58', NULL),
(201, 'title', 'xxhcuig', NULL, NULL, 1, 1, 0, 29, 52, NULL, NULL, 1, '2018-06-21 19:58:11', '2018-06-23 12:55:35', NULL),
(202, 'title', 'Yes H', NULL, NULL, 0, 0, 0, 7, NULL, NULL, NULL, 1, '2018-06-21 20:17:21', '2018-06-21 20:17:21', NULL),
(203, 'title', 'Yes H', NULL, NULL, 0, 2, 0, 7, NULL, NULL, NULL, 1, '2018-06-21 20:18:04', '2018-06-24 23:03:41', NULL),
(204, 'title', 'test job H 3', NULL, NULL, 0, 0, 0, 7, 53, NULL, NULL, 1, '2018-06-21 20:18:55', '2018-06-21 20:18:55', NULL),
(205, 'title', 'ghj', NULL, NULL, 0, 1, 0, 29, NULL, NULL, NULL, 1, '2018-06-23 13:55:46', '2018-06-24 22:56:35', NULL),
(206, 'title', 'test', NULL, NULL, 1, 5, 0, 29, NULL, NULL, NULL, 1, '2018-06-23 13:58:30', '2018-06-25 23:10:16', NULL),
(207, 'title', 'مطلوب من داخل المملكه فقط :\n—————————-\nنحتاج مهندسين استشاري من جميع التخصصات \nخريجي أمريكا أو أوروبا\nخبرة لا تقل عن ١٥ سنه\nلأحد مشاريع الإسكان الكبري بالمملكه،\n\n-م مدني\n-م انشائي\n-م معماري\n-', NULL, NULL, 2, 5, 0, 116, NULL, NULL, NULL, 1, '2018-06-23 18:27:53', '2018-06-26 19:17:51', NULL),
(208, 'title', 'مطلوب مهندس إنشائي يجيد sap & etabs &autocad خبره ف التصميم من سنه إلي ثلاث سنوات لمكتب استشاري هندسي بمدينة نصر رجاء ارسال السيرة الذاتية علي ramymahmoud37@yahoo.com', NULL, NULL, 0, 2, 0, 116, 45, NULL, NULL, 1, '2018-06-24 23:13:10', '2018-06-29 14:22:44', NULL),
(209, 'title', 'Job test 4', NULL, NULL, 2, 0, 0, 115, NULL, NULL, NULL, 1, '2018-06-24 23:17:51', '2018-06-25 02:41:18', '2018-06-25 02:41:18'),
(210, 'title', 'testjob', NULL, NULL, 3, 2, 0, 29, NULL, NULL, NULL, 1, '2018-06-25 23:23:39', '2018-06-26 19:19:30', NULL),
(211, 'title', 'ggh', NULL, NULL, 0, 1, 0, 113, NULL, NULL, NULL, 1, '2018-06-25 23:57:57', '2018-06-26 00:37:00', NULL),
(212, 'title', 'Job test job test', NULL, NULL, 0, 0, 0, 121, NULL, NULL, NULL, 1, '2018-06-26 00:14:54', '2018-06-26 00:14:54', NULL),
(213, 'title', 'hi', NULL, NULL, 0, 1, 0, 113, NULL, NULL, NULL, 1, '2018-06-26 00:34:38', '2018-06-26 00:34:51', NULL),
(214, 'title', 'job', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/Screenshot_20180427-1559261529973265751.png', NULL, 0, 1, 0, 121, NULL, NULL, NULL, 1, '2018-06-26 00:34:43', '2018-06-26 00:42:05', NULL),
(215, 'title', 'السلام عليكم ورحمة الله وبركاته\nالزملاء الكرام\nمطلوب مهندس ميكانيكا ، خبرة لا تقل عن 10 سنوات ، لمكتب استشاري\nالعمل بالمنطقة الشرقية \nKhames_arc@yahoo.com', NULL, NULL, 0, 1, 0, 116, 50, NULL, NULL, 1, '2018-06-26 19:20:29', '2018-06-26 19:28:09', NULL),
(216, 'title', 'السلام عليكم ورحمة الله وبركاته\nالزملاء الكرام\nمطلوب مهندس ميكانيكا ، خبرة لا تقل عن 10 سنوات ، لمكتب استشاري\nالعمل بالمنطقة الشرقية \nKhames_arc@yahoo.com', NULL, NULL, 1, 0, 0, 116, NULL, NULL, NULL, 1, '2018-06-26 19:22:02', '2018-06-26 19:22:39', NULL),
(217, 'title', 'job in KSA', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/Screenshot_2018-06-27-00-31-391530048733247.jpg', NULL, 1, 1, 0, 113, NULL, NULL, NULL, 1, '2018-06-26 21:32:31', '2018-06-26 21:36:41', NULL),
(218, 'title', 'for Egyptian only, Cairo and Delta residents.\n\nurgent for medical equipment and drugs for IVF labs in Heliopolis, Cairo \n\nwe need medical Reps & biomedical Engineers with IVF background\n\n-fresh graduate or 1-year experience.\n\n-preferred science or Vet graduated for medical Reps\n\n-Biomedical, Electronics and Electrical Engineering are welcome\n\n-prefer males for biomedical engineer positions.\n\n- work will be in Cairo and Delta area.\n\nfor candidates please send your detailed CV. with a recent Photo\n\nto globalpharm2008@gmail.com\nMobile 01022060773', NULL, NULL, 0, 0, 0, 113, NULL, NULL, NULL, 1, '2018-06-26 22:19:16', '2018-06-26 22:19:16', NULL),
(219, 'title', 'مطلوب للعمل بالمدينة المنورة \nمهندس معماري خبرة ١٠ سنوات\nيشترط نقل الكفالة\nرجاءا ارسال السيرة الذاتية على\n\nMns00hr2018@gmail.com', NULL, NULL, 0, 0, 0, 113, NULL, NULL, NULL, 1, '2018-06-27 10:29:15', '2018-06-27 10:29:15', NULL),
(220, 'title', 'شباب\nبدور على حد .Net Developer خبرة مش اقل من 5 سنين وياريت Certified لشغل برة مصر اللي يعرف حد يبعت ال سي في\neng.abdullah.g@gmail.com', NULL, NULL, 0, 1, 0, 113, NULL, NULL, NULL, 1, '2018-06-27 11:30:28', '2018-06-28 22:41:24', NULL),
(221, 'title', 'وظائف شاغرة للجنسين في مدينة الملك عبدالعزيز للعلوم والتقنية\n\nhttps://twitter.com/kacst/status/1011906545733570560?s=12', NULL, NULL, 0, 0, 0, 113, NULL, NULL, NULL, 1, '2018-06-27 13:37:26', '2018-06-27 13:37:26', NULL),
(222, 'title', 'هىهىمىخىهر', NULL, NULL, 0, 4, 0, 124, NULL, NULL, NULL, 1, '2018-06-29 13:49:27', '2018-06-29 14:18:37', NULL),
(223, 'title', 'new', NULL, NULL, 0, 0, 0, 117, NULL, NULL, NULL, 1, '2018-06-29 14:26:43', '2018-06-29 14:26:43', NULL),
(224, 'title', '‏فرص وظيفية في جدة للجنسين:\n1- operations\n2- Business development\n\nالي مهتم يراسل:  cv@jakapp.co\n👆', NULL, NULL, 0, 0, 0, 113, NULL, NULL, NULL, 1, '2018-06-29 14:26:56', '2018-06-29 14:26:56', NULL),
(225, 'title', 'ggyy', NULL, NULL, 0, 0, 0, 29, NULL, NULL, NULL, 1, '2018-06-29 14:39:02', '2018-06-29 14:39:02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jobs_appliers`
--

CREATE TABLE `jobs_appliers` (
  `id` int(11) NOT NULL,
  `job_id` int(11) DEFAULT NULL,
  `profile_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jobs_appliers`
--

INSERT INTO `jobs_appliers` (`id`, `job_id`, `profile_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 1, 1, NULL, NULL, NULL),
(2, 1, 2, 1, NULL, NULL, NULL),
(3, 1, 11, 0, NULL, NULL, NULL),
(4, 1, 18, 0, NULL, NULL, NULL),
(5, 2, 18, 0, NULL, NULL, NULL),
(6, 1, 18, 0, NULL, NULL, NULL),
(7, 22, 18, 0, NULL, NULL, NULL),
(8, 1, 18, 0, NULL, NULL, NULL),
(9, 1, 18, 0, NULL, NULL, NULL),
(10, 2, 18, 0, NULL, NULL, NULL),
(11, 2, 18, 0, NULL, NULL, NULL),
(12, 3, 18, 0, NULL, NULL, NULL),
(13, 1, 18, 0, NULL, NULL, NULL),
(14, 1, 18, 0, NULL, NULL, NULL),
(15, 1, 18, 0, NULL, NULL, NULL),
(16, 14, 19, 0, NULL, NULL, NULL),
(17, 10, 23, 0, NULL, NULL, NULL),
(18, 24, 18, 0, '2018-03-25 21:05:12', NULL, NULL),
(19, 1, 26, 0, '2018-03-27 18:46:07', NULL, NULL),
(20, 8, 28, 0, '2018-03-30 17:56:47', NULL, NULL),
(21, 8, 28, 0, '2018-03-30 17:57:00', NULL, NULL),
(22, 8, 28, 0, '2018-03-30 17:57:21', NULL, NULL),
(23, 8, 28, 0, '2018-03-30 17:57:25', NULL, NULL),
(24, 27, 28, 0, '2018-03-30 18:00:42', NULL, NULL),
(25, 26, 29, 0, '2018-03-30 19:38:20', NULL, NULL),
(26, 27, 29, 0, '2018-03-30 19:39:26', NULL, NULL),
(27, 27, 6, 0, '2018-04-03 19:31:10', NULL, NULL),
(28, 1, 37, 0, '2018-04-04 20:52:02', NULL, NULL),
(29, 27, 37, 0, '2018-04-04 21:02:46', NULL, NULL),
(30, 1, 42, 0, '2018-04-07 19:29:13', NULL, NULL),
(31, 42, 29, 0, '2018-04-08 21:04:15', NULL, NULL),
(32, 45, 58, 0, '2018-04-13 14:41:57', NULL, NULL),
(33, 40, 58, 0, '2018-04-13 14:42:12', NULL, NULL),
(34, 45, 56, 0, '2018-04-13 14:49:17', NULL, NULL),
(35, 50, 56, 0, '2018-04-13 15:06:06', NULL, NULL),
(36, 44, 56, 0, '2018-04-13 15:47:43', NULL, NULL),
(37, 34, 59, 0, '2018-04-14 18:19:06', NULL, NULL),
(38, 55, 59, 0, '2018-04-14 18:55:07', NULL, NULL),
(39, 55, 6, 0, '2018-04-15 10:54:42', NULL, NULL),
(40, 2, 28, 0, '2018-04-22 20:49:01', NULL, NULL),
(41, 3, 28, 0, '2018-04-22 21:17:01', NULL, NULL),
(42, 4, 28, 0, '2018-04-22 21:21:32', NULL, NULL),
(43, 5, 28, 0, '2018-04-22 21:21:44', NULL, NULL),
(44, 10, 28, 0, '2018-04-22 21:23:35', NULL, NULL),
(45, 62, 28, 0, '2018-04-22 21:23:59', NULL, NULL),
(46, 1, 29, 0, '2018-04-24 09:50:49', NULL, NULL),
(47, 68, 7, 0, '2018-04-24 10:51:00', NULL, NULL),
(48, 69, 7, 0, '2018-04-24 11:10:52', NULL, NULL),
(49, 58, 29, 0, '2018-04-24 11:56:27', NULL, NULL),
(50, 75, 7, 0, '2018-04-24 12:39:50', NULL, NULL),
(51, 73, 7, 0, '2018-04-24 12:41:20', NULL, NULL),
(52, 70, 26, 0, '2018-04-24 21:12:20', NULL, NULL),
(53, 72, 26, 0, '2018-04-24 21:12:53', NULL, NULL),
(54, 67, 26, 0, '2018-04-24 21:13:51', NULL, NULL),
(55, 62, 26, 0, '2018-04-24 21:13:56', NULL, NULL),
(56, 70, 77, 0, '2018-04-25 22:20:33', NULL, NULL),
(57, 72, 77, 0, '2018-04-25 22:20:47', NULL, NULL),
(58, 60, 77, 0, '2018-04-25 22:20:58', NULL, NULL),
(59, 107, 86, 0, '2018-05-07 14:27:26', NULL, NULL),
(60, 156, 77, 0, '2018-05-27 14:06:56', NULL, NULL),
(61, 158, 12, 0, '2018-05-27 23:10:31', NULL, NULL),
(62, 175, 12, 0, '2018-06-01 21:12:35', NULL, NULL),
(63, 177, 77, 0, '2018-06-07 17:15:37', NULL, NULL),
(64, 178, 111, 0, '2018-06-08 01:53:42', NULL, NULL),
(65, 176, 77, 0, '2018-06-08 01:55:41', NULL, NULL),
(66, 171, 111, 0, '2018-06-08 21:24:49', NULL, NULL),
(67, 179, 77, 0, '2018-06-08 21:24:55', NULL, NULL),
(68, 175, 111, 0, '2018-06-08 21:24:59', NULL, NULL),
(69, 181, 12, 0, '2018-06-11 13:07:25', NULL, NULL),
(70, 184, 12, 0, '2018-06-11 13:08:04', NULL, NULL),
(71, 186, 77, 0, '2018-06-11 14:49:16', NULL, NULL),
(72, 187, 77, 0, '2018-06-11 14:53:25', NULL, NULL),
(73, 188, 111, 0, '2018-06-11 20:30:51', NULL, NULL),
(74, 180, 115, 0, '2018-06-13 12:30:55', NULL, NULL),
(75, 188, 115, 0, '2018-06-13 12:34:59', NULL, NULL),
(76, 190, 111, 0, '2018-06-13 15:32:17', NULL, NULL),
(77, 190, 116, 0, '2018-06-13 15:55:21', NULL, NULL),
(78, 191, 116, 0, '2018-06-13 15:59:17', NULL, NULL),
(79, 192, 115, 0, '2018-06-13 21:22:39', NULL, NULL),
(80, 70, 115, 0, '2018-06-13 22:17:57', NULL, NULL),
(81, 191, 29, 0, '2018-06-13 22:23:23', NULL, NULL),
(82, 193, 7, 0, '2018-06-21 19:14:45', NULL, NULL),
(83, 195, 29, 0, '2018-06-21 19:35:35', NULL, NULL),
(84, 196, 7, 0, '2018-06-21 19:44:43', NULL, NULL),
(85, 198, 7, 0, '2018-06-21 19:50:26', NULL, NULL),
(86, 199, 7, 0, '2018-06-21 19:53:03', NULL, NULL),
(87, 201, 7, 0, '2018-06-21 20:25:50', NULL, NULL),
(88, 207, 115, 0, '2018-06-23 18:43:39', NULL, NULL),
(89, 191, 12, 0, '2018-06-24 20:42:36', NULL, NULL),
(90, 209, 116, 0, '2018-06-24 23:21:57', NULL, NULL),
(91, 209, 120, 0, '2018-06-25 01:01:44', NULL, NULL),
(92, 206, 115, 0, '2018-06-25 23:10:16', NULL, NULL),
(93, 210, 115, 0, '2018-06-25 23:26:24', NULL, NULL),
(94, 191, 121, 0, '2018-06-26 00:13:01', NULL, NULL),
(95, 210, 121, 0, '2018-06-26 00:13:09', NULL, NULL),
(96, 207, 113, 0, '2018-06-26 19:17:51', NULL, NULL),
(97, 210, 113, 0, '2018-06-26 19:19:30', NULL, NULL),
(98, 216, 113, 0, '2018-06-26 19:22:39', NULL, NULL),
(99, 217, 116, 0, '2018-06-26 21:36:41', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jobs_forwards`
--

CREATE TABLE `jobs_forwards` (
  `id` int(10) UNSIGNED NOT NULL,
  `job_id` int(11) NOT NULL DEFAULT '0',
  `profile_id` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs_forwards`
--

INSERT INTO `jobs_forwards` (`id`, `job_id`, `profile_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 24, 18, '2018-03-30 14:52:11', NULL, NULL),
(2, 24, 18, '2018-03-30 14:54:59', NULL, NULL),
(3, 24, 18, '2018-03-30 14:57:20', NULL, NULL),
(4, 1, 29, '2018-04-04 20:49:53', NULL, NULL),
(5, 1, 29, '2018-04-04 20:52:45', NULL, NULL),
(6, 1, 24, '2018-04-07 18:46:39', NULL, NULL),
(7, 45, 29, '2018-04-13 11:53:19', NULL, NULL),
(8, 51, 29, '2018-04-13 15:38:14', NULL, NULL),
(9, 51, 7, '2018-04-13 15:38:25', NULL, NULL),
(10, 54, 29, '2018-04-13 15:38:39', NULL, NULL),
(11, 41, 29, '2018-04-13 23:09:05', NULL, NULL),
(12, 56, 29, '2018-04-14 14:51:51', NULL, NULL),
(13, 68, 7, '2018-04-24 09:23:26', NULL, NULL),
(14, 1, 26, '2018-04-24 09:52:29', NULL, NULL),
(15, 72, 7, '2018-04-24 10:38:38', NULL, NULL),
(16, 72, 7, '2018-04-24 10:40:23', NULL, NULL),
(17, 1, 7, '2018-04-24 10:40:39', NULL, NULL),
(18, 27, 26, '2018-04-24 10:40:52', NULL, NULL),
(19, 72, 59, '2018-04-24 10:41:06', NULL, NULL),
(20, 70, 65, '2018-04-28 12:40:42', NULL, NULL),
(21, 175, 6, '2018-06-11 01:41:46', NULL, NULL),
(22, 195, 7, '2018-06-21 19:36:46', NULL, NULL),
(23, 195, 26, '2018-06-21 19:37:46', NULL, NULL),
(24, 189, 29, '2018-06-22 22:35:51', NULL, NULL),
(25, 201, 26, '2018-06-23 12:55:35', NULL, NULL),
(26, 195, 26, '2018-06-23 13:00:13', NULL, NULL),
(27, 191, 12, '2018-06-23 18:33:20', NULL, NULL),
(28, 191, 12, '2018-06-23 18:33:40', NULL, NULL),
(29, 203, 116, '2018-06-23 19:25:42', NULL, NULL),
(30, 206, 6, '2018-06-23 19:32:24', NULL, NULL),
(31, 207, -1, '2018-06-23 20:31:13', NULL, NULL),
(32, 207, 6, '2018-06-24 21:42:04', NULL, NULL),
(33, 195, 12, '2018-06-24 21:45:09', NULL, NULL),
(34, 194, -1, '2018-06-24 21:45:28', NULL, NULL),
(35, 207, 12, '2018-06-24 21:45:53', NULL, NULL),
(36, 205, -1, '2018-06-24 22:56:35', NULL, NULL),
(37, 207, -1, '2018-06-24 23:02:55', NULL, NULL),
(38, 206, 6, '2018-06-24 23:03:29', NULL, NULL),
(39, 203, 6, '2018-06-24 23:03:41', NULL, NULL),
(40, 206, 12, '2018-06-24 23:06:46', NULL, NULL),
(41, 208, 6, '2018-06-24 23:13:45', NULL, NULL),
(42, 207, 6, '2018-06-24 23:14:31', NULL, NULL),
(43, 195, 29, '2018-06-25 20:22:20', NULL, NULL),
(44, 206, 77, '2018-06-25 22:59:17', NULL, NULL),
(45, 206, 115, '2018-06-25 22:59:24', NULL, NULL),
(46, 210, 77, '2018-06-25 23:25:42', NULL, NULL),
(47, 210, 115, '2018-06-25 23:25:47', NULL, NULL),
(48, 213, 29, '2018-06-26 00:34:51', NULL, NULL),
(49, 211, 29, '2018-06-26 00:37:00', NULL, NULL),
(50, 214, -1, '2018-06-26 00:42:05', NULL, NULL),
(51, 215, 6, '2018-06-26 19:28:09', NULL, NULL),
(52, 217, 116, '2018-06-26 21:34:56', NULL, NULL),
(53, 220, -1, '2018-06-28 22:41:24', NULL, NULL),
(54, 222, 7, '2018-06-29 13:52:52', NULL, NULL),
(55, 222, 7, '2018-06-29 13:55:23', NULL, NULL),
(56, 222, 77, '2018-06-29 13:55:29', NULL, NULL),
(57, 222, -1, '2018-06-29 14:18:37', NULL, NULL),
(58, 208, 6, '2018-06-29 14:22:44', NULL, NULL),
(59, 195, 7, '2018-06-29 14:38:15', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jobs_hidden`
--

CREATE TABLE `jobs_hidden` (
  `id` int(10) UNSIGNED NOT NULL,
  `job_id` int(11) NOT NULL DEFAULT '0',
  `profile_id` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs_hidden`
--

INSERT INTO `jobs_hidden` (`id`, `job_id`, `profile_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 18, '2018-03-25 20:05:44', NULL, NULL),
(2, 2, 18, '2018-03-25 20:05:55', NULL, NULL),
(3, 1, 18, '2018-03-25 21:00:00', NULL, NULL),
(4, 1, 18, '2018-03-25 21:00:10', NULL, NULL),
(5, 1, 18, '2018-03-25 22:01:36', NULL, NULL),
(6, 3, 18, '2018-03-25 22:01:58', NULL, NULL),
(7, 3, 18, '2018-03-25 22:02:44', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `job_transaction`
--

CREATE TABLE `job_transaction` (
  `id` int(10) UNSIGNED NOT NULL,
  `job_id` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_transaction`
--

INSERT INTO `job_transaction` (`id`, `job_id`, `profile_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 26, 3, '2018-03-27 18:46:07', '2018-03-27 18:46:07', NULL),
(2, 8, 28, 4, '2018-03-30 17:56:47', '2018-03-30 17:56:47', NULL),
(7, 27, 28, 3, '2018-03-30 18:00:42', '2018-03-30 18:00:42', NULL),
(8, 26, 29, 3, '2018-03-30 19:38:20', '2018-03-30 19:38:20', NULL),
(9, 27, 29, 3, '2018-03-30 19:39:26', '2018-03-30 19:39:26', NULL),
(10, 27, 6, 3, '2018-04-03 19:31:10', '2018-04-03 19:31:10', NULL),
(11, 1, 37, 3, '2018-04-04 20:52:02', '2018-04-04 20:52:02', NULL),
(12, 27, 37, 3, '2018-04-04 21:02:46', '2018-04-04 21:02:46', NULL),
(13, 1, 42, 3, '2018-04-07 19:29:13', '2018-04-07 19:29:13', NULL),
(14, 42, 29, 3, '2018-04-08 21:04:15', '2018-04-08 21:04:15', NULL),
(15, 45, 58, 3, '2018-04-13 14:41:57', '2018-04-13 14:41:57', NULL),
(16, 40, 58, 3, '2018-04-13 14:42:12', '2018-04-13 14:42:12', NULL),
(17, 45, 56, 4, '2018-04-13 14:49:17', '2018-04-13 14:49:17', NULL),
(18, 50, 56, 3, '2018-04-13 15:06:06', '2018-04-13 15:06:06', NULL),
(20, 44, 56, 3, '2018-04-13 15:47:43', '2018-04-13 15:47:43', NULL),
(21, 34, 59, 3, '2018-04-14 18:19:06', '2018-04-14 18:19:06', NULL),
(22, 55, 59, 2, '2018-04-14 18:55:07', '2018-04-14 18:55:07', NULL),
(23, 55, 6, 2, '2018-04-15 10:54:42', '2018-04-15 10:54:42', NULL),
(24, 56, 6, 4, '2018-04-15 10:54:54', '2018-04-15 10:54:54', NULL),
(25, 2, 28, 3, '2018-04-22 20:49:01', '2018-04-22 20:49:01', NULL),
(26, 3, 28, 3, '2018-04-22 21:17:01', '2018-04-22 21:17:01', NULL),
(27, 4, 28, 3, '2018-04-22 21:21:32', '2018-04-22 21:21:32', NULL),
(28, 5, 28, 3, '2018-04-22 21:21:44', '2018-04-22 21:21:44', NULL),
(29, 10, 28, 3, '2018-04-22 21:23:35', '2018-04-22 21:23:35', NULL),
(30, 62, 28, 3, '2018-04-22 21:23:59', '2018-04-22 21:23:59', NULL),
(31, 1, 29, 4, '2018-04-24 09:50:49', '2018-04-24 09:50:49', NULL),
(32, 68, 7, 3, '2018-04-24 10:51:00', '2018-04-24 10:51:00', NULL),
(33, 69, 7, 3, '2018-04-24 11:10:52', '2018-04-24 11:10:52', NULL),
(34, 58, 29, 3, '2018-04-24 11:56:27', '2018-04-24 11:56:27', NULL),
(35, 75, 7, 3, '2018-04-24 12:39:50', '2018-04-24 12:39:50', NULL),
(36, 73, 7, 3, '2018-04-24 12:41:20', '2018-04-24 12:41:20', NULL),
(37, 70, 26, 2, '2018-04-24 21:12:20', '2018-04-24 21:12:20', NULL),
(38, 72, 26, 2, '2018-04-24 21:12:53', '2018-04-24 21:12:53', NULL),
(39, 67, 26, 3, '2018-04-24 21:13:51', '2018-04-24 21:13:51', NULL),
(40, 62, 26, 3, '2018-04-24 21:13:56', '2018-04-24 21:13:56', NULL),
(41, 62, 77, 4, '2018-04-25 22:19:31', '2018-04-25 22:19:31', NULL),
(42, 64, 77, 4, '2018-04-25 22:19:47', '2018-04-25 22:19:47', NULL),
(43, 70, 77, 2, '2018-04-25 22:20:33', '2018-04-25 22:20:33', NULL),
(44, 72, 77, 2, '2018-04-25 22:20:47', '2018-04-25 22:20:47', NULL),
(45, 60, 77, 3, '2018-04-25 22:20:58', '2018-04-25 22:20:58', NULL),
(54, 107, 86, 2, '2018-05-07 14:27:26', '2018-05-07 14:27:26', NULL),
(55, 156, 77, 3, '2018-05-27 14:06:56', '2018-05-27 14:06:56', NULL),
(56, 158, 12, 3, '2018-05-27 23:10:31', '2018-05-27 23:10:31', NULL),
(57, 175, 12, 3, '2018-06-01 21:12:35', '2018-06-01 21:12:35', NULL),
(58, 177, 77, 3, '2018-06-07 17:15:37', '2018-06-07 17:15:37', NULL),
(60, 178, 111, 3, '2018-06-08 01:53:42', '2018-06-08 01:53:42', NULL),
(62, 176, 77, 3, '2018-06-08 01:55:41', '2018-06-08 01:55:41', NULL),
(69, 171, 111, 3, '2018-06-08 21:24:49', '2018-06-08 21:24:49', NULL),
(70, 179, 77, 3, '2018-06-08 21:24:55', '2018-06-08 21:24:55', NULL),
(71, 175, 111, 3, '2018-06-08 21:24:59', '2018-06-08 21:24:59', NULL),
(83, 181, 12, 3, '2018-06-11 13:07:25', '2018-06-11 13:07:25', NULL),
(84, 184, 12, 3, '2018-06-11 13:08:04', '2018-06-11 13:08:04', NULL),
(86, 186, 77, 3, '2018-06-11 14:49:16', '2018-06-11 14:49:16', NULL),
(88, 187, 77, 3, '2018-06-11 14:53:25', '2018-06-11 14:53:25', NULL),
(93, 188, 111, 3, '2018-06-11 20:30:51', '2018-06-11 20:30:51', NULL),
(100, 180, 115, 3, '2018-06-13 12:30:55', '2018-06-13 12:30:55', NULL),
(101, 188, 115, 3, '2018-06-13 12:34:59', '2018-06-13 12:34:59', NULL),
(103, 190, 111, 2, '2018-06-13 15:32:17', '2018-06-13 15:32:17', NULL),
(106, 190, 116, 2, '2018-06-13 15:55:21', '2018-06-13 15:55:21', NULL),
(111, 191, 116, 2, '2018-06-13 15:59:17', '2018-06-13 15:59:17', NULL),
(115, 192, 115, 2, '2018-06-13 21:22:39', '2018-06-13 21:22:39', NULL),
(126, 70, 115, 2, '2018-06-13 22:17:57', '2018-06-13 22:17:57', NULL),
(127, 191, 29, 2, '2018-06-13 22:23:23', '2018-06-13 22:23:23', NULL),
(146, 193, 7, 2, '2018-06-21 19:14:45', '2018-06-21 19:14:45', NULL),
(154, 195, 29, 2, '2018-06-21 19:35:35', '2018-06-21 19:35:35', NULL),
(156, 196, 7, 3, '2018-06-21 19:44:43', '2018-06-21 19:44:43', NULL),
(157, 198, 7, 3, '2018-06-21 19:50:26', '2018-06-21 19:50:26', NULL),
(158, 199, 7, 3, '2018-06-21 19:53:03', '2018-06-21 19:53:03', NULL),
(159, 201, 7, 2, '2018-06-21 20:25:50', '2018-06-21 20:25:50', NULL),
(194, 207, 115, 2, '2018-06-23 18:43:39', '2018-06-23 18:43:39', NULL),
(199, 191, 12, 2, '2018-06-24 20:42:36', '2018-06-24 20:42:36', NULL),
(209, 207, 12, 4, '2018-06-24 23:11:01', '2018-06-24 23:11:01', NULL),
(210, 195, 12, 4, '2018-06-24 23:11:10', '2018-06-24 23:11:10', NULL),
(211, 189, 115, 4, '2018-06-24 23:16:22', '2018-06-24 23:16:22', NULL),
(212, 209, 116, 2, '2018-06-24 23:21:57', '2018-06-24 23:21:57', NULL),
(217, 209, 120, 3, '2018-06-25 01:01:44', '2018-06-25 01:01:44', NULL),
(218, 206, 115, 2, '2018-06-25 23:10:16', '2018-06-25 23:10:16', NULL),
(221, 210, 115, 2, '2018-06-25 23:26:24', '2018-06-25 23:26:24', NULL),
(223, 191, 121, 3, '2018-06-26 00:13:01', '2018-06-26 00:13:01', NULL),
(224, 210, 121, 2, '2018-06-26 00:13:09', '2018-06-26 00:13:09', NULL),
(225, 207, 113, 2, '2018-06-26 19:17:51', '2018-06-26 19:17:51', NULL),
(228, 210, 113, 2, '2018-06-26 19:19:30', '2018-06-26 19:19:30', NULL),
(229, 216, 113, 2, '2018-06-26 19:22:39', '2018-06-26 19:22:39', NULL),
(231, 217, 116, 2, '2018-06-26 21:36:41', '2018-06-26 21:36:41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(19, '2014_10_12_000000_create_users_table', 1),
(20, '2014_10_12_100000_create_password_resets_table', 1),
(21, '2018_01_24_092135_create_pages_table', 1),
(22, '2018_01_24_153934_create_profiles_table', 1),
(23, '2018_01_24_155122_create_jobs_table', 1),
(24, '2018_01_24_155417_create_groups_table', 1),
(25, '2018_03_15_000552_add_is_admin_column', 2),
(26, '2018_03_25_014752_change_jobs_counts_default_values', 3),
(27, '2018_03_25_020823_create_table_job_forwards', 3),
(28, '2018_03_25_030619_create_table_jobs_hidden', 3),
(29, '2018_03_25_223710_create_table_jobs_transactions', 4),
(30, '2018_03_26_231152_change_profile_columns', 5),
(31, '2018_03_26_235318_create_user_contacts_table', 5),
(32, '2018_04_02_025603_create_profile_transaction_table', 6),
(33, '2018_04_04_193743_add_columns_to_profiles', 7),
(34, '2018_04_04_200512_create_work_experience_table', 7),
(35, '2018_04_05_061842_create_profile_tokens_table', 7),
(36, '2018_04_28_224446_create_notifications_table', 8);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile_id` int(11) NOT NULL,
  `token_id` int(11) NOT NULL,
  `body` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_type` int(11) NOT NULL DEFAULT '0',
  `action_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `success` int(11) NOT NULL DEFAULT '0',
  `sending_result` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_new` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `profile_id`, `token_id`, `body`, `action_type`, `action_value`, `success`, `sending_result`, `is_new`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 29, 54, 'You have been added to a group', 2, '[\"13\"]', 1, '[{\"message_id\":\"0:1525032810096121%378826f2378826f2\"}]', 0, '2018-04-29 20:13:30', '2018-04-29 20:13:30', NULL),
(2, 29, 54, 'You have been added to a group', 2, '[\"13\"]', 1, '[{\"message_id\":\"0:1525032937662887%378826f2378826f2\"}]', 0, '2018-04-29 20:15:37', '2018-04-29 20:15:37', NULL),
(3, 29, 54, 'You have been added to a group', 2, '[\"13\"]', 1, '[{\"message_id\":\"0:1525033137788411%378826f2378826f2\"}]', 0, '2018-04-29 20:18:57', '2018-04-29 20:18:57', NULL),
(4, 29, 54, 'You have been added to a group', 2, '[\"13\"]', 1, '[{\"message_id\":\"0:1525033145020853%378826f2378826f2\"}]', 0, '2018-04-29 20:19:05', '2018-04-29 20:19:05', NULL),
(5, 29, 54, 'You have been added to a group', 2, '[\"13\"]', 1, '[{\"message_id\":\"0:1525033165613633%378826f2378826f2\"}]', 0, '2018-04-29 20:19:25', '2018-04-29 20:19:25', NULL),
(6, 26, 53, 'You have been added to a group', 2, '[\"13\"]', 1, '[{\"message_id\":\"0:1525033181238496%378826f2378826f2\"}]', 0, '2018-04-29 20:19:41', '2018-04-29 20:19:41', NULL),
(7, 29, 54, 'You have been added to a group', 2, '[\"13\"]', 1, '[{\"message_id\":\"0:1525033202269577%378826f2378826f2\"}]', 0, '2018-04-29 20:20:02', '2018-04-29 20:20:02', NULL),
(8, 29, 54, 'You have been added as subadmin', 2, '[\"13\"]', 1, '[{\"message_id\":\"0:1525039634874006%378826f2378826f2\"}]', 0, '2018-04-29 22:07:14', '2018-04-29 22:07:14', NULL),
(9, 29, 54, 'You have been added to a group', 2, '[\"13\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-05-01 14:05:54', '2018-05-01 14:05:54', NULL),
(10, 29, 54, 'You have been added to a group', 2, '[\"13\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-05-01 14:05:58', '2018-05-01 14:05:58', NULL),
(11, 29, 54, 'You have been added to a group', 2, '[\"13\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-05-01 14:06:07', '2018-05-01 14:06:07', NULL),
(12, 6, 27, 'You have been added to a group', 2, '[\"17\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-05-05 14:28:58', '2018-05-05 14:28:58', NULL),
(13, 6, 27, 'You have been added to a group', 2, '[\"17\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-05-05 14:29:09', '2018-05-05 14:29:09', NULL),
(14, 26, 53, 'You have been added to a group', 2, '[\"13\"]', 1, '[{\"message_id\":\"0:1525530579186150%378826f2378826f2\"}]', 0, '2018-05-05 14:29:39', '2018-05-05 14:29:39', NULL),
(15, 6, 27, 'You have been added to a group', 2, '[\"13\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-05-05 14:30:00', '2018-05-05 14:30:00', NULL),
(16, 26, 53, 'You have been added to a group', 2, '[\"13\"]', 1, '[{\"message_id\":\"0:1525530616830242%378826f2378826f2\"}]', 0, '2018-05-05 14:30:16', '2018-05-05 14:30:16', NULL),
(17, 6, 27, 'You have been added to a group', 2, '[\"13\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-05-05 14:30:26', '2018-05-05 14:30:26', NULL),
(18, 6, 27, 'You have been added to a group', 2, '[\"13\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-05-05 14:30:35', '2018-05-05 14:30:35', NULL),
(19, 6, 27, 'You have been added to a group', 2, '[\"13\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-05-05 14:30:40', '2018-05-05 14:30:40', NULL),
(20, 6, 27, 'You have been added to a group', 2, '[\"13\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-05-05 14:30:46', '2018-05-05 14:30:46', NULL),
(21, 6, 27, 'You have been added to a group', 2, '[\"13\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-05-05 14:30:52', '2018-05-05 14:30:52', NULL),
(22, 65, 26, 'You have been added to a group', 2, '[\"13\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-05-05 14:31:21', '2018-05-05 14:31:21', NULL),
(23, 65, 26, 'You have been added to a group', 2, '[\"13\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-05-05 14:31:27', '2018-05-05 14:31:27', NULL),
(24, 29, 54, 'You have been added to a group', 2, '[\"13\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-05-05 14:31:41', '2018-05-05 14:31:41', NULL),
(25, 26, 53, 'New Job Applier', 1, '[\"107\"]', 1, '[{\"message_id\":\"0:1525703246154150%378826f2378826f2\"}]', 0, '2018-05-07 14:27:26', '2018-05-07 14:27:26', NULL),
(26, 101, 78, 'New Job Applier', 1, '[\"156\"]', 1, '[{\"message_id\":\"0:1527430016262799%378826f2378826f2\"}]', 1, '2018-05-27 14:06:56', '2018-05-27 14:06:56', NULL),
(27, 77, 57, 'New Job Applier', 1, '[\"158\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-05-27 23:10:31', '2018-05-27 23:10:31', NULL),
(28, 77, 57, 'New Job Applier', 1, '[\"175\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-01 21:12:35', '2018-06-01 21:12:35', NULL),
(29, 111, 88, 'New Job Applier', 1, '[\"177\"]', 1, '[{\"message_id\":\"0:1528391737192579%378826f2378826f2\"}]', 0, '2018-06-07 17:15:37', '2018-06-07 17:15:37', NULL),
(30, 77, 57, 'New Job Applier', 1, '[\"178\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-08 01:53:42', '2018-06-08 01:53:42', NULL),
(31, 111, 88, 'New Job Applier', 1, '[\"176\"]', 1, '[{\"message_id\":\"0:1528422942020033%378826f2378826f2\"}]', 0, '2018-06-08 01:55:42', '2018-06-08 01:55:42', NULL),
(32, 107, 85, 'New Job Applier', 1, '[\"171\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-08 21:24:49', '2018-06-08 21:24:49', NULL),
(33, 111, 89, 'New Job Applier', 1, '[\"179\"]', 1, '[{\"message_id\":\"0:1528493096025240%378826f2378826f2\"}]', 0, '2018-06-08 21:24:56', '2018-06-08 21:24:56', NULL),
(34, 77, 57, 'New Job Applier', 1, '[\"175\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-08 21:24:59', '2018-06-08 21:24:59', NULL),
(35, 6, 27, 'You have been added to a group', 2, '[\"50\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-10 19:16:04', '2018-06-10 19:16:04', NULL),
(36, 6, 27, 'New Job Forwarded to you', 1, '[\"175\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-11 01:41:46', '2018-06-11 01:41:46', NULL),
(37, 12, 61, 'You have been added to a group', 2, '[\"50\"]', 1, '[{\"message_id\":\"0:1528681974346951%378826f2378826f2\"}]', 0, '2018-06-11 01:52:54', '2018-06-11 01:52:54', NULL),
(38, 29, 54, 'You have been added to a group', 2, '[\"50\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-11 12:56:15', '2018-06-11 12:56:15', NULL),
(39, 111, 91, 'New Job Applier', 1, '[\"181\"]', 1, '[{\"message_id\":\"0:1528722445320793%378826f2378826f2\"}]', 0, '2018-06-11 13:07:25', '2018-06-11 13:07:25', NULL),
(40, 77, 57, 'New Job Applier', 1, '[\"184\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-11 13:08:05', '2018-06-11 13:08:05', NULL),
(41, 111, 91, 'New Job Applier', 1, '[\"186\"]', 1, '[{\"message_id\":\"0:1528728556646314%378826f2378826f2\"}]', 0, '2018-06-11 14:49:16', '2018-06-11 14:49:16', NULL),
(42, 111, 91, 'New Job Applier', 1, '[\"187\"]', 1, '[{\"message_id\":\"0:1528728805113721%378826f2378826f2\"}]', 0, '2018-06-11 14:53:25', '2018-06-11 14:53:25', NULL),
(43, 77, 57, 'New Job Applier', 1, '[\"188\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-11 20:30:51', '2018-06-11 20:30:51', NULL),
(44, 111, 91, 'New Job Applier', 1, '[\"180\"]', 1, '[{\"message_id\":\"0:1528893055496711%378826f2378826f2\"}]', 0, '2018-06-13 12:30:55', '2018-06-13 12:30:55', NULL),
(45, 77, 57, 'New Job Applier', 1, '[\"188\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-13 12:34:59', '2018-06-13 12:34:59', NULL),
(46, 115, 93, 'New Job Applier', 1, '[\"190\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-13 15:32:17', '2018-06-13 15:32:17', NULL),
(47, 115, 93, 'New Job Applier', 1, '[\"190\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-13 15:55:21', '2018-06-13 15:55:21', NULL),
(48, 115, 93, 'New Job Applier', 1, '[\"191\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-13 15:59:17', '2018-06-13 15:59:17', NULL),
(49, 116, 94, 'New Job Applier', 1, '[\"192\"]', 1, '[{\"message_id\":\"0:1528924959592931%378826f2378826f2\"}]', 0, '2018-06-13 21:22:39', '2018-06-13 21:22:39', NULL),
(50, 29, 54, 'New Job Applier', 1, '[\"70\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-13 22:17:57', '2018-06-13 22:17:57', NULL),
(51, 115, 93, 'New Job Applier', 1, '[\"191\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-13 22:23:23', '2018-06-13 22:23:23', NULL),
(52, 29, 96, 'New Job Applier', 1, '[\"193\"]', 1, '[{\"message_id\":\"0:1529608485648469%378826f2378826f2\"}]', 0, '2018-06-21 19:14:45', '2018-06-21 19:14:45', NULL),
(53, 7, 97, 'New Job Applier', 1, '[\"195\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-21 19:35:35', '2018-06-21 19:35:35', NULL),
(54, 7, 97, 'New Job Forwarded to you', 1, '[\"195\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-21 19:36:46', '2018-06-21 19:36:46', NULL),
(55, 26, 81, 'New Job Forwarded to you', 1, '[\"195\"]', 1, '[{\"message_id\":\"0:1529609866656541%378826f2378826f2\"}]', 0, '2018-06-21 19:37:46', '2018-06-21 19:37:46', NULL),
(56, 29, 96, 'User: Hesham Ahmed has applied to the job title', 1, '[\"196\"]', 1, '[{\"message_id\":\"0:1529610283747131%378826f2378826f2\"}]', 0, '2018-06-21 19:44:43', '2018-06-21 19:44:43', NULL),
(57, 29, 96, 'User: Hesham Ahmed has applied to the job title', 1, '[\"198\"]', 1, '[{\"message_id\":\"0:1529610626885008%378826f2378826f2\"}]', 0, '2018-06-21 19:50:26', '2018-06-21 19:50:26', NULL),
(58, 29, 96, 'User: Hesham Ahmed has applied to the job title', 1, '[\"199\"]', 1, '[{\"message_id\":\"0:1529610783459781%378826f2378826f2\"}]', 0, '2018-06-21 19:53:03', '2018-06-21 19:53:03', NULL),
(59, 7, 97, 'You have been added to a group', 2, '[\"52\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-21 20:00:31', '2018-06-21 20:00:31', NULL),
(60, 7, 97, 'You have been added to a group', 2, '[\"52\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-21 20:16:48', '2018-06-21 20:16:48', NULL),
(61, 29, 96, 'You have been added to a group', 2, '[\"53\"]', 1, '[{\"message_id\":\"0:1529612521958049%378826f2378826f2\"}]', 0, '2018-06-21 20:22:01', '2018-06-21 20:22:01', NULL),
(62, 29, 96, 'User: Hesham Ahmed has applied to the job title', 1, '[\"201\"]', 1, '[{\"message_id\":\"0:1529612750582003%378826f2378826f2\"}]', 0, '2018-06-21 20:25:50', '2018-06-21 20:25:50', NULL),
(63, 29, 98, 'New Job Forwarded to you', 1, '[\"189\"]', 1, '[{\"message_id\":\"0:1529706951892677%378826f2378826f2\"}]', 0, '2018-06-22 22:35:51', '2018-06-22 22:35:51', NULL),
(64, 29, 98, 'You have been added to a group', 2, '[\"13\"]', 1, '[{\"message_id\":\"0:1529707046430171%378826f2378826f2\"}]', 0, '2018-06-22 22:37:26', '2018-06-22 22:37:26', NULL),
(65, 26, 81, 'New Job Forwarded to you', 1, '[\"201\"]', 1, '[{\"message_id\":\"0:1529758535878246%378826f2378826f2\"}]', 0, '2018-06-23 12:55:35', '2018-06-23 12:55:35', NULL),
(66, 26, 81, 'New Job Forwarded to you', 1, '[\"195\"]', 1, '[{\"message_id\":\"0:1529758813380812%378826f2378826f2\"}]', 0, '2018-06-23 13:00:13', '2018-06-23 13:00:13', NULL),
(67, 12, 61, 'New Job Forwarded to you', 1, '[\"191\"]', 1, '[{\"message_id\":\"0:1529778800864525%378826f2378826f2\"}]', 0, '2018-06-23 18:33:20', '2018-06-23 18:33:20', NULL),
(68, 12, 61, 'New Job Forwarded to you', 1, '[\"191\"]', 1, '[{\"message_id\":\"0:1529778820543909%378826f2378826f2\"}]', 0, '2018-06-23 18:33:40', '2018-06-23 18:33:40', NULL),
(69, 116, 94, 'Mohamed Salah has applied to a new job', 1, '[\"207\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-23 18:43:39', '2018-06-23 18:43:39', NULL),
(70, 116, 94, 'New Job Forwarded to you', 1, '[\"203\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-23 19:25:42', '2018-06-23 19:25:42', NULL),
(71, 6, 27, 'New Job Forwarded to you', 1, '[\"206\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-23 19:32:24', '2018-06-23 19:32:24', NULL),
(72, 115, 93, 'Mohammad Abdulaziz has applied to a new job', 1, '[\"191\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-24 20:42:36', '2018-06-24 20:42:36', NULL),
(73, 6, 27, 'New Job Forwarded to you', 1, '[\"207\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-24 21:42:04', '2018-06-24 21:42:04', NULL),
(74, 12, 61, 'New Job Forwarded to you', 1, '[\"195\"]', 1, '[{\"message_id\":\"0:1529876710015630%378826f2378826f2\"}]', 0, '2018-06-24 21:45:10', '2018-06-24 21:45:10', NULL),
(75, 12, 61, 'New Job Forwarded to you', 1, '[\"207\"]', 1, '[{\"message_id\":\"0:1529876753491019%378826f2378826f2\"}]', 0, '2018-06-24 21:45:53', '2018-06-24 21:45:53', NULL),
(76, 6, 27, 'New Job Forwarded to you', 1, '[\"206\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-24 23:03:29', '2018-06-24 23:03:29', NULL),
(77, 6, 27, 'New Job Forwarded to you', 1, '[\"203\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-24 23:03:41', '2018-06-24 23:03:41', NULL),
(78, 12, 61, 'New Job Forwarded to you', 1, '[\"206\"]', 1, '[{\"message_id\":\"0:1529881606315379%378826f2378826f2\"}]', 0, '2018-06-24 23:06:46', '2018-06-24 23:06:46', NULL),
(79, 6, 27, 'New Job Forwarded to you', 1, '[\"208\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-24 23:13:45', '2018-06-24 23:13:45', NULL),
(80, 6, 27, 'New Job Forwarded to you', 1, '[\"207\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-24 23:14:31', '2018-06-24 23:14:31', NULL),
(81, 115, 93, 'shady helmy has applied to a new job', 1, '[\"209\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-24 23:21:57', '2018-06-24 23:21:57', NULL),
(82, 115, 93, 'kamal serag has applied to a new job', 1, '[\"209\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-25 01:01:44', '2018-06-25 01:01:44', NULL),
(83, 116, 94, 'The Job has been deleted', 0, '[]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-25 02:41:18', '2018-06-25 02:41:18', NULL),
(84, 120, 103, 'The Job has been deleted', 0, '[]', 1, '[{\"message_id\":\"0:1529894478635733%378826f2378826f2\"}]', 0, '2018-06-25 02:41:18', '2018-06-25 02:41:18', NULL),
(85, 29, 102, 'New Job Forwarded to you', 1, '[\"195\"]', 1, '[{\"message_id\":\"0:1529958140443929%378826f2378826f2\"}]', 0, '2018-06-25 20:22:20', '2018-06-25 20:22:20', NULL),
(86, 77, 57, 'New Job Forwarded to you', 1, '[\"206\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-25 22:59:17', '2018-06-25 22:59:17', NULL),
(87, 115, 93, 'New Job Forwarded to you', 1, '[\"206\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-25 22:59:24', '2018-06-25 22:59:24', NULL),
(88, 29, 102, 'Mohamed Salah has applied to a new job', 1, '[\"206\"]', 1, '[{\"message_id\":\"0:1529968216308129%378826f2378826f2\"}]', 0, '2018-06-25 23:10:16', '2018-06-25 23:10:16', NULL),
(89, 6, 27, 'You have been added to a group', 2, '[\"45\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-25 23:18:49', '2018-06-25 23:18:49', NULL),
(90, 77, 57, 'New Job Forwarded to you', 1, '[\"210\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-25 23:25:42', '2018-06-25 23:25:42', NULL),
(91, 115, 93, 'New Job Forwarded to you', 1, '[\"210\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-25 23:25:47', '2018-06-25 23:25:47', NULL),
(92, 29, 102, 'Mohamed Salah has applied to a new job', 1, '[\"210\"]', 1, '[{\"message_id\":\"0:1529969184627824%378826f2378826f2\"}]', 0, '2018-06-25 23:26:24', '2018-06-25 23:26:24', NULL),
(93, 115, 93, 'S A has applied to a new job', 1, '[\"191\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-26 00:13:01', '2018-06-26 00:13:01', NULL),
(94, 29, 102, 'S A has applied to a new job', 1, '[\"210\"]', 1, '[{\"message_id\":\"0:1529971989065927%378826f2378826f2\"}]', 0, '2018-06-26 00:13:09', '2018-06-26 00:13:09', NULL),
(95, 29, 102, 'New Job Forwarded to you', 1, '[\"213\"]', 1, '[{\"message_id\":\"0:1529973291815883%378826f2378826f2\"}]', 0, '2018-06-26 00:34:51', '2018-06-26 00:34:51', NULL),
(96, 29, 102, 'New Job Forwarded to you', 1, '[\"211\"]', 1, '[{\"message_id\":\"0:1529973420803529%378826f2378826f2\"}]', 0, '2018-06-26 00:37:00', '2018-06-26 00:37:00', NULL),
(97, 116, 94, '  has applied to a new job', 1, '[\"207\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-26 19:17:51', '2018-06-26 19:17:51', NULL),
(98, 29, 102, '  has applied to a new job', 1, '[\"210\"]', 1, '[{\"message_id\":\"0:1530040770537591%378826f2378826f2\"}]', 0, '2018-06-26 19:19:30', '2018-06-26 19:19:30', NULL),
(99, 116, 94, '  has applied to a new job', 1, '[\"216\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-26 19:22:39', '2018-06-26 19:22:39', NULL),
(100, 6, 27, 'New Job Forwarded to you', 1, '[\"215\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-26 19:28:09', '2018-06-26 19:28:09', NULL),
(101, 116, 94, 'New Job Forwarded to you', 1, '[\"217\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-26 21:34:56', '2018-06-26 21:34:56', NULL),
(102, 113, 106, 'shady helmy has applied to a new job', 1, '[\"217\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-26 21:36:41', '2018-06-26 21:36:41', NULL),
(103, 7, 97, 'New Job Forwarded to you', 1, '[\"222\"]', 0, '[{\"error\":\"NotRegistered\"}]', 0, '2018-06-29 13:52:52', '2018-06-29 13:52:52', NULL),
(104, 7, 97, 'New Job Forwarded to you', 1, '[\"222\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-29 13:55:23', '2018-06-29 13:55:23', NULL),
(105, 77, 57, 'New Job Forwarded to you', 1, '[\"222\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-29 13:55:29', '2018-06-29 13:55:29', NULL),
(106, 6, 27, 'New Job Forwarded to you', 1, '[\"208\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-29 14:22:44', '2018-06-29 14:22:44', NULL),
(107, 7, 97, 'New Job Forwarded to you', 1, '[\"195\"]', 0, '[{\"error\":\"NotRegistered\"}]', 1, '2018-06-29 14:38:15', '2018-06-29 14:38:15', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `slug`, `description`, `deleted_at`, `updated_at`, `created_at`) VALUES
(1, 'About ijobar', 'en', 'I Jobar is an interactive platform designed specifically for users who have jobs in their company or in their field to share with Their friends are in the list of names where most of them are mostly in Your domain is registered in your phone contact list as a user Of the owners of companies, clients and business friends and these are the most people who deal with the user in the labor market and therefore are more aware of your abilities and your scientific and practical possibilities.\r\n\r\nTherefore, the application of ijobar works on several axes are as follows:\r\n1 - A brief profile, simple and easy user and the nature of his work.\r\n2. Possibility to add functionality easily if you are looking for an employee.\r\n3 - The possibility of applying for the job through the same application.\r\n4. Alert users from the list of names you have in your job status which may give you a very suitable job once you leave your job at any time.\r\n5 - The possibility of sending a job to a friend.\r\n6- Possibility of working in the same field of work.\r\n7 - Diversity of job status options in respect of your experience and your scientific and practical abilities when you leave a job between the option of \'free\' and is an option for those with high positions and the great experience and the aspiration to work for many companies ... The option \'wants work\' for new graduates and those who want to form New practical experiences and in need of suitable work for them.\r\n\r\nThen, the application of iJobar can as a user obtain the following:\r\n1 - You may get a very suitable job once you change your career in the application of iJobar and this is really wonderful.\r\n1. Do not miss a job that may be closer to you than you imagine and this will save you a lot of trouble.\r\n2 - As you are looking for a job you will get a job suitable for your abilities and your scientific and practical experience and this saves you some time and effort in the search for a suitable job.\r\n3 - As advertised for a job you will find an efficient employee for this job suitable for your business environment and the nature of your company or your origin.\r\n4 - As a user you can send the post to a friend may be suitable for this post.\r\n5. As a user, you can create business groups between your friends and hence more diverse business functions in your field.\r\n\r\n\r\n\r\nOur vision\r\nOur vision in iJobar is to be a good choice for the user looking for a job that suits his ambitions and the user who is looking for a competent employee suitable for his company or its origin.\r\n\r\nOur goal\r\nOne of the objectives of Egobar:\r\n1. Do not miss a job opportunity that may be close to the user.\r\n2 - benefit the user from the circle of acquaintances and friends of work to obtain a job suited to his ambitions.\r\n3 - To provide the time and effort of the user to obtain a suitable job has a material return to suit his own.\r\n4 - to find the user the appropriate job in his specially even in the most specialized disciplines, whatever this specialty rare or a few of those working in it.\r\n5. The society should benefit from all scientific and practical expertise and specialization and put all human energy in its proper place in order to achieve maximum benefit for society.', NULL, '2018-07-08 22:55:06', '2018-07-08 22:57:40'),
(2, 'عن آي جوبار', 'ar', 'آي جوبار هو منصة تفاعلية صممت خصيصا للمستخدمين الذين لديهم وظائف فى شركاتهم او فى مجال عملهم لمشاركتها مع\r\nأصدقائهم فى قائمة الأسماء حيث فى الأغلب معظم الذيين فى\r\nمجال عملك يكونون مسجليين فى قائمة الأسماء لديك كمستخدم\r\nمن أصحاب شركات وعملاء وأصدقاء عمل وهؤلاء هم اكثر الناس  الذين يتعامل معهم المستخدم فى سوق العمل وبالتالى هم اكثر معرفة بقدراتك وامكانياتك العلمية والعملية .\r\nلذلك تطبيق آي جوبار يعمل على عدة محاور هى كالتالى:\r\n1-ملف تعريفى مختصر,بسيط وسهل بالمستخدم وطبيعة عمله.\r\n2-امكانية إضافة وظيفة بسهولة ويسر إذا كنت تبحث عن موظف .\r\n3-إمكانية التقدم للوظيفة عن طريق التطبيق نفسه.\r\n4-تنبيه المستخدمين من قائمة الاسماء لديك بحالتك الوظيفة وهو ما قد يتيح لك وظيفة مناسبة جدا بمجرد تركك عملك فى اى وقت.\r\n5- إمكانية إرسال وظيفة لصديق.\r\n6-إمكانية عمل جروبات عمل فى نفس مجال عملك.\r\n7- تنوع خيارات الحالة الوظيفة احتراما لخبراتك  وقدراتك العلمية والعملية عند تركك وظيفة ما ما بين خيار انك\" حر\" وهو خيار لذوى المناصب الرفيعة والخبرات الكبيرة و المطلوبيين  للعمل لدى كثير من الشركات.... وخيار\" يريد عمل\" للخريجيين الجدد  والذيين يريدون تكوين خبرات عملية جديدة وفى حاجة الى عمل مناسب لهم. \r\n وبالتالى من تطبيق آي جوبار تستطيع كمستخدم أن تحصل على الآتى:\r\n1-قد تحصل على وظيفة مناسبة جدا بمجرد تغير حالتك الوظيفية فى تطبيق إيجوبار وهذا رائع حقا.\r\n1-ان لا تفوت فرصة عمل قد تكون قريبة منك أكثر مما تتخيل وهذا يوفر لك كثير من العناء.\r\n2-كونك تبحث عن وظيفة ستحصل على وظيفة مناسبة لقدراتك وخبراتك العلمية والعملية وهذا يوفر عليك بعض الوقت والجهد فى البحث عن وظيفة مناسبة.\r\n3-كمعلن عن وظيفة ستجد الموظف الكفء لهذه الوظيفة المناسب لبيئة عملك و طبيعة شركتك او منشئتك .\r\n4-كمستخدم تستطيع ان ترسل الوظيفة الى صديق اليك قد يكون مناسب لهذه الوظيفة . \r\n5- تستطيع كمستخدم ان تنشاء مجموعات عمل بين اصدقائك وبالتالى مزيد من وظائف العمل المتنوعة فى مجال عملك.\r\n\r\nرؤيتنا\r\nرؤيتنا فى آي جوبار أن نكون الخيار الجيد للمستخدم الباحث عن وظيفة تلائم طموحاته والمستخدم الذى يبحث عن موظف كفء مناسب لشركته أو مناشئته.\r\n\r\nهدفنا \r\nمن أهداف إيجوبار :\r\n1-أن لا نفوت فرصة عمل قد تكون قريبة من المستخدم .\r\n2- أستفادة المستخدم من دائرة معارفة وأصدقاء العمل فى الحصول على فرصة عمل تلائم طموحاته.\r\n3-توفير وقت وجهد المستخدم فى الحصول على وظيفة مناسبة له ذات عائد مادى يلائم تطلاعاته.\r\n4-أن يجد المستخدم الوظيفة المناسبة فى تخصصه حتى فى ادق التخصصات مهما كان هذا التخصص نادر أو قليل من يعملون فيه.\r\n5- ان يستفيد المجتمع من كل الخبرات والتخصصات العلمية والعملية ووضع كل طاقة بشرية فى مكانها المناسب بما يحقق الاستفادة القصوى للمجتمع .', NULL, '2018-07-08 22:55:06', '2018-07-08 22:57:40'),
(3, 'Privacy Policy', 'en', 'Privacy Statement\r\nWe appreciate your interest and your concerns about the privacy of your data on the Internet.\r\nThis policy is designed to help you understand the nature of the data we collect from you when\r\nyou installed ijobar App. and how we handle this personal data.\r\nBrowsing\r\nWe did not design this application to collect your personal data from your mobile phone or tablet\r\ndevice during your use of the application, but only the data provided by you will be used with\r\nyour knowledge and of your own free will.\r\nInternet Protocol (IP) address\r\nAnytime the application is used, the host server will register your IP address,\r\ndate and time of visit.\r\nNetwork surveys\r\nOur online surveys enable us to collect specific data such as the data required of you regarding\r\nyour view and feel about our application. Your feedback is of paramount importance and is\r\nappreciated as it enables us to improve the application level, and you are free to choose other\r\ndata.\r\nLinks to other sites on the Internet\r\nThe application may include links to other sites on the Internet. Or banners from other sites such\r\nas Google AdSens we are not responsible for the data collection practices of such sites you can\r\nsee the privacy and content policies for those sites accessed through any link within that app.\r\nDisclosure of information\r\nAt all times we will maintain the privacy and confidentiality of all personal data we receive.\r\nThis information will only be disclosed if required under any law or when we believe in good\r\nfaith that such action will be required or desirable to comply with the law or to defend or protect\r\nthe property rights of such application or its beneficiaries.\r\nData required performing transactions required by you\r\nWhen we need any data of your own, we will ask you to submit it of your own volition. This\r\ninformation will help us to contact you, improve the service provided by the application and\r\nimplement your requests wherever possible.\r\nThe data provided by you to any third party will not be sold for marketing without the prior\r\nconsent of you, provided that it is a collective data used for statistical purposes and research\r\nwithout including any data that may be used to introduce you.\r\n\r\nWhen you contact us\r\nAll data provided by you will be treated as confidential.\r\nThe data provided by you will be used to respond to all your inquiries, feedback or requests\r\nsubmitted to us by e-mail.\r\nModifications to the privacy policy and privacy of information\r\nWe reserve the right to modify the terms and conditions of the privacy policy and the privacy of\r\nthe information if necessary and when appropriate.\r\nThe amendments will be implemented here or on the main privacy policy page and you will be\r\nconstantly informed of the data we have obtained, how we will use it and who will provide it\r\nwith this data.\r\nFinally\r\nYour concerns about privacy and confidentiality are very important to us. We hope that this will\r\nbe achieved through this policy.', NULL, '2018-07-08 23:09:26', '2018-07-08 23:09:26'),
(4, 'سياسة الجصوصية', 'ar', 'الخصوصية وبيان سريّة المعلومات\r\nنقدر مخاوفكم واهتمامكم بشأن خصوصية بياناتكم على شبكة الإنترنت.\r\nلقد تم إعداد هذه السياسة لمساعدتكم في تفهم طبيعة البيانات التي نقوم بتجميعها منكم عند تنزيلكم تطبيق آي\r\nجوبار و كيفية تعاملنا مع هذه البيانات الشخصية.\r\nالتصفح\r\nلم نقم بتصميم هذا التطبيق من أجل تجميع بياناتك الشخصية من على هاتفك الجوال او جهازك اللوحى الخاص بك\r\nأثناءأثناء أستخدامك للتطبيق, وإنما سيتم فقط استخدام البيانات المقدمة من قبلك بمعرفتك ومحض إرادتك.\r\nعنوان بروتوكول شبكة الإنترنت (IP)\r\nفي أي وقت تستخد فيه التطبيق , سيقوم السيرفر المضيف بتسجيل عنوان بروتوكول شبكة الانترنت الخاص بك\r\nتاريخ ووقت الزيارة.(IP)\r\nعمليات المسح على الشبكة\r\nإن عمليات المسح التي نقوم بها مباشرة على الشبكة تمكننا من تجميع بيانات محددة مثل البيانات المطلوبة منك\r\nبخصوص نظرتك وشعورك تجاه التطبيق.تعتبر ردودك ذات أهمية قصوى , ومحل تقديرنا حيث أنها تمكننا من تحسين\r\nمستوى التطبيق, ولك كامل الحرية والإختيار البيانات الأخرى.\r\nالروابط بالمواقع الأخرى على شبكة الإنترنت\r\nقد يشتمل التطبيق على روابط بالمواقع الأخرى على شبكة الإنترنت. او علانات من مواقع اخرى مثل\r\nولا نعتبر مسئولين عن أساليب جمع البيانات من قبل تلك المواقع https://www.google.com/adsenseمثل\r\n, يمكنك الاطلاع على سياسات السرية والمحتويات الخاصة بتلك المواقع التي يتم الدخول إليها من خلال أي رابط ضمن\r\nهذا التطبيق.\r\nإفشاء المعلومات\r\nسنحافظ في كافة الأوقات على خصوصية وسرية كافة البيانات الشخصية التي نتحصل عليها. ولن يتم إفشاء هذه\r\nالمعلومات إلا إذا كان ذلك مطلوباً بموجب أي قانون أو عندما نعتقد بحسن نية أن مثل هذا الإجراء سيكون مطلوباً أو\r\nمرغوباً فيه للتمشي مع القانون , أو للدفاع عن أو حماية حقوق الملكية الخاصة بهذا التطبيق أو الجهات المستفيدة منه.\r\nالبيانات اللازمة لتنفيذ المعاملات المطلوبة من قبلك\r\nعندما نحتاج إلى أية بيانات خاصة بك , فإننا سنطلب منك تقديمها بمحض إرادتك. حيث ستساعدنا هذه المعلومات في\r\nالاتصال بك,تحسين الخدمة التى يقدمها التطبيق وتنفيذ طلباتك حيثما كان ذلك ممكنناً. لن يتم اطلاقاً بيع البيانات\r\nالمقدمة من قبلك إلى أي طرف ثالث بغرض تسويقها لمصلحته الخاصة دون الحصول على موافقتك المسبقة ما لم يتم\r\nذلك على أساس أنها ضمن بيانات جماعية تستخدم للأغراض الإحصائية والأبحاث دون اشتمالها على أية بيانات من\r\nالممكن استخدامها للتعريف بك.\r\nعند الاتصال بنا\r\nسيتم التعامل مع كافة البيانات المقدمة من قبلك على أساس أنها سرية . سيتم استخدام البيانات التي يتم تقديمها\r\nمن قبلك في الرد على كافة استفساراتك , ملاحظاتك , أو طلباتك المقدمه الينا من قبلك عن طريق البريد الألكترونى.\r\nالتعديلات على سياسة سرية وخصوصية المعلومات\r\nنحتفظ بالحق في تعديل بنود وشروط سياسة سرية وخصوصية المعلومات إن لزم الأمر ومتى كان ذلك ملائماً. سيتم\r\nتنفيذ التعديلات هنا او على صفحة سياسة الخصوصية الرئيسية وسيتم بصفة مستمرة إخطارك بالبيانات التي حصلنا\r\nعليها , وكيف سنستخدمها والجهة التي سنقوم بتزويدها بهذه البيانات.\r\nاخيرا\r\nإن مخاوفك واهتمامك بشأن سرية وخصوصية البيانات تعتبر مسألة في غاية الأهمية بالنسبة لنا. نحن نأمل أن يتم\r\nتحقيق ذلك من خلال هذه السياسة.', NULL, '2018-07-08 23:13:10', '2018-07-08 23:13:10');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `invited_id` int(11) DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int(11) NOT NULL DEFAULT '0',
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_verify_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_verify_status` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_work_from` timestamp NULL DEFAULT NULL,
  `current_work_to` timestamp NULL DEFAULT NULL,
  `region_id` int(11) NOT NULL DEFAULT '0',
  `country_id` int(11) NOT NULL DEFAULT '0',
  `city_id` int(11) NOT NULL DEFAULT '0',
  `company_updated_at` timestamp NULL DEFAULT NULL,
  `country_updated_at` timestamp NULL DEFAULT NULL,
  `region_updated_at` timestamp NULL DEFAULT NULL,
  `city_updated_at` timestamp NULL DEFAULT NULL,
  `title_updated_at` timestamp NULL DEFAULT NULL,
  `workfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workfieldother` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brief` text COLLATE utf8mb4_unicode_ci,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `scientific_qualifications` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `invited_id`, `first_name`, `last_name`, `email`, `age`, `mobile`, `other_mobile`, `mobile_verify_code`, `mobile_verify_status`, `title`, `company_name`, `current_work_from`, `current_work_to`, `region_id`, `country_id`, `city_id`, `company_updated_at`, `country_updated_at`, `region_updated_at`, `city_updated_at`, `title_updated_at`, `workfield`, `workfieldother`, `school`, `gender`, `brief`, `photo`, `status`, `scientific_qualifications`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, NULL, NULL, NULL, NULL, 0, '22222', NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-03-03 18:03:03', '2018-03-03 18:03:03', NULL),
(2, NULL, NULL, NULL, NULL, 0, '222221', NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-03-03 18:04:21', '2018-03-03 18:04:21', NULL),
(3, NULL, NULL, NULL, NULL, 0, '2222212', NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-03-03 18:06:05', '2018-03-03 18:06:05', NULL),
(4, NULL, NULL, NULL, NULL, 0, '6666666', NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-03-03 18:06:14', '2018-03-03 18:06:14', NULL),
(5, NULL, 'Mohamed', 'Salah', NULL, 0, '002001009429977', NULL, '1234', 1, 'Biomedical Engineer', 'Rehab Al-safwa', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Mindray Medison Application', NULL, 1, NULL, '2018-03-05 11:14:27', '2018-03-05 11:16:45', NULL),
(6, NULL, 'Mohamed', 'Salah', 'mohamedsalah054@zoho.com', 0, '00966546628911', NULL, '7851', 1, 'Application', 'Rehab Al-Safwa', '2009-04-19 01:05:16', '2018-04-20 01:05:24', 0, 966, 0, '2018-04-02 09:34:15', '2018-04-02 09:34:15', '2018-04-02 09:34:15', NULL, '2018-04-02 09:34:15', NULL, NULL, NULL, 'Male', 'Ultrasound (Mindray and Medison) Application', NULL, 4, 'Bachlor of Engineering', '2018-03-05 18:59:10', '2018-06-26 19:16:41', NULL),
(7, NULL, 'Hesham', 'Ahmed', 'hesham.abboud@gmail.com', 31, '00201223185749', NULL, '0025', 1, 'Product Manager', 'Bey2ollak', '2015-08-16 02:22:35', NULL, 0, 20, 0, '2018-06-21 20:29:13', '2018-06-21 20:29:13', '2018-06-21 20:29:13', NULL, '2018-06-21 20:29:13', NULL, NULL, NULL, 'Male', 'Riririririririririririri', NULL, 1, NULL, '2018-03-10 20:53:15', '2018-06-29 13:54:56', NULL),
(8, NULL, 'zz', 'z', 'z@h.s', 0, '002001067672720', NULL, '1234', 1, 'bj', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'nnnm', NULL, 3, NULL, '2018-03-10 21:12:30', '2018-04-26 16:07:10', NULL),
(9, NULL, 'Hesham', 'Abboud', NULL, 0, '002001223185746', NULL, '1234', 1, 'Engineer', 'Bey2ollak', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1234', NULL, 1, NULL, '2018-03-10 21:12:58', '2018-03-10 21:14:02', NULL),
(10, NULL, NULL, NULL, NULL, 0, '00201142833580', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-03-12 18:21:09', '2018-03-12 18:21:16', NULL),
(11, NULL, NULL, NULL, NULL, 0, '009660546628912', NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-03-12 23:00:11', '2018-03-12 23:00:11', NULL),
(12, NULL, 'Mohammad', 'Abdulaziz', NULL, 0, '00966500176113', NULL, '6156', 1, 'Systems Engineer', 'BTC', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Integration Engineer', NULL, 1, NULL, '2018-03-14 12:23:20', '2018-06-28 22:21:05', NULL),
(13, NULL, NULL, NULL, NULL, 0, '0020119849824', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-03-16 16:24:44', '2018-03-16 16:24:49', NULL),
(14, NULL, 'H', 'H', NULL, 0, '00201119849824', NULL, '1234', 1, 'pHp', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test', NULL, 1, NULL, '2018-03-16 16:25:22', '2018-03-16 16:26:10', NULL),
(15, NULL, 'Ahmed', 'Test', NULL, 0, '00201122334455', NULL, '1234', 1, 'job test', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'test cv', NULL, 1, NULL, '2018-03-16 20:03:25', '2018-04-02 19:18:30', NULL),
(16, NULL, 'Reda', 'Abbas', NULL, 0, '00201279695195', NULL, '1234', 1, 'Accountant', 'Shams', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Accountant chvjkbkb hxhcjvvjkb hcjcjvivkv uchcjvjvkb xyjcjvib yxucviiib vuivbobkkbbo ucjvjvkvkbkbb chhcvjjvvjjv jcjccjjcjv ucjcvjjvjv cijvjvjvkvkbkb ucucvujvjvjv hchcj h jvj cujcjcjc cjjcvjvjjvjvj hcjvjvjvjvjv jvjvjvjvjv jvjvjvvjjvjv hcjcvjjvjvjv jcjchvjvjvjv jvvjjvjvjvkb ivkb', NULL, 1, NULL, '2018-03-17 17:53:36', '2018-03-17 17:55:28', NULL),
(17, NULL, 'mahmoud', 'ramadan', NULL, 0, '002001064041779', NULL, '1234', 1, 'software engineer', 'androidv', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'gzhzbsnsndn', NULL, 1, NULL, '2018-03-20 08:18:08', '2018-03-20 08:33:22', NULL),
(18, NULL, 'attia', 'gamea', NULL, 0, '0126999969999', NULL, '', 0, 'dfggf', 'dfgf', NULL, NULL, 0, 0, 0, '2018-03-31 15:35:20', NULL, '2018-03-31 15:35:20', NULL, '2018-03-31 15:35:20', NULL, NULL, NULL, NULL, 'test', NULL, 1, NULL, '2018-03-20 20:36:37', '2018-04-13 13:17:28', NULL),
(19, NULL, 'aa', 'aa', NULL, 0, '002001066253101', NULL, '1234', 0, 'aa', 'aaa', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'bshsjjsjsjdjd', NULL, 1, NULL, '2018-03-21 08:33:52', '2018-04-02 18:41:33', NULL),
(20, NULL, NULL, NULL, NULL, 0, '009101066253102', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-03-21 15:43:58', '2018-03-21 15:44:03', NULL),
(21, NULL, NULL, NULL, NULL, 0, '009101066253101', NULL, '1234', 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-03-21 15:45:03', '2018-03-21 15:45:04', NULL),
(22, NULL, NULL, NULL, NULL, 0, '009101064041779', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-03-22 08:12:21', '2018-03-22 08:12:30', NULL),
(23, NULL, NULL, NULL, NULL, 0, '002012345978', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-03-23 16:22:02', '2018-03-23 16:22:07', NULL),
(24, NULL, 'Eslam', 'A.gwad', NULL, 0, '00201066253101', NULL, '1234', 1, 'Developer', 'aaa', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'aaa', NULL, 1, NULL, '2018-03-24 14:08:26', '2018-04-23 19:29:49', NULL),
(25, NULL, 'hoda', 'hoda', NULL, 0, '002001020192526', NULL, '1234', 1, 'ccc', 'ww', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'qqqqq', NULL, 0, NULL, '2018-03-27 09:09:48', '2018-03-27 09:10:59', NULL),
(26, NULL, 'aaa', 'bbb', 'attigd@ty.hff', 12, '00201019584283', '00966966123456123', '1251', 1, 'Gjjh', 'aaaaa', '2018-04-10 04:49:50', '2018-04-22 04:50:04', 0, 20, 0, NULL, '2018-05-27 19:06:28', '2018-05-27 19:06:28', NULL, '2018-05-24 10:30:09', 'aas', 'ffg', 'ssss', 'Female', 'hhhh', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/magazine-unlock-01-2.3.983-_abe2a717900d4c6aae388650693625001527157694360.jpg', 1, 'ehhd', '2018-03-27 18:39:16', '2018-06-23 14:06:53', NULL),
(27, NULL, NULL, NULL, NULL, 0, '002001019584283', NULL, '7842', 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-03-27 20:18:24', '2018-05-19 19:56:40', NULL),
(28, NULL, 'Hesham', 'Abboud', NULL, 0, '002001223185749', NULL, '1234', 1, 'CEO', 'Bey2ollak', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ana', NULL, 1, NULL, '2018-03-30 17:40:16', '2018-04-22 21:11:23', NULL),
(29, NULL, 'Sally', 'Mohamed', 'ss@ss.com', 949, '00201067672720', NULL, '5548', 1, 'Project Manager', 'ffg', '2018-04-17 12:14:29', '2018-04-20 12:14:32', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Female', 'Test gsvzbnzmz zbndndbxbnd dbdkdkdsm bend nb-egypt.com dnmdbdvdbdm dbjeklfjjf dhkdkfnfn ddkmdnd dhkdmر برميمثt', NULL, 4, NULL, '2018-03-30 18:18:49', '2018-06-29 14:35:05', NULL),
(30, NULL, NULL, NULL, NULL, 0, '201019584283', NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-03-30 20:42:44', '2018-03-30 20:42:44', NULL),
(31, NULL, NULL, NULL, NULL, 0, '0091556666555566', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-01 13:10:16', '2018-04-01 13:10:31', NULL),
(32, NULL, 'sal', 'moh', NULL, 0, '0091556668545454', NULL, '1234', 1, 'Manager', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'bxbxjxj bxnxjdjdn dbndkdk dbjdkd', NULL, 0, NULL, '2018-04-01 16:26:09', '2018-04-01 16:26:58', NULL),
(33, NULL, NULL, NULL, NULL, 0, '0020166253101', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-02 18:54:10', '2018-04-02 18:54:36', NULL),
(34, NULL, NULL, NULL, NULL, 0, '00200166253101', NULL, '1234', 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-02 18:54:20', '2018-04-02 18:54:21', NULL),
(35, NULL, 'test3', 'test3', NULL, 0, '002001067672722', NULL, '1234', 1, 'test3', 'worcbox', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'yucvuiv vuviviib vuvuivivib ucuccuvivi uccuucuv vuuv vuucvuuv cuuviviv vuvivivvi ucuccuiv cucuvuvu uccucuvu cuucvuuvvi vuvuvuvuviiv vuuvivivuvvivi vviivivibib vivivivviviiv uvuvuvuvuvuviv viivivivvivi uvivivivvi vuuvuvvu iviviviviv vuuvivvibi viivibbi vibiibbobobobo ibviibibbiib ivviivvibi viivivbibibo ivibibbobo viviivbiibib ivivviivvi biivivivvi. iviivivib ibibibvivivi viivivivivivivvi vuvuucvuvuvuiv vuvuvuuvvuivuvvuvi. uuvuvuvuv ivivuvuvviuvivvi uvuvvuvuivbi uvuvuv', NULL, 0, NULL, '2018-04-04 19:35:36', '2018-04-04 19:38:09', NULL),
(36, NULL, 'sal', 'dal', NULL, 0, '00201067676760', NULL, '1234', 1, 'sal', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'sal hjvog cuivviob cuucuciv cuivob viiviv viucuv ucucivh vuiviv ivuviv ivivivvi ivivig iviviv ivivg', NULL, 0, NULL, '2018-04-04 20:10:07', '2018-04-04 20:10:51', NULL),
(37, NULL, 'vy', 'tct', NULL, 0, '0020823838683938', NULL, '1234', 1, 'gvyuv', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'vb', NULL, 0, NULL, '2018-04-04 20:20:03', '2018-04-04 20:26:37', NULL),
(38, NULL, 'ssd', 'sss', NULL, 0, '0091686868868657', NULL, '1234', 1, 'ssa', 'ffgh', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'dhhdjfkg hdjfjfjf fhjfjfjf djjfjfjfkf jdjdjfjfjf djjdjfjf sukckclv', NULL, 0, NULL, '2018-04-05 15:55:25', '2018-04-05 15:57:09', NULL),
(39, NULL, 'aass', 'aaa', NULL, 0, '00201012345678', NULL, '1234', 1, 'aas', 'aasdf', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'aadf', NULL, 1, NULL, '2018-04-06 18:16:42', '2018-04-07 09:04:27', NULL),
(40, NULL, 'aaa', 'ett', NULL, 0, '00201012345677', NULL, '', 0, 'argt', 'afggs', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'cgh', NULL, 1, NULL, '2018-04-07 08:51:20', '2018-04-07 08:58:12', NULL),
(41, NULL, NULL, NULL, NULL, 0, '0020123385585', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-07 17:28:18', '2018-04-07 17:28:21', NULL),
(42, NULL, 'ahah', 'shdh', 'gag@hgh.jhh', 0, '0020123456123', NULL, '1234', 1, 'shhssj', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'sjhdhd', NULL, 3, NULL, '2018-04-07 17:36:20', '2018-04-09 18:27:09', NULL),
(43, NULL, 'dd', 'dd', NULL, 0, '0091687657755757', NULL, '1234', 1, 'fff', 'vvhj', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'cvbhhg', NULL, 0, NULL, '2018-04-07 19:05:06', '2018-04-07 19:06:11', NULL),
(44, NULL, 'ff', 'ff', 'f@ff.com', 0, '00918668242424', NULL, '1234', 1, 'fggh', 'dd', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'xgduuc chchhxyxyd xyydyddu dyydchuc udyfuf', NULL, 1, NULL, '2018-04-07 21:04:50', '2018-04-07 21:05:29', NULL),
(45, NULL, 'xvbx', 'zzz', 'gg@hh ss', 0, '0091676585686466', NULL, '1234', 1, 'vsbzjzj', 'vzbsnsnns', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'bxnxjxmxmx', NULL, 2, NULL, '2018-04-08 00:11:25', '2018-04-08 00:12:00', NULL),
(46, NULL, 'vvbb', 'vbbb', 'hg@gg.jj', 0, '0091855666888886', NULL, '1234', 1, 'hhjn', 'cvbb', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'bsnsssnms', NULL, 3, NULL, '2018-04-08 00:12:22', '2018-04-08 00:12:59', NULL),
(47, NULL, 'rr', 'ssd', 'rr@tt.vv', 0, '00918855588555', NULL, '1234', 1, 'fggh', 'tt', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'fghbvhvccg', NULL, 1, NULL, '2018-04-08 11:16:18', '2018-04-08 11:17:03', NULL),
(48, NULL, 'ff', 'gg', 'gg@gh.jj', 0, '00201067672722', NULL, '1234', 1, 'hbb', 'xff', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'hbnnnng', NULL, 1, NULL, '2018-04-08 16:45:02', '2018-04-08 16:46:36', NULL),
(49, NULL, 'add', 'dff', 'dff', 0, '0020123456124', NULL, '1234', 1, 'xfg', 'dgg', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'chhghh', NULL, 1, NULL, '2018-04-09 18:27:26', '2018-04-09 18:27:56', NULL),
(50, NULL, 'ahsh', 'gvb', 'aaa@hvv.nbb', 0, '0020123456456', NULL, '1234', 1, 'hvbh', 'dggg', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'cgggh', NULL, 1, NULL, '2018-04-09 18:36:41', '2018-04-09 18:44:51', NULL),
(51, NULL, 'ggvg', 'fgg', 'fgfgff', 0, '00201234567878', NULL, '1234', 1, 'fgggg', 'dghh', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'fghh', NULL, 1, NULL, '2018-04-09 18:45:12', '2018-04-09 18:45:42', NULL),
(52, NULL, 'ghgg', 'chgg', 'fhg', 0, '0020123456963', NULL, '1234', 1, 'fhh', 'chg', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ggcg', NULL, 3, NULL, '2018-04-09 18:58:49', '2018-04-09 19:00:12', NULL),
(53, NULL, 'dgv', 'xfg', 'fvv', 0, '0020123456741', NULL, '0714', 1, 'dfvg', 'edf', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'cvbbb', NULL, 1, NULL, '2018-04-09 19:13:06', '2018-05-22 22:54:38', NULL),
(54, NULL, NULL, NULL, NULL, 0, '0020123654159', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-09 19:21:30', '2018-04-09 19:24:56', NULL),
(55, NULL, 'asff', 'dfg', 'fgg@fyy.jhh', 14, '0020123456781', NULL, '1234', 1, 'dfg', 'xfggg', '2018-04-02 10:50:27', '2018-04-11 10:50:30', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'ggvvg', NULL, 1, 'ffggg', '2018-04-09 19:28:54', '2018-04-10 20:51:31', NULL),
(56, NULL, 'sal3', 'M', 'sal3@sal.com', 0, '00201067672723', NULL, '1234', 1, 'tester', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'vjkvkvkvkvkv', NULL, 3, NULL, '2018-04-13 10:19:45', '2018-04-23 14:33:30', NULL),
(57, NULL, NULL, NULL, NULL, 0, '002068900988855', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-13 10:30:56', '2018-04-13 10:31:03', NULL),
(58, NULL, NULL, NULL, NULL, 0, '0091555775283558', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-13 10:32:37', '2018-04-13 10:32:41', NULL),
(59, NULL, 'Attia', 'Gamea', 'Attia.gamea@gmail.com', 0, '00201019584283', NULL, '', 0, 'Android', 'Wett', '2018-04-14 02:15:55', '2018-04-14 02:15:57', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'Chhh', NULL, 1, NULL, '2018-04-13 14:49:24', '2018-04-20 19:05:04', NULL),
(60, NULL, 'se', 'dd', 'tf@ff.gf', 0, '00201067672726', NULL, '1234', 1, 'ffgh', 'xcf', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ctuvhbgg', NULL, 3, NULL, '2018-04-13 16:43:33', '2018-04-13 16:44:36', NULL),
(61, NULL, 'vv', 'gg', 'ff@gg.hg', 0, '00201067672729', NULL, '1234', 1, 'gccgvhhvhv', 'g cgg', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'chchhvhvuv cycyvu', NULL, 1, NULL, '2018-04-13 20:52:40', '2018-04-13 20:53:17', NULL),
(62, NULL, NULL, NULL, NULL, 0, '0020123456525', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-14 12:32:16', '2018-04-14 12:32:20', NULL),
(63, NULL, NULL, NULL, NULL, 0, '0020123456525', NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-14 12:32:16', '2018-04-14 12:32:16', NULL),
(64, NULL, 'Fgg', 'Xggg', 'Dtf@fyu.ihh', 0, '0020123456369', NULL, '7921', 1, 'Fyggghh', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Fhjgjhgg', NULL, 3, NULL, '2018-04-14 12:33:07', '2018-05-22 22:23:53', NULL),
(65, NULL, 'Ft', 'Ft', 'Fit@fhu.jgg', 0, '002010123456789', NULL, '1234', 1, 'Dygg', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cggg', NULL, 3, NULL, '2018-04-14 21:39:00', '2018-04-14 21:40:01', NULL),
(66, NULL, NULL, NULL, NULL, 0, '00204898959695', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-20 18:27:13', '2018-04-20 18:29:32', NULL),
(67, NULL, 'dd', 'ff', 'gg', 0, '00966889965688656', NULL, '1234', 1, 'ycycyv', 'hhc', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'dycuiv vjkvibih uvvuiv g88hh8 8g8g8g ibibibib ucuvucucucufuv', NULL, 1, NULL, '2018-04-22 11:07:14', '2018-04-22 11:11:48', NULL),
(68, NULL, 'Fgg', 'Gg5', 'Tyy', 0, '00201019586366', NULL, '1234', 1, 'Fyy', 'Fygg', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Cyyggu', NULL, 3, NULL, '2018-04-22 19:48:26', '2018-04-22 19:49:09', NULL),
(69, NULL, 'Chgg', 'Hggh', 'Yghh', 0, '0020125434868686', NULL, '1234', 1, 'Hghh', 'Dygg', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Hchhh', NULL, 1, NULL, '2018-04-22 19:53:08', '2018-04-22 19:53:38', NULL),
(70, NULL, 'Egheh', 'Geyd', 'Gdh', 0, '00204659898998', NULL, '1234', 1, 'Dhdhd', 'Fydy', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Dhhdh', NULL, 1, NULL, '2018-04-22 19:57:57', '2018-04-22 19:59:00', NULL),
(71, NULL, 'Tfgg', 'Fggg', 'Tf@rty.hyyy', 0, '00206589376494', NULL, '1234', 1, 'Ftygg', 'Fggg', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ftt', NULL, 1, NULL, '2018-04-22 20:24:24', '2018-04-22 20:25:39', NULL),
(72, NULL, 'Gshshs', 'Fdydy', 'Ggd@hjr.hgh', 0, '0020565997767697', NULL, '1234', 1, 'Dhdh', 'Fhfhfh', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Dhdhddh', NULL, 1, NULL, '2018-04-22 20:35:03', '2018-04-22 20:37:17', NULL),
(73, NULL, 'Ttfg', 'Fff', 'Fff@rttt.yggf', 0, '00209668252586', NULL, '1234', 1, 'Rtfggg', 'Fggghh', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Gghbhh', NULL, 1, NULL, '2018-04-22 20:38:46', '2018-04-22 20:39:34', NULL),
(74, NULL, 'ss', 'ss', 'ds', 0, '009665757383535', NULL, '1234', 1, 'gjvkv', 'dddd', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mmody910@gmail.com n jcgiog cjcufduduyd duuddufifiud xhhdys', NULL, 2, NULL, '2018-04-23 11:13:44', '2018-04-23 12:26:14', NULL),
(75, NULL, 'ss', 'mm', 'mm@mm.ss', 0, '00201067672725', NULL, '1234', 1, 'bh', 'vbn', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'bznzjjs dbhdjdjd dhjdjejd snddnndn dbdnnzn thanks dbdnnzn dbdnjd', NULL, 1, NULL, '2018-04-23 22:23:11', '2018-04-23 22:27:44', NULL),
(76, NULL, NULL, NULL, NULL, 0, '00205659656565', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-24 20:51:44', '2018-04-24 20:51:47', NULL),
(77, NULL, 'Mohamed', 'Salah', 'mohamedsalah054@zoho.com', 33, '009660546628911', NULL, '1234', 1, 'Technical Director', 'Rehab Al-Safwa Company', '2010-05-27 11:14:47', NULL, 0, 966, 0, '2018-04-26 16:03:10', '2018-06-01 21:39:34', '2018-04-26 16:03:10', NULL, '2018-04-26 16:03:10', 'Biomedical engineer', NULL, 'مدرسة العباسية الثانوية العسكرية', 'Male', 'Ultrasound Application and service\nUltrasound trianer\nconnect Dicome\nDemonstration \nUltrasound service', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/park icon1528391675418.png', 1, 'Bechloer of engineering', '2018-04-25 22:14:25', '2018-06-07 17:14:53', NULL),
(78, NULL, 'Attia', 'Aaa', 'Aa@qq.com', 0, '0020111111112', NULL, '1234', 1, '123', 'Dhddb', '2018-04-26 12:40:02', '2018-04-26 12:40:04', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'Dhddj', NULL, 1, NULL, '2018-04-26 10:37:01', '2018-04-26 10:40:11', NULL),
(79, NULL, '123', 'Dgdhdh', 'Dhd@hf.jbdd', 12, '0020111111113', NULL, '1234', 1, 'Ajdbdb', 'Hrjeh', '2018-04-26 12:55:04', '2018-04-26 12:55:06', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'Schssh', NULL, 1, 'rjdbd', '2018-04-26 10:47:53', '2018-04-26 11:12:06', NULL),
(80, NULL, NULL, NULL, NULL, 0, '00null', NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-26 10:55:59', '2018-04-26 10:55:59', NULL),
(81, NULL, NULL, NULL, NULL, 0, '0020894994979894', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-26 14:07:22', '2018-04-26 14:07:25', NULL),
(82, NULL, NULL, NULL, NULL, 0, '00201067672770', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-26 16:06:28', '2018-04-26 16:06:31', NULL),
(83, NULL, NULL, NULL, NULL, 0, '00201067672420', NULL, '1234', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-04-26 16:07:37', '2018-04-26 16:07:40', NULL),
(84, NULL, 'لاا', 'Gvf', 'Fuh@fhh.hgg', 0, '0020235698865666', NULL, '1234', 1, 'Gugf', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Hfguj', NULL, 3, NULL, '2018-04-26 21:48:46', '2018-04-26 21:49:12', NULL),
(85, NULL, 'Edfh', 'Fty', 'Fgf@fgh.hgg', 0, '0020123456852', NULL, '1234', 1, 'Fgh', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Fghh', NULL, 3, NULL, '2018-04-26 21:51:03', '2018-04-26 21:51:27', NULL),
(86, NULL, 'mahmoud', 'sallam', 'm.sallam@worcbox.com', 0, '00201275922279', NULL, '5571', 1, 'project Manager', 'rrudjfigig', NULL, NULL, 0, 20, 0, '2018-05-23 12:45:30', '2018-05-23 12:45:30', '2018-05-23 12:45:30', NULL, NULL, NULL, NULL, NULL, NULL, 'hssjsj dbdjkdkd 0\nTracking, Track Parcels, Packages, Shipments | DHL Express Tracking\n\nwww.dhlegypt.com › express › tracking\n\nDHL Express tracking - track a parcel, track a package, track shipments and check shipment delivery status online. Track parcels and packages now.\n\nDHL Tracking\n\nwww.dhl.com › express › tracking\n\nNo information is available for this page.\n\nLearn why\n\nDHL | Tracking Tools | English\n\nwww.dhl.com › express › tracking_tools\n\nDHL\'s express tracking tools offer you the latest shipment information, in real-time, direct to your PC, mobile phone or handheld device. They are available to all DHL customers, ...\n\nDHL | Tracking FAQs | English\n\nwww.dhl.com › tracking › tracking_faq\n\nQuick answers to common DHL Express tracking questions.\n\nGlobal Logistics - International Shipping | DHL Home | Egypt - DHL Express\n\nhttps://www.logistics.dhl › eg-en\n\nDHL connects people in over 220 countries and territories worldwide. Driven by the power of more than 340,000 employees, we deliver integrated services and tailored solutions for ...\n\nTracking | DHL | Australia - DHL Express\n\nhttps://www.logistics.dhl › au-en › home\n\nContact Us · Portal Login · Australia; EN; Search · Select Country · Australia Select Country. EN. Search. Menu. DHL Australia · All Products & Solutions. Back; All Products & Solutions ...\n\nDHL Express Tracking - AfterShip\n\nhttps://www.aftership.com › couriers › dhl\n\nEnter tracking number to track DHL Express shipments and get delivery status online. Contact DHL Express and get REST API docs.\n\nTrack & Trace | DHL Parcel\n\nhttps://www.dhlparcel.nl › receiving › tra...\n\nTrace your parcel. Please enter your tracking code and your postal code for the current status of your parcel ...\n\nDHL EXPRESS TRACKING | Parcel Monitor\n\nhttps://www.parcelmonitor.com › track-d...\n\nParcel Monitor for DHL Express enables you to check for real-time updates for all your parcels on one user-friendly webpage with just your tracking number. DHL Express is a ...\n\nDHL Global Mail Tracking - DHL eCommerce Tracking\n\nhttps://webtrack.dhlglobalmail.com › ...\n\nDHL eCommerce Has the Answers. When will my tracking information appear? You should see tracking events within 24-48 hours after your package has been processed in our ...\n\nPEOPLE ALSO SEARCH FOR\n\nsupply chain organizations\n\nDHL Express\n\nUnited Parcel Service\n\nDHL Supply Chain\n\nDeutsche Post\n\nDHL Global Forwarding\n\nMore results\n\nFeedback\n\nMore results\n\nRELATED SEARCHES\n\ndhl tracking international\n\ndhl tracking india\n\ndhl tracking number format\n\ndhl tracking usa\n\ndhl waybill tracking\n\ndhl global tracking\n\ndhl tracking uk\n\ndhl tracking germany\n\nEgypt\n\nRawd Al Farag - From your Internet address - Learn more\n\nTerms\nd', NULL, 1, NULL, '2018-05-07 13:51:51', '2018-05-23 12:45:30', NULL),
(87, NULL, 'Gg', 'Fh', 'G@fhu.ugg', 0, '0020147258369', NULL, '7467', 1, 'Fyyg', 'Tyyy', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Fygchu', NULL, 1, NULL, '2018-05-08 06:48:09', '2018-05-22 20:25:42', NULL),
(88, NULL, NULL, NULL, NULL, 0, '00201116732526', NULL, '6113', 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-05-19 19:54:39', '2018-05-19 19:54:40', NULL),
(89, NULL, NULL, NULL, NULL, 0, '00201117773434', NULL, '5597', 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-05-19 19:58:01', '2018-05-19 19:58:01', NULL),
(90, NULL, 'Aaaa', 'Adhdh', 'Ahah@gh.ij', 0, '0020123456782', NULL, '3358', 1, 'Qrwysu', '11', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '1234567890', NULL, 1, NULL, '2018-05-21 23:18:48', '2018-05-21 23:19:33', NULL),
(91, NULL, '123', 'Fgh', 'Ghh', 0, '0020123456987', NULL, '4591', 1, 'Ghh', 'Fftt', NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ghuh', NULL, 1, NULL, '2018-05-22 20:10:16', '2018-05-22 20:11:34', NULL),
(92, NULL, 'Fhhh', 'Hgh', 'Gghj@hj.jhh', 0, '0020123456147', NULL, '1821', 1, 'Hvhj', 'Guh', '2018-05-08 10:27:25', '2018-05-22 10:27:28', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'Gjhh', NULL, 1, NULL, '2018-05-22 20:27:07', '2018-05-22 22:54:10', NULL),
(93, NULL, NULL, NULL, NULL, 0, '0020123456321', NULL, '9454', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-05-22 22:24:11', '2018-05-22 22:24:16', NULL),
(94, NULL, NULL, NULL, NULL, 0, '0020123789456', NULL, '4024', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-05-22 22:54:57', '2018-05-22 22:55:03', NULL),
(95, NULL, 'اع', 'ااا', NULL, 0, '00201222213564', NULL, '4992', 1, 'رهلهى', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'ترخا', NULL, 2, NULL, '2018-05-22 23:48:59', '2018-06-29 14:20:56', NULL),
(96, NULL, '6dufugig', 'yxucigb', NULL, 0, '00966343535646868', NULL, '0855', 1, '7f8gigig', 'ucjckblb', '2018-05-09 02:59:31', '2018-05-31 02:59:34', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'uvugug8h', NULL, 3, NULL, '2018-05-23 12:59:00', '2018-05-23 13:00:00', NULL),
(97, NULL, 'cff', 'ff', NULL, 0, '0096655555588888', NULL, '2158', 1, 'ggb', 'yyxyc', '2018-05-16 12:02:40', '2018-05-19 12:02:42', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'chigigho cjjcjcjcjc cjjxhxhxux ciuxhxjcjcjc hzhxhxuxuc xhhxhxhxjc jcjckvkvvk jcciiciv cjjcjcc ciififig icicic jcicicic cjjcjcjcjc jcicicic icigigog icigivov viigoh', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/temp16571735161527159589795.jpg', 1, NULL, '2018-05-24 10:01:38', '2018-05-24 11:00:03', NULL),
(98, NULL, 'tt', '5cc5', NULL, 0, '009665805822850', NULL, '4303', 1, 'tcv5vt', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'y  th  h', NULL, 3, NULL, '2018-05-25 09:20:34', '2018-05-25 09:20:50', NULL),
(99, NULL, 'yhxyx', 'yxyxyx', NULL, 0, '009666858588588', NULL, '8896', 1, 'g hchvjv', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'cufufuyf cicucuuc icucuc cuucucucuc icuxuc', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/20180524_0249481527257528965.jpg', 3, NULL, '2018-05-25 14:10:28', '2018-05-25 14:12:12', NULL),
(100, NULL, 'cgg', 'ghy', NULL, 0, '00966055005505058', NULL, '8806', 1, 'bbbb', 'ahhh bb', '2018-05-09 04:12:56', '2018-05-26 04:12:59', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'vvbh', NULL, 3, NULL, '2018-05-25 14:12:34', '2018-05-25 14:13:21', NULL),
(101, NULL, 'g t t', 'f t', NULL, 0, '009668228505028', NULL, '9267', 1, 'f  t t', 'vuuvuv', '2018-05-16 04:16:56', '2018-05-31 04:16:58', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'y yvyv', NULL, 1, NULL, '2018-05-25 14:15:47', '2018-05-25 14:16:59', NULL),
(102, NULL, 'Df', 'Fgg', 'cggg@gh.hgg', 0, '0020123456951', NULL, '3251', 1, 'Fhhg', '11', '2018-05-15 01:14:48', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'Fhhh', NULL, 1, NULL, '2018-05-28 23:14:28', '2018-05-28 23:43:09', NULL),
(103, NULL, 'sbkssk', 'xxz', NULL, 0, '009669999999855', NULL, '9265', 1, 'zz', 'ss', '2018-05-17 01:55:52', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'zbnznsmsmsm', NULL, 1, NULL, '2018-05-30 23:54:44', '2018-05-30 23:55:59', NULL),
(104, NULL, 'Gg@gg.hh', 'g yvuv', NULL, 0, '009665082283860', NULL, '9818', 1, 'yy', 'ghvj', '2018-05-16 01:59:16', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'vuvujb', NULL, 1, NULL, '2018-05-30 23:58:59', '2018-05-30 23:59:20', NULL),
(105, NULL, NULL, NULL, NULL, 0, '0020123456234', NULL, '3902', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-05-31 07:12:10', '2018-05-31 07:12:14', NULL),
(106, NULL, 'Aaa', 'Fgy', NULL, 0, '0020123456351', NULL, '8532', 1, 'Fyy', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Fgyy', NULL, 1, NULL, '2018-05-31 07:16:15', '2018-05-31 20:58:59', NULL),
(107, NULL, 'vg', 'gg', NULL, 0, '0096688888552880', NULL, '3442', 1, 'vv', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'vhhnh', NULL, 1, NULL, '2018-05-31 09:01:03', '2018-05-31 09:01:47', NULL),
(108, NULL, NULL, NULL, NULL, 0, '0020123456489', NULL, '3560', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-05-31 09:11:35', '2018-05-31 09:11:39', NULL),
(109, NULL, NULL, NULL, NULL, 0, '0020123426351', NULL, '9621', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-05-31 20:49:03', '2018-05-31 20:49:13', NULL),
(110, NULL, 'ff', 'cf', NULL, 0, '0020106767272720', NULL, '9067', 1, 'manager', 'worcbox', '2018-06-01 12:57:35', '2018-06-30 12:57:37', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'yvvyub cuucvuivih ucuvivbi ucivigug ucucucug', NULL, 1, NULL, '2018-05-31 22:57:06', '2018-05-31 22:57:47', NULL),
(111, NULL, 'Shady', 'Helmy', 'shady@park.com.sa', 35, '009660565720839', '009660565720839', '3174', 1, 'Mechanical Engineer & solar', 'Park energy', '2017-02-01 05:25:01', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 'mechanical', 'audit energu', NULL, 'Male', 'mechanical engineer and renewable energy engineer to make saving energy audit energy', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/black-r1-57841528391903049.jpg', 4, NULL, '2018-06-06 13:27:17', '2018-06-13 15:25:22', NULL),
(112, NULL, NULL, NULL, NULL, 0, '009661019584283', NULL, '9868', 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-06-09 22:46:33', '2018-06-09 22:46:38', NULL),
(113, NULL, NULL, NULL, NULL, 0, '+966546628911', NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 966, 0, NULL, '2018-06-27 12:12:28', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, '2018-06-09 22:51:16', '2018-06-27 12:12:28', NULL),
(114, NULL, NULL, NULL, NULL, 0, '+201019584283', NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-06-09 22:52:07', '2018-06-09 22:52:07', NULL),
(115, NULL, 'Mohamed', 'Salah', NULL, 0, '009665466289411', NULL, '8800', 1, 'Biomedical engineer', 'Rehab Al-Safwa Co.', '2015-06-13 03:26:04', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ultrasound Application\nUltrasound service\nX-RAY mentineance', NULL, 2, NULL, '2018-06-13 12:24:56', '2018-06-25 00:24:45', NULL),
(116, NULL, 'shady', 'helmy', 'shady@park.con.sa', 35, '00966565720839', '00966565720839', '3376', 1, 'mechnical engineer', 'park energy', '2017-02-01 05:54:41', NULL, 0, 966, 0, NULL, '2018-06-13 15:56:11', NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'hshsjsodbdksn hdjbs isisvs zksigs', NULL, 1, NULL, '2018-06-13 15:54:06', '2018-06-13 15:56:38', NULL),
(117, NULL, 'vg', 'hh', NULL, 0, '00966561779934', NULL, '6018', 1, 'vh', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'vhj', NULL, 3, NULL, '2018-06-20 06:52:57', '2018-06-29 14:25:10', NULL),
(118, NULL, NULL, NULL, NULL, 0, '009660561779934', NULL, '1348', 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-06-20 06:54:35', '2018-06-20 06:54:36', NULL),
(119, NULL, NULL, NULL, NULL, 0, '00201019548283', NULL, '4919', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-06-23 14:06:15', '2018-06-23 14:06:24', NULL),
(120, NULL, 'kamal', 'serag', 'ksa_serag@yahoo.com', 30, '002001001882649', NULL, '5040', 1, 'biomedical engineer', 'gamma trade', '2018-01-01 02:43:43', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 'sales and maintenance engineer', 'biomedical engineer', NULL, 'Male', 'I\'m kamal serag graduated from faculty of electronic engineering menofia University at 2010, works as biomedical engineer after graduation, worked at s s c  from 2011 to 2_2014, I tech from 6-2014 to 12-2017, and now in gamma trade, \nmy experience at maintenance of medical devices like (lab devices, I c u devices) and now work as sales and maintenance \nI am training in China for lab devices', NULL, 3, NULL, '2018-06-25 00:43:09', '2018-06-25 01:09:17', NULL),
(121, NULL, 'S', 'A', NULL, 0, '00200106767272', NULL, '7473', 1, 'P', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'working', NULL, 1, NULL, '2018-06-26 00:06:14', '2018-06-26 00:07:08', NULL),
(122, NULL, NULL, NULL, NULL, 0, '00249924595046', NULL, '5442', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-06-26 08:47:23', '2018-06-26 08:48:01', NULL),
(123, NULL, 'x', 'z', NULL, 0, '00966009660546628', NULL, '6305', 1, 'z', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'xx', NULL, 3, NULL, '2018-06-29 13:12:52', '2018-06-29 13:13:14', NULL),
(124, NULL, 'اسم', 'عربي', NULL, 0, '0020123456115', NULL, '4300', 1, 'صصصصث', 'لات', '2018-06-20 03:53:25', '2018-06-30 03:53:28', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, 'ترهل', 'خاخاحا', NULL, 'Male', 'لا يوجد', NULL, 2, NULL, '2018-06-29 13:47:49', '2018-06-29 13:55:05', NULL),
(125, NULL, NULL, NULL, NULL, 0, '00201097972720', NULL, '4973', 1, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-06-29 14:05:43', '2018-06-29 14:05:48', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `profile_token`
--

CREATE TABLE `profile_token` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile_id` int(11) NOT NULL DEFAULT '0',
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_type` tinyint(4) NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profile_token`
--

INSERT INTO `profile_token` (`id`, `profile_id`, `token`, `device_type`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 6, 'fR-FNz88hos:APA91bFAwoTESoIipoNzzdITmYbco2sLKFzp7OaiD4TgP7y6bGlOttXZP2ieXLCNBg6YeYOqNNXYvDQfpSR5-Ww_CYaCWTMLDhZU-wDxf8twnVnVm7a9PpIXTnPqGSHeO8NuGvlpMYuO', 1, 0, '2018-04-06 16:53:45', '2018-04-06 16:53:45', NULL),
(2, 24, 'eDORjaQpHpk:APA91bEp63wB6aphfgOKiY5NTUH5E2kyaa2TPgBNbsx3ibVJyJfC-m3gWEbWeKYNIEIsxC_gU16zlcpfOFpryX535kMQRNeXwjm610Ad2EfMrd-Q1OJygzerrjQOCErm6Kj-vynujem6', 1, 0, '2018-04-06 17:29:45', '2018-04-06 17:29:45', NULL),
(3, 18, 'ddkarq3OHn4:APA91bHEHatvOah4ujInv3lMb4WMXVi18XOxoGGBmdhb90VjnMC3jJaVcNd6BBA_tbPW7t2ibD9Hl1uORxoPJoMbQH2aATlcfpD4qLIRBjLI7FBAyJK3GeKQMcOzL7vA4kQHGI5aq-SM', 1, 0, '2018-04-06 17:34:11', '2018-04-06 17:34:11', NULL),
(4, 28, 'f9v9DEzszq4:APA91bH5P0ar-eJMZsCwW47qAqfFzdLZlVNOBH3htD7ilPaovpflEa_NLXIAUCldW26ogvyL9RMpYxB_5IOkfVFOx31e-EW375IXfm8TaUD-rpZ2nSl38oUa-WsTJRDgSq6vzYoq6MIE', 1, 0, '2018-04-07 04:03:32', '2018-04-07 04:03:32', NULL),
(5, 39, 'ddkarq3OHn4:APA91bHEHatvOah4ujInv3lMb4WMXVi18XOxoGGBmdhb90VjnMC3jJaVcNd6BBA_tbPW7t2ibD9Hl1uORxoPJoMbQH2aATlcfpD4qLIRBjLI7FBAyJK3GeKQMcOzL7vA4kQHGI5aq-SM', 1, 1, '2018-04-07 08:51:02', '2018-04-07 08:51:02', NULL),
(6, 40, 'ddkarq3OHn4:APA91bHEHatvOah4ujInv3lMb4WMXVi18XOxoGGBmdhb90VjnMC3jJaVcNd6BBA_tbPW7t2ibD9Hl1uORxoPJoMbQH2aATlcfpD4qLIRBjLI7FBAyJK3GeKQMcOzL7vA4kQHGI5aq-SM', 1, 1, '2018-04-07 08:54:22', '2018-04-07 08:54:22', NULL),
(7, 42, 'ddkarq3OHn4:APA91bHEHatvOah4ujInv3lMb4WMXVi18XOxoGGBmdhb90VjnMC3jJaVcNd6BBA_tbPW7t2ibD9Hl1uORxoPJoMbQH2aATlcfpD4qLIRBjLI7FBAyJK3GeKQMcOzL7vA4kQHGI5aq-SM', 1, 1, '2018-04-07 17:37:11', '2018-04-07 17:37:11', NULL),
(8, 43, 'dsMxDzXUGGw:APA91bFrrvskqb-Vf-VQ3ijx9434bFj64aGfi719VCbHZ2HCm3RhbGwWNv-BLV2OiIIX-YGCabzOydYBbuuok4J3t4Oqus-x7oEv6jEWwxj7D4akWl4PL8QNky_xqi-B3yxH4rCIzYS_', 1, 1, '2018-04-07 20:42:09', '2018-04-07 20:42:09', NULL),
(9, 44, 'cNKvLqjaaQo:APA91bH4aiky9o-JfaxJj4qjXY-o97HULAlzWCPCtf8B5Wu4pWtkGuMKL3kkbNHhv1G3J_m6MVAiQPnFPno-AvyiFXsNE1-RRdWosL2SJdaUfIBpJ_83DouYFa7yOr8mhH0GPy3iPuee', 1, 1, '2018-04-07 21:05:37', '2018-04-07 21:05:37', NULL),
(10, 29, 'eLDTPL9Ga8M:APA91bGy_dwCUMCNDLicnX2N3AwS7gLiuH-Cgqm4GdONfzIwwnV1t85U-b5vHJC2ZTwZfJ0xeqOACi7QGRsLWKcUwt-UAkBc3alHm38GvpHvjFB1-eLUqI4T06252tr4g-oLbbwVVlU1', 1, 0, '2018-04-08 11:17:56', '2018-04-08 11:17:56', NULL),
(11, 28, 'cNKvLqjaaQo:APA91bH4aiky9o-JfaxJj4qjXY-o97HULAlzWCPCtf8B5Wu4pWtkGuMKL3kkbNHhv1G3J_m6MVAiQPnFPno-AvyiFXsNE1-RRdWosL2SJdaUfIBpJ_83DouYFa7yOr8mhH0GPy3iPuee', 1, 0, '2018-04-08 12:35:15', '2018-04-08 12:35:15', NULL),
(12, 50, 'ddkarq3OHn4:APA91bHEHatvOah4ujInv3lMb4WMXVi18XOxoGGBmdhb90VjnMC3jJaVcNd6BBA_tbPW7t2ibD9Hl1uORxoPJoMbQH2aATlcfpD4qLIRBjLI7FBAyJK3GeKQMcOzL7vA4kQHGI5aq-SM', 1, 1, '2018-04-09 18:44:52', '2018-04-09 18:44:52', NULL),
(13, 52, 'ddkarq3OHn4:APA91bHEHatvOah4ujInv3lMb4WMXVi18XOxoGGBmdhb90VjnMC3jJaVcNd6BBA_tbPW7t2ibD9Hl1uORxoPJoMbQH2aATlcfpD4qLIRBjLI7FBAyJK3GeKQMcOzL7vA4kQHGI5aq-SM', 1, 1, '2018-04-09 19:00:24', '2018-04-09 19:00:24', NULL),
(14, 55, 'ddkarq3OHn4:APA91bHEHatvOah4ujInv3lMb4WMXVi18XOxoGGBmdhb90VjnMC3jJaVcNd6BBA_tbPW7t2ibD9Hl1uORxoPJoMbQH2aATlcfpD4qLIRBjLI7FBAyJK3GeKQMcOzL7vA4kQHGI5aq-SM', 1, 1, '2018-04-09 21:51:39', '2018-04-09 21:51:39', NULL),
(15, 56, 'd_QpUmOrSV4:APA91bH3z4gAEb--dDUgpE6qE_JhGsQXXpVMZKJR8G3-Y7-pr80kUAnaXo1KjR6uSw36uhRkpkv7yE2SzoyV-BZ5PhxQio90PH8wwCW2uM1UZiSEAMbhs4tHTR2EqRTB_PzU-RKjHj4O', 1, 0, '2018-04-13 10:29:19', '2018-04-13 10:29:19', NULL),
(16, 57, 'd_QpUmOrSV4:APA91bH3z4gAEb--dDUgpE6qE_JhGsQXXpVMZKJR8G3-Y7-pr80kUAnaXo1KjR6uSw36uhRkpkv7yE2SzoyV-BZ5PhxQio90PH8wwCW2uM1UZiSEAMbhs4tHTR2EqRTB_PzU-RKjHj4O', 1, 1, '2018-04-13 10:32:21', '2018-04-13 10:32:21', NULL),
(17, 58, 'd_QpUmOrSV4:APA91bH3z4gAEb--dDUgpE6qE_JhGsQXXpVMZKJR8G3-Y7-pr80kUAnaXo1KjR6uSw36uhRkpkv7yE2SzoyV-BZ5PhxQio90PH8wwCW2uM1UZiSEAMbhs4tHTR2EqRTB_PzU-RKjHj4O', 1, 1, '2018-04-13 10:35:16', '2018-04-13 10:35:16', NULL),
(18, 29, 'fwW7Mop67Ik:APA91bGJCqZBVQtwEYjJl5rCRkuhzQg4RkWpiE-VtYCHZhCDRpLX0GZRDclqWbj7S3xTn1sOZHZB9UUnPesO9Gkyd7gQGJj87Ja_UAtN47My1rOoqIQmtyDdguMAgmXd644pN3VDFCSO', 1, 0, '2018-04-13 10:45:16', '2018-04-13 10:45:16', NULL),
(19, 18, 'dT5RbL82qhI:APA91bE53Oy1cZUW0c8ovtXAc_w8-xi_Jo3LZ7Bklze8sjOLADfO65rn7goxG9AzJc8F_oKbFE8pLxHr7jmTCRFychSKL7qga9eMxoNwAkOXU_d7Ybxiq_EOuFuiEEfxj7BX5bPcjRh0', 1, 1, '2018-04-13 12:37:03', '2018-04-13 12:37:03', NULL),
(20, 59, 'dT5RbL82qhI:APA91bE53Oy1cZUW0c8ovtXAc_w8-xi_Jo3LZ7Bklze8sjOLADfO65rn7goxG9AzJc8F_oKbFE8pLxHr7jmTCRFychSKL7qga9eMxoNwAkOXU_d7Ybxiq_EOuFuiEEfxj7BX5bPcjRh0', 1, 1, '2018-04-13 14:49:43', '2018-04-13 14:49:43', NULL),
(21, 60, 'fwW7Mop67Ik:APA91bGJCqZBVQtwEYjJl5rCRkuhzQg4RkWpiE-VtYCHZhCDRpLX0GZRDclqWbj7S3xTn1sOZHZB9UUnPesO9Gkyd7gQGJj87Ja_UAtN47My1rOoqIQmtyDdguMAgmXd644pN3VDFCSO', 1, 1, '2018-04-13 20:52:00', '2018-04-13 20:52:00', NULL),
(22, 61, 'fwW7Mop67Ik:APA91bGJCqZBVQtwEYjJl5rCRkuhzQg4RkWpiE-VtYCHZhCDRpLX0GZRDclqWbj7S3xTn1sOZHZB9UUnPesO9Gkyd7gQGJj87Ja_UAtN47My1rOoqIQmtyDdguMAgmXd644pN3VDFCSO', 1, 1, '2018-04-13 20:53:48', '2018-04-13 20:53:48', NULL),
(23, 56, 'fwW7Mop67Ik:APA91bGJCqZBVQtwEYjJl5rCRkuhzQg4RkWpiE-VtYCHZhCDRpLX0GZRDclqWbj7S3xTn1sOZHZB9UUnPesO9Gkyd7gQGJj87Ja_UAtN47My1rOoqIQmtyDdguMAgmXd644pN3VDFCSO', 1, 0, '2018-04-13 20:55:00', '2018-04-13 20:55:00', NULL),
(24, 29, 'd_QpUmOrSV4:APA91bH3z4gAEb--dDUgpE6qE_JhGsQXXpVMZKJR8G3-Y7-pr80kUAnaXo1KjR6uSw36uhRkpkv7yE2SzoyV-BZ5PhxQio90PH8wwCW2uM1UZiSEAMbhs4tHTR2EqRTB_PzU-RKjHj4O', 1, 0, '2018-04-13 20:56:34', '2018-04-13 20:56:34', NULL),
(25, 64, 'dT5RbL82qhI:APA91bE53Oy1cZUW0c8ovtXAc_w8-xi_Jo3LZ7Bklze8sjOLADfO65rn7goxG9AzJc8F_oKbFE8pLxHr7jmTCRFychSKL7qga9eMxoNwAkOXU_d7Ybxiq_EOuFuiEEfxj7BX5bPcjRh0', 1, 0, '2018-04-14 12:33:38', '2018-04-14 12:33:38', NULL),
(26, 65, 'dT5RbL82qhI:APA91bE53Oy1cZUW0c8ovtXAc_w8-xi_Jo3LZ7Bklze8sjOLADfO65rn7goxG9AzJc8F_oKbFE8pLxHr7jmTCRFychSKL7qga9eMxoNwAkOXU_d7Ybxiq_EOuFuiEEfxj7BX5bPcjRh0', 1, 1, '2018-04-14 21:40:07', '2018-04-14 21:40:07', NULL),
(27, 6, 'dLwgpoWj8yk:APA91bFSDGjobaTXJG7MUMoMmzpwtBBd-QavAuQTuyKaf9wlAHlQHi_K5KItsqvyuCa4ywnKfYF28uxJhm1hWimEDRzUEWqp1uyPyNEXudkBKJJDGfYIiJ6SR868508xmsmon4V_cFEL', 1, 1, '2018-04-15 10:53:36', '2018-04-15 10:53:36', NULL),
(28, 26, 'dT5RbL82qhI:APA91bE53Oy1cZUW0c8ovtXAc_w8-xi_Jo3LZ7Bklze8sjOLADfO65rn7goxG9AzJc8F_oKbFE8pLxHr7jmTCRFychSKL7qga9eMxoNwAkOXU_d7Ybxiq_EOuFuiEEfxj7BX5bPcjRh0', 1, 0, '2018-04-20 19:05:21', '2018-04-20 19:05:21', NULL),
(29, 67, 'cg18b-PX5FU:APA91bHNOQFDU6KTg99NDfB9YtKZuakibX57NoC5KAzkOaBYCzZVxTSACgBPVA6k44WUJk2tpuPtREIBeJAJuzEqz9IHNXFkGK4MMcyxlumfKMgYUFaVDsKTeZ_4UOdOXS5FVJFJUDFR', 1, 1, '2018-04-22 11:10:44', '2018-04-22 11:10:44', NULL),
(30, 29, 'cg18b-PX5FU:APA91bHNOQFDU6KTg99NDfB9YtKZuakibX57NoC5KAzkOaBYCzZVxTSACgBPVA6k44WUJk2tpuPtREIBeJAJuzEqz9IHNXFkGK4MMcyxlumfKMgYUFaVDsKTeZ_4UOdOXS5FVJFJUDFR', 1, 0, '2018-04-22 11:24:49', '2018-04-22 11:24:49', NULL),
(31, 68, 'eoVB1Nhl7dg:APA91bEEdj0qoMg-YR0t7l9xKsWxiaGQNU7NBpd0Kgu4VkmYT8yC5K-1LYSBMRt6XS_lJ9XXQtXDsmpOhMaXt43-ACWtfXUihRe518tKT8yGHHauE61j5ko3_lOeTd1JdZmb2V55myqd', 1, 1, '2018-04-22 19:49:11', '2018-04-22 19:49:11', NULL),
(32, 69, 'eoVB1Nhl7dg:APA91bEEdj0qoMg-YR0t7l9xKsWxiaGQNU7NBpd0Kgu4VkmYT8yC5K-1LYSBMRt6XS_lJ9XXQtXDsmpOhMaXt43-ACWtfXUihRe518tKT8yGHHauE61j5ko3_lOeTd1JdZmb2V55myqd', 1, 1, '2018-04-22 19:57:35', '2018-04-22 19:57:35', NULL),
(33, 70, 'eoVB1Nhl7dg:APA91bEEdj0qoMg-YR0t7l9xKsWxiaGQNU7NBpd0Kgu4VkmYT8yC5K-1LYSBMRt6XS_lJ9XXQtXDsmpOhMaXt43-ACWtfXUihRe518tKT8yGHHauE61j5ko3_lOeTd1JdZmb2V55myqd', 1, 1, '2018-04-22 20:21:52', '2018-04-22 20:21:52', NULL),
(34, 26, 'eoVB1Nhl7dg:APA91bEEdj0qoMg-YR0t7l9xKsWxiaGQNU7NBpd0Kgu4VkmYT8yC5K-1LYSBMRt6XS_lJ9XXQtXDsmpOhMaXt43-ACWtfXUihRe518tKT8yGHHauE61j5ko3_lOeTd1JdZmb2V55myqd', 1, 0, '2018-04-22 20:22:25', '2018-04-22 20:22:25', NULL),
(35, 72, 'eoVB1Nhl7dg:APA91bEEdj0qoMg-YR0t7l9xKsWxiaGQNU7NBpd0Kgu4VkmYT8yC5K-1LYSBMRt6XS_lJ9XXQtXDsmpOhMaXt43-ACWtfXUihRe518tKT8yGHHauE61j5ko3_lOeTd1JdZmb2V55myqd', 1, 1, '2018-04-22 20:37:18', '2018-04-22 20:37:18', NULL),
(36, 73, 'eoVB1Nhl7dg:APA91bEEdj0qoMg-YR0t7l9xKsWxiaGQNU7NBpd0Kgu4VkmYT8yC5K-1LYSBMRt6XS_lJ9XXQtXDsmpOhMaXt43-ACWtfXUihRe518tKT8yGHHauE61j5ko3_lOeTd1JdZmb2V55myqd', 1, 1, '2018-04-22 20:39:35', '2018-04-22 20:39:35', NULL),
(37, 28, 'fR-FNz88hos:APA91bFAwoTESoIipoNzzdITmYbco2sLKFzp7OaiD4TgP7y6bGlOttXZP2ieXLCNBg6YeYOqNNXYvDQfpSR5-Ww_CYaCWTMLDhZU-wDxf8twnVnVm7a9PpIXTnPqGSHeO8NuGvlpMYuF', 1, 0, '2018-04-22 20:50:10', '2018-04-22 20:50:10', NULL),
(38, 74, 'cGxoPS-bRIM:APA91bHIJCSuVk-s8yL4-P9R2RQd9v3qv3FIZnnH294KWbU7wJmh8ftHKEorWvHZNhSlRqsUxXtfxARAA07YR-CeWQuU_UgNbtNES5ZNroh5qF22kvK2_KZt_MYNapQqlWXyHPB7cGzV', 1, 1, '2018-04-23 11:16:01', '2018-04-23 11:16:01', NULL),
(39, 29, 'cGxoPS-bRIM:APA91bHIJCSuVk-s8yL4-P9R2RQd9v3qv3FIZnnH294KWbU7wJmh8ftHKEorWvHZNhSlRqsUxXtfxARAA07YR-CeWQuU_UgNbtNES5ZNroh5qF22kvK2_KZt_MYNapQqlWXyHPB7cGzV', 1, 0, '2018-04-23 12:28:16', '2018-04-23 12:28:16', NULL),
(40, 56, 'cGxoPS-bRIM:APA91bHIJCSuVk-s8yL4-P9R2RQd9v3qv3FIZnnH294KWbU7wJmh8ftHKEorWvHZNhSlRqsUxXtfxARAA07YR-CeWQuU_UgNbtNES5ZNroh5qF22kvK2_KZt_MYNapQqlWXyHPB7cGzV', 1, 1, '2018-04-23 14:33:31', '2018-04-23 14:33:31', NULL),
(41, 24, 'cGxoPS-bRIM:APA91bHIJCSuVk-s8yL4-P9R2RQd9v3qv3FIZnnH294KWbU7wJmh8ftHKEorWvHZNhSlRqsUxXtfxARAA07YR-CeWQuU_UgNbtNES5ZNroh5qF22kvK2_KZt_MYNapQqlWXyHPB7cGzV', 1, 1, '2018-04-23 19:29:50', '2018-04-23 19:29:50', NULL),
(42, 26, 'dEz0DWvdBSQ:APA91bHNtgQIzBDFFF8hd26iliMXOr6yI74VKNG6cOBuZtKsxbBwQ8LqySRdJ_rkXkiStx5DobXdew5AG1WJmSwPoFSNOUIg2PO9TkKVA1Sa49iWQcGRVkLn2lTOhCvMVkyjBS67E6iP', 1, 0, '2018-04-23 19:35:49', '2018-04-23 19:35:49', NULL),
(43, 26, 'ejw-si7ToP8:APA91bEEnEP6_d9pJrYI7btpEpLY1uZtmEi54Yca923wsHuBflL_1Fsg6wpbk9kUPRYkIAytp-jGc25LOUmwBia8RAYNmI5yHIaizWzhYA7P2dhAc99qfL2ME1xDY9FzCnNrMA6TEXwR', 1, 0, '2018-04-23 19:58:18', '2018-04-23 19:58:18', NULL),
(44, 29, 'f_zLg4dWmpM:APA91bF_KG21xDJMFYBJd5wixqRHf3fdOjo-rz0r8sj_EwJfdHof4CWEaywnlsloqOXgjosnYw8ZJn_jxfnFImg00ffLN3neDcWOM9QJM2rFiS3YGWArhP__8rLp9jd9NaNnD3GerdVf', 1, 0, '2018-04-23 20:57:48', '2018-04-23 20:57:48', NULL),
(45, 26, 'f_zLg4dWmpM:APA91bF_KG21xDJMFYBJd5wixqRHf3fdOjo-rz0r8sj_EwJfdHof4CWEaywnlsloqOXgjosnYw8ZJn_jxfnFImg00ffLN3neDcWOM9QJM2rFiS3YGWArhP__8rLp9jd9NaNnD3GerdVf', 1, 0, '2018-04-23 20:59:26', '2018-04-23 20:59:26', NULL),
(46, 26, 'ejw-si7ToP8:APA91bEEnEP6_d9pJrYI7btpEpLY1uZtmEi54Yca923wsHuBflL_1Fsg6wpbk9kUPRYkIAytp-jGc25LOUmwBia8RAYNmI5yHIaizWzhYA7P2dhAc99qfL2ME1xDY9FzCnNrMA6TEXwR', 1, 0, '2018-04-23 21:20:04', '2018-04-23 21:20:04', NULL),
(47, 8, 'f_zLg4dWmpM:APA91bF_KG21xDJMFYBJd5wixqRHf3fdOjo-rz0r8sj_EwJfdHof4CWEaywnlsloqOXgjosnYw8ZJn_jxfnFImg00ffLN3neDcWOM9QJM2rFiS3YGWArhP__8rLp9jd9NaNnD3GerdVf', 1, 0, '2018-04-23 21:30:56', '2018-04-23 21:30:56', NULL),
(48, 26, 'cm9MtfrWRrQ:APA91bHjGiPGe5DCIZSSdCjQOlv09l070kHevMx8L7rTLKkFdSB1UKCT1GqOHU9Ic7XQb-_Q_8yGLRzGoZwTFZphKqIESUJW6DQ7R0Wv3L1y8DbVDjlVgRcR9ga8vzyV8G5DctO3lehk', 1, 0, '2018-04-23 22:18:26', '2018-04-23 22:18:26', NULL),
(49, 75, 'cm9MtfrWRrQ:APA91bHjGiPGe5DCIZSSdCjQOlv09l070kHevMx8L7rTLKkFdSB1UKCT1GqOHU9Ic7XQb-_Q_8yGLRzGoZwTFZphKqIESUJW6DQ7R0Wv3L1y8DbVDjlVgRcR9ga8vzyV8G5DctO3lehk', 1, 0, '2018-04-23 22:24:04', '2018-04-23 22:24:04', NULL),
(50, 75, 'ftNlOvjMc4Q:APA91bEcXWS481tuGMdGDeoxKEii4B00Uspz5DHVPQrrgG7eDeJK0cw1xY1BV-iAMDBmC7h2P2AYdyv_ZXcwBDbWcMYUlqnJptKcVeXe8vT4XNW4rWCpnp6X8Qia5EuDyXEOw8NqttCt', 1, 1, '2018-04-23 22:27:45', '2018-04-23 22:27:45', NULL),
(51, 26, 'ejw-si7ToP8:APA91bEEnEP6_d9pJrYI7btpEpLY1uZtmEi54Yca923wsHuBflL_1Fsg6wpbk9kUPRYkIAytp-jGc25LOUmwBia8RAYNmI5yHIaizWzhYA7P2dhAc99qfL2ME1xDY9FzCnNrMA6TEXwR', 1, 0, '2018-04-23 22:40:47', '2018-04-23 22:40:47', NULL),
(52, 26, 'dsrBfj-87FE:APA91bG5f1tttUrWTmBSwhIYTnnKJ6Pf--e3l3cXLwDMGThccyEKkbVK2nNZ-7w0kDrbXHRYEf564iRXi2TskFwLjUiTnWUFBFFkJaPWOR_nfiFq4JwgTgFF2MSTFNQFMMIvhSdPyy9y', 1, 0, '2018-04-23 22:59:10', '2018-04-23 22:59:10', NULL),
(53, 26, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 0, '2018-04-23 23:16:04', '2018-04-23 23:16:04', NULL),
(54, 29, 'eW4xwk8Ysjo:APA91bFxrfypkR7DwNsWPQMLJKAMYpJH_a61lI4NASxh9jmhC-4Z7KgxKSPHsO3WtvqdK44WmvY7HiTkR-Y9isOWy-zlFuldXaqmGlWaeSxnysiOOaIkZ2CXTK-SUPqWE9MzMBYizcml', 1, 0, '2018-04-24 08:57:57', '2018-04-24 08:57:57', NULL),
(55, 28, 'f9v9DEzszq4:APA91bH5P0ar-eJMZsCwW47qAqfFzdLZlVNOBH3htD7ilPaovpflEa_NLXIAUCldW26ogvyL9RMpYxB_5IOkfVFOx31e-EW375IXfm8TaUD-rpZ2nSl38oUa-WsTJRDgSq6vzYoq6MIE', 1, 1, '2018-04-24 10:28:09', '2018-04-24 10:28:09', NULL),
(56, 7, 'ebGBHGIQRW4:APA91bE77h92OEC3W_Vl1pC9_a8YjVAvgdywlItKm4T8TqyO6vwpfpQkGHHRiD6tZvUc0tXNMcurCqlA6hwK-qf9J64iW6TwyHcUU_qTNWv3T0PtUVXz5Q0d9hROZL2ZRxwBmCIAhQ1b', 1, 0, '2018-04-24 10:46:47', '2018-04-24 10:46:47', NULL),
(57, 77, 'dLwgpoWj8yk:APA91bFSDGjobaTXJG7MUMoMmzpwtBBd-QavAuQTuyKaf9wlAHlQHi_K5KItsqvyuCa4ywnKfYF28uxJhm1hWimEDRzUEWqp1uyPyNEXudkBKJJDGfYIiJ6SR868508xmsmon4V_cFEL', 1, 1, '2018-04-25 22:18:46', '2018-04-25 22:18:46', NULL),
(58, 78, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-04-26 10:37:53', '2018-04-26 10:37:53', NULL),
(59, 79, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-04-26 10:48:26', '2018-04-26 10:48:26', NULL),
(60, 8, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-04-26 16:07:10', '2018-04-26 16:07:10', NULL),
(61, 12, 'e_7jeKZ-xJI:APA91bESHao7N0Q8D-EJdbAHoMF-4x06CHm3V_eAdHsS8hQULAa4YcLixU_BdM1DSkZCcidbGxWcAEwnt-1iy3kZpF-DwNGcVCWmAFhJFScKYnp5X-MynriISpHo_JXHQLURLfKBy0ZD', 1, 0, '2018-04-26 21:00:28', '2018-04-26 21:00:28', NULL),
(62, 84, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-04-26 21:49:13', '2018-04-26 21:49:13', NULL),
(63, 85, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-04-26 21:51:29', '2018-04-26 21:51:29', NULL),
(64, 86, 'cOjERvpYE6M:APA91bEZRTOo_1SLJmhi1aybgC9UGe-Jnrgjfllzbrd9cnzUEXqY2n7MHXZK2hYBosJackin_KTeHloEYyesQHDE7dyRuQHmpGN9sYkc8oxG_FMWyulBIVxUQISfU6hmlW4gAQyxHALc', 1, 0, '2018-05-07 14:11:02', '2018-05-07 14:11:02', NULL),
(65, 90, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-05-21 23:19:35', '2018-05-21 23:19:35', NULL),
(66, 91, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-05-22 20:11:36', '2018-05-22 20:11:36', NULL),
(67, 64, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-05-22 20:25:04', '2018-05-22 20:25:04', NULL),
(68, 87, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-05-22 20:25:43', '2018-05-22 20:25:43', NULL),
(69, 92, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-05-22 20:27:39', '2018-05-22 20:27:39', NULL),
(70, 53, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-05-22 22:54:41', '2018-05-22 22:54:41', NULL),
(71, 7, 'cOjERvpYE6M:APA91bEZRTOo_1SLJmhi1aybgC9UGe-Jnrgjfllzbrd9cnzUEXqY2n7MHXZK2hYBosJackin_KTeHloEYyesQHDE7dyRuQHmpGN9sYkc8oxG_FMWyulBIVxUQISfU6hmlW4gAQyxHALc', 1, 0, '2018-05-22 23:51:41', '2018-05-22 23:51:41', NULL),
(72, 86, 'dClfm8nX4OQ:APA91bEPxwct766v66f6r9EZR168yuiCIUbsIgr_d5t4Gzm4PXQ8ZbGbBwpuOqNMAyTxcOWCBj-79vFmDW8ngqEhvFk8r0utrjnsnZ3--n-j0ZROToZecK8b9v3yFSFG2hzGsKvMoDaq', 1, 1, '2018-05-23 12:44:23', '2018-05-23 12:44:23', NULL),
(73, 96, 'dClfm8nX4OQ:APA91bEPxwct766v66f6r9EZR168yuiCIUbsIgr_d5t4Gzm4PXQ8ZbGbBwpuOqNMAyTxcOWCBj-79vFmDW8ngqEhvFk8r0utrjnsnZ3--n-j0ZROToZecK8b9v3yFSFG2hzGsKvMoDaq', 1, 1, '2018-05-23 13:00:01', '2018-05-23 13:00:01', NULL),
(74, 97, 'cxMVRpb6dsQ:APA91bEnPomN5QQrQ9COualZQPI0XBOERcJRcuyOTKRbjBDNlNmuwLjS5mfNABshC217jydENhZQfCPbV0otWgLPG3KGSyYt5Di7ksMUViyMD8OvUjFHmmN4du6UcnGD8E6NRasGQ6Gp', 1, 1, '2018-05-24 10:03:17', '2018-05-24 10:03:17', NULL),
(75, 26, 'crxwoUZF77U:APA91bHC8rldOi72pq1HE6IvdRf-gDJQ2PgaM7Qk7l98WB37O5OD2JgAV5CMPCK7FFIzfiFp6OoigEC7xit4nd1uH1oo4R1Z9M4KykuggKHZb7hrmYvaGVf7t3yXHGs0BBpO4yTOoh1E', 1, 0, '2018-05-25 06:59:26', '2018-05-25 06:59:26', NULL),
(76, 99, 'dwcLBK9UZQw:APA91bHiQJIKsD5H9xozgPxzqRc1HUEQUbGA0rmYNysgdOHXWasH74-XgGmbVN1zRw4L0w7n6EfKJahpZVII3Ov6Lq5W0OWYmvSt5D4ojvHPg2nU3mwIvTdb1a34Z-ep7PcLhGobysT2', 1, 1, '2018-05-25 14:10:56', '2018-05-25 14:10:56', NULL),
(77, 100, 'dwcLBK9UZQw:APA91bHiQJIKsD5H9xozgPxzqRc1HUEQUbGA0rmYNysgdOHXWasH74-XgGmbVN1zRw4L0w7n6EfKJahpZVII3Ov6Lq5W0OWYmvSt5D4ojvHPg2nU3mwIvTdb1a34Z-ep7PcLhGobysT2', 1, 1, '2018-05-25 14:13:22', '2018-05-25 14:13:22', NULL),
(78, 101, 'dwcLBK9UZQw:APA91bHiQJIKsD5H9xozgPxzqRc1HUEQUbGA0rmYNysgdOHXWasH74-XgGmbVN1zRw4L0w7n6EfKJahpZVII3Ov6Lq5W0OWYmvSt5D4ojvHPg2nU3mwIvTdb1a34Z-ep7PcLhGobysT2', 1, 1, '2018-05-25 14:17:00', '2018-05-25 14:17:00', NULL),
(79, 26, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 0, '2018-05-25 15:18:10', '2018-05-25 15:18:10', NULL),
(80, 26, 'crxwoUZF77U:APA91bHC8rldOi72pq1HE6IvdRf-gDJQ2PgaM7Qk7l98WB37O5OD2JgAV5CMPCK7FFIzfiFp6OoigEC7xit4nd1uH1oo4R1Z9M4KykuggKHZb7hrmYvaGVf7t3yXHGs0BBpO4yTOoh1E', 1, 0, '2018-05-27 18:53:53', '2018-05-27 18:53:53', NULL),
(81, 26, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-05-27 19:05:27', '2018-05-27 19:05:27', NULL),
(82, 102, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-05-28 23:15:07', '2018-05-28 23:15:07', NULL),
(83, 103, 'cQmo9NRr8gw:APA91bEM0s-LFnGqdx5Baf3c_RqsciB6GQqJutmF0idW__8MS3YRJ8gborKYhWPkhOoN_d7j3w5AhNZNvzyLg3eXlfeVmURT3cTM8OnIRTxJh2C--836eT7F56r-p_-B1FWPajbhpTZ0', 1, 1, '2018-05-30 23:55:19', '2018-05-30 23:55:19', NULL),
(84, 104, 'cQmo9NRr8gw:APA91bEM0s-LFnGqdx5Baf3c_RqsciB6GQqJutmF0idW__8MS3YRJ8gborKYhWPkhOoN_d7j3w5AhNZNvzyLg3eXlfeVmURT3cTM8OnIRTxJh2C--836eT7F56r-p_-B1FWPajbhpTZ0', 1, 1, '2018-05-30 23:59:21', '2018-05-30 23:59:21', NULL),
(85, 107, 'fO7bN1XI3dI:APA91bF2Otxta9ADOaAIlvwAied6V0BSX-vkz7CR3aqiaINl9cFl_8vcV06Xwg2fV73ke-oQqD48TyPA9OqcuH_6DbSpMjxdNy5jwPu4Td5RCXpUhYNtpOBS9LTUw2qy-ZNmmddKHZ2p', 1, 1, '2018-05-31 09:01:48', '2018-05-31 09:01:48', NULL),
(86, 106, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-05-31 20:59:01', '2018-05-31 20:59:01', NULL),
(87, 110, 'dg7kKLDeTKc:APA91bE69TjzbX88vNXZbeeOrxZ04MqvWU0e6CMZIE9CMwhWjcRVyGaQ7jtSsnbpOJMgnv7f3i4NaVzrtKlOvaCpGigH86awCjGnJy9EXs5Z5-79WCczNcGUfI30YegO_xuN_Ho8Wf_a', 1, 1, '2018-05-31 22:57:47', '2018-05-31 22:57:47', NULL),
(88, 111, 'dB4bWmcLnaI:APA91bGn5PLOsJnk9cLOlYQeWEmonwYgtyzuOZZds46A9GqY7fWWzUD5nppoyVuO4gwAmjq3brfLnRe6csbixmZDBTE_pTnWD3EiJJGL4QvoREAlwIdllogjXQxvkbN1mz1x14UVfc0N', 1, 0, '2018-06-06 17:44:47', '2018-06-06 17:44:47', NULL),
(89, 111, 'e1hClWmALig:APA91bFfsDMw6bZjRybiyJi-5ceHKPl46WzSMDZ63UBEX43pvOITGjW1xsDJN5YsUZYAh1nXgbAVHqMrB6y_Tor82ZwkQam1ZT7zp7bfX2h2KDC--TKv0P6VjXMsSaLpnMkA6XbiJm7q', 1, 0, '2018-06-08 21:00:21', '2018-06-08 21:00:21', NULL),
(90, 113, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 0, '2018-06-09 22:55:50', '2018-06-09 22:55:50', NULL),
(91, 111, 'dhW-h1cIwAI:APA91bEhsiu4opQV1VqSxdrPVFjarWL0xcDCCHZpZDc2x5125GWnN__SlZwzacvKm-qky377qKDZ0wjj2dbdAX4wWPETojr0Zy1vk_LF0Hkp-Yp0M8D6_qmVcM2Gnc8dPJBIeShCLJRn', 1, 1, '2018-06-10 19:08:09', '2018-06-10 19:08:09', NULL),
(92, 7, 'dLwgpoWj8yk:APA91bFSDGjobaTXJG7MUMoMmzpwtBBd-QavAuQTuyKaf9wlAHlQHi_K5KItsqvyuCa4ywnKfYF28uxJhm1hWimEDRzUEWqp1uyPyNEXudkBKJJDGfYIiJ6SR868508xmsmon4V_cFEL', 1, 0, '2018-06-12 04:17:51', '2018-06-12 04:17:51', NULL),
(93, 115, 'dLwgpoWj8yk:APA91bFSDGjobaTXJG7MUMoMmzpwtBBd-QavAuQTuyKaf9wlAHlQHi_K5KItsqvyuCa4ywnKfYF28uxJhm1hWimEDRzUEWqp1uyPyNEXudkBKJJDGfYIiJ6SR868508xmsmon4V_cFEL', 1, 1, '2018-06-13 12:27:45', '2018-06-13 12:27:45', NULL),
(94, 116, 'dhW-h1cIwAI:APA91bEhsiu4opQV1VqSxdrPVFjarWL0xcDCCHZpZDc2x5125GWnN__SlZwzacvKm-qky377qKDZ0wjj2dbdAX4wWPETojr0Zy1vk_LF0Hkp-Yp0M8D6_qmVcM2Gnc8dPJBIeShCLJRn', 1, 1, '2018-06-13 15:55:10', '2018-06-13 15:55:10', NULL),
(95, 29, 'fv7KVZVYH_s:APA91bEMUk63Yj06uHDJoV5tT0HzQ0wgOfp4-dkQayHttJOLfWtNjiSW7Lm3uUkbEunf930rUdiT18-6-XXyhLpgxeh8_P1P7CgPWgNKMS-gwfKROrsDC81WGYpRH9rgZWTckoT_Xg_k', 1, 0, '2018-06-13 22:28:14', '2018-06-13 22:28:14', NULL),
(96, 29, 'fV51oNWXxS8:APA91bEFRWDMCy03pzQ_h2mv2hoSwiMLQd83ZPchk0Xm7JS7TshH61SOxCFlBO0tO7rArCsWbFKUGhVSPgiEdeyUvW2V1vvv4QfPFNhWje4YMdqD8p5n9e5Xljx_KiqZAVEUlIKpw8guJ-Tsd-xF3OQ9ot-trLBpIg', 1, 0, '2018-06-21 19:07:03', '2018-06-21 19:07:03', NULL),
(97, 7, 'ebGBHGIQRW4:APA91bE77h92OEC3W_Vl1pC9_a8YjVAvgdywlItKm4T8TqyO6vwpfpQkGHHRiD6tZvUc0tXNMcurCqlA6hwK-qf9J64iW6TwyHcUU_qTNWv3T0PtUVXz5Q0d9hROZL2ZRxwBmCIAhQ1b', 1, 1, '2018-06-21 19:14:28', '2018-06-21 19:14:28', NULL),
(98, 29, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 0, '2018-06-22 20:21:20', '2018-06-22 20:21:20', NULL),
(99, 29, 'fV51oNWXxS8:APA91bEFRWDMCy03pzQ_h2mv2hoSwiMLQd83ZPchk0Xm7JS7TshH61SOxCFlBO0tO7rArCsWbFKUGhVSPgiEdeyUvW2V1vvv4QfPFNhWje4YMdqD8p5n9e5Xljx_KiqZAVEUlIKpw8guJ-Tsd-xF3OQ9ot-trLBpIg', 1, 0, '2018-06-23 12:00:08', '2018-06-23 12:00:08', NULL),
(100, 29, 'cU8cpu4Ke0M:APA91bE31y639cygERWD7ChZvm8FJhxYwgq3eO8Z_ep5M3Ypz9StKH93WONxC3p4JaaQrl3gQxhWFbOvCpn3tIm_NJePDT6Ngw7kjqpLGw9AwIGsXadJ4x6UzJl6IuGDg0zbgn8r_3hwr3RPDR1G5U44b40xt7h3PQ', 1, 0, '2018-06-23 12:50:16', '2018-06-23 12:50:16', NULL),
(101, 29, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 0, '2018-06-23 14:05:11', '2018-06-23 14:05:11', NULL),
(102, 29, 'cU8cpu4Ke0M:APA91bE31y639cygERWD7ChZvm8FJhxYwgq3eO8Z_ep5M3Ypz9StKH93WONxC3p4JaaQrl3gQxhWFbOvCpn3tIm_NJePDT6Ngw7kjqpLGw9AwIGsXadJ4x6UzJl6IuGDg0zbgn8r_3hwr3RPDR1G5U44b40xt7h3PQ', 1, 1, '2018-06-23 22:19:36', '2018-06-23 22:19:36', NULL),
(103, 120, 'e25M9WoIxbE:APA91bFf4ZO8jimZZsurBvZB0XmqmPqMs3qoan0scb4FjPB9Mnz2fe2WjxSC4qUwCWVyabMPTAgm429umHtLulwwEqbAfgneckTGaqMa7b7A2vLRJE1vxnXuvsLOa0hXBVl61jm6QBE78KKXt28fEZwOIux545odRA', 1, 1, '2018-06-25 00:53:19', '2018-06-25 00:53:19', NULL),
(104, 113, 'cU8cpu4Ke0M:APA91bE31y639cygERWD7ChZvm8FJhxYwgq3eO8Z_ep5M3Ypz9StKH93WONxC3p4JaaQrl3gQxhWFbOvCpn3tIm_NJePDT6Ngw7kjqpLGw9AwIGsXadJ4x6UzJl6IuGDg0zbgn8r_3hwr3RPDR1G5U44b40xt7h3PQ', 1, 0, '2018-06-25 23:57:10', '2018-06-25 23:57:10', NULL),
(105, 121, 'dLwgpoWj8yk:APA91bFSDGjobaTXJG7MUMoMmzpwtBBd-QavAuQTuyKaf9wlAHlQHi_K5KItsqvyuCa4ywnKfYF28uxJhm1hWimEDRzUEWqp1uyPyNEXudkBKJJDGfYIiJ6SR868508xmsmon4V_cFEL', 1, 1, '2018-06-26 00:07:09', '2018-06-26 00:07:09', NULL),
(106, 113, 'dLwgpoWj8yk:APA91bFSDGjobaTXJG7MUMoMmzpwtBBd-QavAuQTuyKaf9wlAHlQHi_K5KItsqvyuCa4ywnKfYF28uxJhm1hWimEDRzUEWqp1uyPyNEXudkBKJJDGfYIiJ6SR868508xmsmon4V_cFEL', 1, 0, '2018-06-26 19:16:41', '2018-06-26 19:16:41', NULL),
(107, 113, 'cU8cpu4Ke0M:APA91bE31y639cygERWD7ChZvm8FJhxYwgq3eO8Z_ep5M3Ypz9StKH93WONxC3p4JaaQrl3gQxhWFbOvCpn3tIm_NJePDT6Ngw7kjqpLGw9AwIGsXadJ4x6UzJl6IuGDg0zbgn8r_3hwr3RPDR1G5U44b40xt7h3PQ', 1, 0, '2018-06-27 15:26:11', '2018-06-27 15:26:11', NULL),
(108, 113, 'dLwgpoWj8yk:APA91bFSDGjobaTXJG7MUMoMmzpwtBBd-QavAuQTuyKaf9wlAHlQHi_K5KItsqvyuCa4ywnKfYF28uxJhm1hWimEDRzUEWqp1uyPyNEXudkBKJJDGfYIiJ6SR868508xmsmon4V_cFEL', 1, 0, '2018-06-27 19:23:32', '2018-06-27 19:23:32', NULL),
(109, 12, 'ejWI8RvDPTo:APA91bFxEVOfvcYrIlPTadheVZpAORhIJ78wTAmOsB_okntP149XHWO3I7BFPrba98oBlkZ9TUeUFhZPyulY7EcY8eDI88_ukvTiDUIJ-65-ac7ypH93zdLbG8ZXUP7w3DMMZqhNBH0pwEJQwETrwlkDzESr-A1EqA', 1, 1, '2018-06-28 22:21:06', '2018-06-28 22:21:06', NULL),
(110, 113, 'cU8cpu4Ke0M:APA91bE31y639cygERWD7ChZvm8FJhxYwgq3eO8Z_ep5M3Ypz9StKH93WONxC3p4JaaQrl3gQxhWFbOvCpn3tIm_NJePDT6Ngw7kjqpLGw9AwIGsXadJ4x6UzJl6IuGDg0zbgn8r_3hwr3RPDR1G5U44b40xt7h3PQ', 1, 0, '2018-06-29 11:59:10', '2018-06-29 11:59:10', NULL),
(111, 123, 'cU8cpu4Ke0M:APA91bE31y639cygERWD7ChZvm8FJhxYwgq3eO8Z_ep5M3Ypz9StKH93WONxC3p4JaaQrl3gQxhWFbOvCpn3tIm_NJePDT6Ngw7kjqpLGw9AwIGsXadJ4x6UzJl6IuGDg0zbgn8r_3hwr3RPDR1G5U44b40xt7h3PQ', 1, 1, '2018-06-29 13:14:38', '2018-06-29 13:14:38', NULL),
(112, 124, 'cU8cpu4Ke0M:APA91bE31y639cygERWD7ChZvm8FJhxYwgq3eO8Z_ep5M3Ypz9StKH93WONxC3p4JaaQrl3gQxhWFbOvCpn3tIm_NJePDT6Ngw7kjqpLGw9AwIGsXadJ4x6UzJl6IuGDg0zbgn8r_3hwr3RPDR1G5U44b40xt7h3PQ', 1, 1, '2018-06-29 13:48:42', '2018-06-29 13:48:42', NULL),
(113, 113, 'dLwgpoWj8yk:APA91bFSDGjobaTXJG7MUMoMmzpwtBBd-QavAuQTuyKaf9wlAHlQHi_K5KItsqvyuCa4ywnKfYF28uxJhm1hWimEDRzUEWqp1uyPyNEXudkBKJJDGfYIiJ6SR868508xmsmon4V_cFEL', 1, 1, '2018-06-29 14:07:43', '2018-06-29 14:07:43', NULL),
(114, 95, 'cU8cpu4Ke0M:APA91bE31y639cygERWD7ChZvm8FJhxYwgq3eO8Z_ep5M3Ypz9StKH93WONxC3p4JaaQrl3gQxhWFbOvCpn3tIm_NJePDT6Ngw7kjqpLGw9AwIGsXadJ4x6UzJl6IuGDg0zbgn8r_3hwr3RPDR1G5U44b40xt7h3PQ', 1, 1, '2018-06-29 14:20:58', '2018-06-29 14:20:58', NULL),
(115, 117, 'cU8cpu4Ke0M:APA91bE31y639cygERWD7ChZvm8FJhxYwgq3eO8Z_ep5M3Ypz9StKH93WONxC3p4JaaQrl3gQxhWFbOvCpn3tIm_NJePDT6Ngw7kjqpLGw9AwIGsXadJ4x6UzJl6IuGDg0zbgn8r_3hwr3RPDR1G5U44b40xt7h3PQ', 1, 1, '2018-06-29 14:25:11', '2018-06-29 14:25:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `profile_transaction`
--

CREATE TABLE `profile_transaction` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile_id` int(11) NOT NULL,
  `transaction_type` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profile_transaction`
--

INSERT INTO `profile_transaction` (`id`, `profile_id`, `transaction_type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 6, 1, '2018-04-02 09:34:15', '2018-04-02 09:34:15', NULL),
(2, 6, 1, '2018-04-03 21:37:49', '2018-04-03 21:37:49', NULL),
(3, 6, 1, '2018-04-03 21:37:55', '2018-04-03 21:37:55', NULL),
(4, 29, 1, '2018-04-04 19:16:54', '2018-04-04 19:16:54', NULL),
(5, 29, 1, '2018-04-08 21:11:28', '2018-04-08 21:11:28', NULL),
(6, 28, 1, '2018-04-22 21:11:15', '2018-04-22 21:11:15', NULL),
(7, 28, 1, '2018-04-22 21:11:23', '2018-04-22 21:11:23', NULL),
(8, 74, 1, '2018-04-23 12:26:14', '2018-04-23 12:26:14', NULL),
(9, 29, 1, '2018-04-24 08:58:58', '2018-04-24 08:58:58', NULL),
(10, 28, 1, '2018-04-24 09:14:35', '2018-04-24 09:14:35', NULL),
(11, 7, 1, '2018-04-24 09:19:36', '2018-04-24 09:19:36', NULL),
(12, 29, 1, '2018-04-24 09:20:01', '2018-04-24 09:20:01', NULL),
(13, 7, 1, '2018-04-24 10:57:33', '2018-04-24 10:57:33', NULL),
(14, 7, 1, '2018-04-24 10:58:08', '2018-04-24 10:58:08', NULL),
(15, 26, 1, '2018-04-26 12:51:35', '2018-04-26 12:51:35', NULL),
(16, 26, 1, '2018-04-26 12:51:54', '2018-04-26 12:51:54', NULL),
(17, 77, 1, '2018-04-26 16:03:10', '2018-04-26 16:03:10', NULL),
(18, 77, 1, '2018-04-26 22:09:20', '2018-04-26 22:09:20', NULL),
(19, 77, 1, '2018-04-27 18:13:01', '2018-04-27 18:13:01', NULL),
(20, 77, 1, '2018-04-27 18:13:39', '2018-04-27 18:13:39', NULL),
(21, 77, 1, '2018-04-27 18:20:30', '2018-04-27 18:20:30', NULL),
(22, 77, 1, '2018-04-27 18:23:31', '2018-04-27 18:23:31', NULL),
(23, 77, 1, '2018-04-27 18:27:44', '2018-04-27 18:27:44', NULL),
(24, 86, 1, '2018-05-07 14:32:32', '2018-05-07 14:32:32', NULL),
(25, 26, 1, '2018-05-08 06:46:04', '2018-05-08 06:46:04', NULL),
(26, 86, 1, '2018-05-23 12:45:30', '2018-05-23 12:45:30', NULL),
(27, 26, 1, '2018-05-24 10:30:09', '2018-05-24 10:30:09', NULL),
(28, 26, 1, '2018-05-24 10:30:20', '2018-05-24 10:30:20', NULL),
(29, 26, 1, '2018-05-27 18:56:33', '2018-05-27 18:56:33', NULL),
(30, 26, 1, '2018-05-27 19:06:28', '2018-05-27 19:06:28', NULL),
(31, 77, 1, '2018-05-28 01:10:28', '2018-05-28 01:10:28', NULL),
(32, 77, 1, '2018-05-28 01:10:39', '2018-05-28 01:10:39', NULL),
(33, 77, 1, '2018-06-01 21:39:34', '2018-06-01 21:39:34', NULL),
(34, 111, 1, '2018-06-08 14:39:19', '2018-06-08 14:39:19', NULL),
(35, 111, 1, '2018-06-08 14:39:51', '2018-06-08 14:39:51', NULL),
(36, 111, 1, '2018-06-08 14:40:33', '2018-06-08 14:40:33', NULL),
(37, 111, 1, '2018-06-08 14:54:39', '2018-06-08 14:54:39', NULL),
(38, 111, 1, '2018-06-11 20:30:36', '2018-06-11 20:30:36', NULL),
(39, 116, 1, '2018-06-13 15:56:11', '2018-06-13 15:56:11', NULL),
(40, 7, 1, '2018-06-21 19:30:57', '2018-06-21 19:30:57', NULL),
(41, 7, 1, '2018-06-21 19:33:07', '2018-06-21 19:33:07', NULL),
(42, 7, 1, '2018-06-21 20:29:13', '2018-06-21 20:29:13', NULL),
(43, 115, 1, '2018-06-25 00:24:45', '2018-06-25 00:24:45', NULL),
(44, 120, 1, '2018-06-25 00:53:52', '2018-06-25 00:53:52', NULL),
(45, 113, 1, '2018-06-26 00:37:55', '2018-06-26 00:37:55', NULL),
(46, 113, 1, '2018-06-26 00:37:57', '2018-06-26 00:37:57', NULL),
(47, 113, 1, '2018-06-27 12:12:28', '2018-06-27 12:12:28', NULL),
(48, 124, 1, '2018-06-29 13:55:05', '2018-06-29 13:55:05', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin@ijobs.com', '01002202640', '$2y$10$J71a870RpwzcgPQIqgJ3FONjnr1EtZvbJO/ogonXtiqydti1ZHDtq', NULL, '2018-01-26 13:43:54', '2018-01-26 13:43:54'),
(3, 'Admin1', 'admin1111@ijobs.com', '201142833580', '$2y$10$J71a870RpwzcgPQIqgJ3FONjnr1EtZvbJO/ogonXtiqydti1ZHDtq', NULL, '2018-01-26 13:43:54', '2018-01-26 13:43:54'),
(9, '22222', '22222@ijbber.com', NULL, '$2y$10$vGxeUhwS7SmXwDC4TmwS8.nkbN068vQtbxW4sllDY9VPJrDO5zEFm', NULL, '2018-03-03 18:03:03', '2018-03-03 18:03:03'),
(10, '222221', '222221@ijbber.com', NULL, '$2y$10$c1owtw37zpju5jYTm91kaOHwjPKXBpD7T87rVko/2v79R2Ia/o58u', NULL, '2018-03-03 18:04:21', '2018-03-03 18:04:21'),
(11, '2222212', '2222212@ijbber.com', '2222212', '$2y$10$/W8OiUxeqDl39NYpZ5pKiO7PsAzO2296x4UXnwrrDjwyfcStmp.ES', NULL, '2018-03-03 18:06:05', '2018-03-03 18:06:05'),
(12, '6666666', '6666666@ijbber.com', '6666666', '$2y$10$IV0k0/nShhxbLowAFOeUZeFSeGuAJBWSwIDhKCG8s864h6WAqO4lW', NULL, '2018-03-03 18:06:14', '2018-03-03 18:06:14'),
(13, '002001009429977', '002001009429977@ijbber.com', '002001009429977', '$2y$10$tX19nlHTYpy002twkDlSb.yprOza0OC7S4yXxIERRbuv7SBahTuAa', NULL, '2018-03-05 11:14:27', '2018-03-05 11:14:27'),
(16, '009660546628911', '009660546628911@ijbber.com', '009660546628911', '$2y$10$VdEKPKStYqpkjEphACp.7Ob93kVVnFpMJ9PEvWgh2obIbLng/Y1bK', NULL, '2018-03-05 18:59:10', '2018-03-05 18:59:10'),
(19, '00201223185749', '00201223185749@ijober.com', '00201223185749', '$2y$10$nQ4Fp/y7yXupJtSSX837AeNMksETf0byK23uLHpV5ITUDSAF8qzfO', NULL, '2018-03-10 20:53:15', '2018-03-10 20:53:15'),
(20, '002001067672720', '002001067672720@ijober.com', '002001067672720', '$2y$10$nSAZoEXwdwMIjvtyS3nEFeg6o6A/V8qhfvE/F1lHAsGGGEjeMQNXC', NULL, '2018-03-10 21:12:30', '2018-03-10 21:12:30'),
(21, '002001223185746', '002001223185746@ijober.com', '002001223185746', '$2y$10$iyq9GE7yqnr50CTjV.NwF.us57af6.g0uF2b6e/bMCEJpUUQVbOp6', NULL, '2018-03-10 21:12:58', '2018-03-10 21:12:58'),
(22, '002001223185746', '002001223185746@ijbber.com', '002001223185746', '$2y$10$hRwGXg4OIIxetUQPFnyG4uV2URL5dYYIaMAz.EYDmxLtHHZyW4PcS', NULL, '2018-03-10 21:14:02', '2018-03-10 21:14:02'),
(23, '00201142833580', '00201142833580@ijober.com', '00201142833580', '$2y$10$wwDibaKayBm5hRWCxf52G.lZWWs6vUybwTyWXftUyx/Ihs/r2OfDe', NULL, '2018-03-12 18:21:09', '2018-03-12 18:21:09'),
(24, '009660546628912', '009660546628912@ijober.com', '009660546628912', '$2y$10$wPcim1V35T4aK815IDos0uZVdNaz6CrjSbH4931uaXCpWYoa0IrEm', NULL, '2018-03-12 23:00:11', '2018-03-12 23:00:11'),
(25, '00966500176113', '00966500176113@ijober.com', '00966500176113', '$2y$10$tQXst8Q0j5EOoELpjI/NgukOtsIlWnixiON7kKaXr3OR1pqJ9XGI6', NULL, '2018-03-14 12:23:20', '2018-03-14 12:23:20'),
(26, '00966500176113', '00966500176113@ijbber.com', '00966500176113', '$2y$10$cbx7gWb2GcCNC1kG0Y0iuOAm8Y.BUzHsph8u5Yzxt39ZWKzGBU7zq', NULL, '2018-03-14 12:26:07', '2018-03-14 12:26:07'),
(27, '0020119849824', '0020119849824@ijober.com', '0020119849824', '$2y$10$3SuQL5cH6ZWuv9pkfp6n0e6y/SiP.L0U.WBu2Mq0gQK5fdu9QhQS6', NULL, '2018-03-16 16:24:45', '2018-03-16 16:24:45'),
(28, '00201119849824', '00201119849824@ijober.com', '00201119849824', '$2y$10$3CqiUcLTK688ysIslRsbhuT93SYkUok9YykWlB3X0H8aSdokloMjO', NULL, '2018-03-16 16:25:22', '2018-03-16 16:25:22'),
(29, '00201119849824', '00201119849824@ijbber.com', '00201119849824', '$2y$10$rWE6uf2R0TiMdzyj5Jy9oefeH9316aMnZAjiIqHXN8cxv6auPhvFi', NULL, '2018-03-16 16:26:10', '2018-03-16 16:26:10'),
(30, '00201122334455', '00201122334455@ijober.com', '00201122334455', '$2y$10$ZZmnmV.glO126XIM0.lzp.8uGtKdjCztHHTko3qrMzjG2yT/No3NC', NULL, '2018-03-16 20:03:25', '2018-03-16 20:03:25'),
(31, '00201122334455', '00201122334455@ijbber.com', '00201122334455', '$2y$10$2iq/Bx4IO3O26R4osoSyYOWiq7Ghto2FUWitoitGmqUDc4208BkEa', NULL, '2018-03-16 20:03:57', '2018-03-16 20:03:57'),
(32, '00201279695195', '00201279695195@ijober.com', '00201279695195', '$2y$10$84cgapNl7pkYjFHcGyYjFuSRCfxHeND64NMxqnJOPPj9WKLg73ZbW', NULL, '2018-03-17 17:53:36', '2018-03-17 17:53:36'),
(33, '00201279695195', '00201279695195@ijbber.com', '00201279695195', '$2y$10$Uh4HpvAHirgMvyOvA9p/L.M.wMSRdkqe2SrC01WQdv9VVUUJNB43u', NULL, '2018-03-17 17:55:28', '2018-03-17 17:55:28'),
(34, '002001064041779', '002001064041779@ijober.com', '002001064041779', '$2y$10$dQ2T5FdWV7EQHXjzz0od/u5z9u5eM9ETxcDfWnipWkNXzIVrRHj2u', NULL, '2018-03-20 08:18:08', '2018-03-20 08:18:08'),
(35, '002001064041779', '002001064041779@ijbber.com', '002001064041779', '$2y$10$BQLCkguwryV4Rvrg87fmUOu.fO65yEr3L6nSqUA823WjwSDww5p4m', NULL, '2018-03-20 08:33:22', '2018-03-20 08:33:22'),
(36, '00201019584283', '00201019584283@ijober.com', '00201019584283', '$2y$10$tYyNWtFJhf4iPIrkcxYy3uYDFAluDQMTvwJMz8mg3vKGskdklWYxG', NULL, '2018-03-20 20:36:37', '2018-03-20 20:36:37'),
(37, '00201019584283', '00201019584283@ijbber.com', '00201019584283', '$2y$10$V0mhF1YDOEk6WxkecNXxzuHDoU3jRtkyJDa9dk.0vhSP9Ze76qF56', NULL, '2018-03-20 20:44:28', '2018-03-20 20:44:28'),
(38, '002001066253101', '002001066253101@ijober.com', '002001066253101', '$2y$10$wBBxL6lusR8r4Eux0nAsLOKtdPQIezLywhWXjcd0wpvJdyThbkCEC', NULL, '2018-03-21 08:33:52', '2018-03-21 08:33:52'),
(39, '002001066253101', '002001066253101@ijbber.com', '002001066253101', '$2y$10$AB2aGLs9ya0okZCkWMlOteK46JGWgMlCpCy9N6I97xiIMXdahoATG', NULL, '2018-03-21 08:34:44', '2018-03-21 08:34:44'),
(40, '009101066253102', '009101066253102@ijober.com', '009101066253102', '$2y$10$pbR1PBgSUFzTfBR0H1lbqOFEAkKZP0QLcD/eOOe0e3.cwnrsuLnVW', NULL, '2018-03-21 15:43:58', '2018-03-21 15:43:58'),
(41, '009101066253101', '009101066253101@ijober.com', '009101066253101', '$2y$10$ABVEAhdM4O0ZW0N7uHIObOwSCOA0Vn0VdqHHBfIelh8V2xgIgqN/2', NULL, '2018-03-21 15:45:03', '2018-03-21 15:45:03'),
(42, '009101064041779', '009101064041779@ijober.com', '009101064041779', '$2y$10$sQR8yZI7Zz/VdXaIUjEEpOOJFaCwH8mqltf.FnXuDZt.0BMzGkEIu', NULL, '2018-03-22 08:12:21', '2018-03-22 08:12:21'),
(43, '002012345978', '002012345978@ijober.com', '002012345978', '$2y$10$AS7FelBNB/4VqkqR3FLolOclx2Gs1J4s6kXyYb6b.k1uEMaRiVJN6', NULL, '2018-03-23 16:22:03', '2018-03-23 16:22:03'),
(44, '00201066253101', '00201066253101@ijober.com', '00201066253101', '$2y$10$z4oW7aQgR2NyXrfbqYYuzu.0J9h0YsosZATe66YKMBPrawr1h.yLm', NULL, '2018-03-24 14:08:26', '2018-03-24 14:08:26'),
(45, '002001020192526', '002001020192526@ijober.com', '002001020192526', '$2y$10$jsc.GKQN9ZH6rVJJq7ljpOwTKLvkKeawbiJa9BdiFgB8E5XWKHIEi', NULL, '2018-03-27 09:09:48', '2018-03-27 09:09:48'),
(46, '002001020192526', '002001020192526@ijbber.com', '002001020192526', '$2y$10$5FOKNPtjyZEmiZDwd4EWs.e7XlJgJiJj5PgdEzI8PtTnvLHVgIU9m', NULL, '2018-03-27 09:10:59', '2018-03-27 09:10:59'),
(47, '0020123456789', '0020123456789@ijober.com', '0020123456789', '$2y$10$UdXYNT9/Q4JJeenrLrCzdeqHzLnE4vgfQDln7GkSvnZiswON3rx5C', NULL, '2018-03-27 18:39:16', '2018-03-27 18:39:16'),
(48, '0020123456789', '0020123456789@ijbber.com', '0020123456789', '$2y$10$5KFTS3s1nclPJNI7pNgjNOjaxqVEmWo3Vc4JaW249CWPfyUU4oyiC', NULL, '2018-03-27 18:39:54', '2018-03-27 18:39:54'),
(49, '002001019584283', '002001019584283@ijober.com', '002001019584283', '$2y$10$Y4j6Nvl51QxxCB8JhleA7.qwD40kc9QSeMupglAR9Ty2ypa/lE0iu', NULL, '2018-03-27 20:18:24', '2018-03-27 20:18:24'),
(50, '002001223185749', '002001223185749@ijober.com', '002001223185749', '$2y$10$wKS7R6zqfCBVe4sn3z18QeasRnfW.pNJDEwXL/64epF31h5pEe.vC', NULL, '2018-03-30 17:40:16', '2018-03-30 17:40:16'),
(51, '002001223185749', '002001223185749@ijbber.com', '002001223185749', '$2y$10$fE9Lzmx34mmiJ8yvaBO4mOmOrUajIzUtK7XUxHd6/sXT5m5gexe/i', NULL, '2018-03-30 17:41:26', '2018-03-30 17:41:26'),
(52, '00201067672720', '00201067672720@ijober.com', '00201067672720', '$2y$10$WDPutoGd3bhxjz52CZ542u6vcd.fTGOf6d//VikDnbP8DGxKWrD8O', NULL, '2018-03-30 18:18:49', '2018-03-30 18:18:49'),
(53, '00201067672720', '00201067672720@ijbber.com', '00201067672720', '$2y$10$5yy27Hc6B9hP4l3RKZ6Kx.yW8nky3a43G4ggXyQMxy/r./HDXhIU2', NULL, '2018-03-30 18:20:23', '2018-04-24 09:59:54'),
(54, '201019584283', '201019584283@ijober.com', '201019584283', '$2y$10$3K7i5P3iCbFUGIi4ktSLYeFVvxgIuGO5MFZm8nyvX..h.yae6sDvW', NULL, '2018-03-30 20:42:44', '2018-03-30 20:42:44'),
(55, '0091556666555566', '0091556666555566@ijober.com', '0091556666555566', '$2y$10$OkiFIU7i5dBiQVDNb.57VeeWIch8RO0xMrJCDgLD97NQ8bheaZuu2', NULL, '2018-04-01 13:10:16', '2018-04-01 13:10:16'),
(56, '0091556668545454', '0091556668545454@ijober.com', '0091556668545454', '$2y$10$gU58kG99pw1y0vIcpazUEei3dsnAtdBiW5Sxv7.kThKRe0sLy9NtG', NULL, '2018-04-01 16:26:09', '2018-04-01 16:26:09'),
(57, '0091556668545454', '0091556668545454@ijbber.com', '0091556668545454', '$2y$10$.nJBeT0pHVjYyd.rc9SAoeqh.UoxxZ5k7CtG/lxcU6TZoh3CZ7Oqu', NULL, '2018-04-01 16:26:58', '2018-04-01 16:26:58'),
(58, '00201066253101', '00201066253101@ijbber.com', '00201066253101', '$2y$10$YuGMIOUspu.cAOxj05fnzeSN2goQEZk9nZw6RxqYB/cH4vpY4.l7e', NULL, '2018-04-02 18:43:16', '2018-04-02 18:43:16'),
(59, '0020166253101', '0020166253101@ijober.com', '0020166253101', '$2y$10$ibs2dRuUOqGg9yEX2CuMTu69xqrnxVBtO6q5mlZv5Dwdu3i47DYHu', NULL, '2018-04-02 18:54:10', '2018-04-02 18:54:10'),
(60, '00200166253101', '00200166253101@ijober.com', '00200166253101', '$2y$10$CBnE30eGgyl1JZyRG8G.EOEuSP3jJPW6RCVRqd9FJ.6DPJ.ziE4N.', NULL, '2018-04-02 18:54:20', '2018-04-02 18:54:20'),
(61, '002001067672722', '002001067672722@ijober.com', '002001067672722', '$2y$10$VDrtzAzHu9XIJwcr1qlGPOsWYrW6omIUXE.b3OyLWulQ/iNDwp6WG', NULL, '2018-04-04 19:35:36', '2018-04-04 19:35:36'),
(62, '002001067672722', '002001067672722@ijbber.com', '002001067672722', '$2y$10$wJCeihgZXx7haPMgg3Q0Oun1wywnHlB44Xk6uS3y2n3F03mo4EZvW', NULL, '2018-04-04 19:38:09', '2018-04-04 19:38:09'),
(65, '00201067676760', '00201067676760@ijober.com', '00201067676760', '$2y$10$2nTM0TRlkRZtP4GakiQgnuf9Zv0Fk2Msx/1SdtDUPiWp4JfCXzIeS', NULL, '2018-04-04 20:10:07', '2018-04-04 20:10:07'),
(66, '00201067676760', '00201067676760@ijbber.com', '00201067676760', '$2y$10$gYSIH72PPV/.oisnh543XOk.EHqGPd.JzfAXBjFPI6pFiWVCXR9r2', NULL, '2018-04-04 20:10:51', '2018-04-04 20:10:51'),
(67, '0020823838683938', '0020823838683938@ijober.com', '0020823838683938', '$2y$10$nCb6MIMfpO86whiHKvb9Z.4QHQuHIHQWEY6L2ez.lamYowxvDtyom', NULL, '2018-04-04 20:20:03', '2018-04-04 20:20:03'),
(68, '0020823838683938', '0020823838683938@ijbber.com', '0020823838683938', '$2y$10$V2N9McMWHkLeJOIbgK/1cOHMlqg/1O1.jxCcxzruFS.TPcakWw.1K', NULL, '2018-04-04 20:26:37', '2018-04-04 20:26:37'),
(69, '0091686868868657', '0091686868868657@ijober.com', '0091686868868657', '$2y$10$H6jaCLAJ/1u4MBPg56pcd.NJRHbDr6qUSpjbCjzwODJMxH0zJHhvm', NULL, '2018-04-05 15:55:25', '2018-04-05 15:55:25'),
(70, '002012345678', '002012345678@ijober.com', '002012345678', '$2y$10$wCHOaRrz/BRRjo1JkOFUcuEDsH8FfCFtClPxB6GZC3BqCohs2.Hey', NULL, '2018-04-06 18:16:42', '2018-04-06 18:16:42'),
(71, '0020112345678', '0020112345678@ijober.com', '0020112345678', '$2y$10$KRYr9E4aq44PXucD0i3E1e4zyB6Ji34eaIlXn3els/nNdzWJG3LF6', NULL, '2018-04-07 08:51:20', '2018-04-07 08:51:20'),
(72, '0020123385585', '0020123385585@ijober.com', '0020123385585', '$2y$10$Vghb46JHjMS2iNO.J0RHTed3JdR16DQsmROTtw.OhKFHND/dqC7hO', NULL, '2018-04-07 17:28:18', '2018-04-07 17:28:18'),
(73, '0020123456123', '0020123456123@ijober.com', '0020123456123', '$2y$10$93/m3WUMn.KcBmLxe.N5J.7VgWzvCRpfq1RMGAdxb72HtVeQeILUm', NULL, '2018-04-07 17:36:20', '2018-04-07 17:36:20'),
(74, '0091687657755757', '0091687657755757@ijober.com', '0091687657755757', '$2y$10$QlCRUVXUbRhAMwqRzZInzeVc3YO58Y.jHafZT4PvE3jJtWbu/RBIe', NULL, '2018-04-07 19:05:06', '2018-04-07 19:05:06'),
(75, '00918668242424', '00918668242424@ijober.com', '00918668242424', '$2y$10$TeQuSZT17vh63RuLNkFHnOKN82PRBLWY1PvzaWPrRl1yg47zkuf8y', NULL, '2018-04-07 21:04:51', '2018-04-07 21:04:51'),
(76, '0091676585686466', '0091676585686466@ijober.com', '0091676585686466', '$2y$10$BfAACIP4kxp93uPJch2tmuJHzSPFUukFKclZHAps2WJPFuujEuEZ.', NULL, '2018-04-08 00:11:25', '2018-04-08 00:11:25'),
(77, '0091855666888886', '0091855666888886@ijober.com', '0091855666888886', '$2y$10$xFIzHiEM9fOJLctgWuLkvO.qFx0vrMc.T/l6.MFkpuzWSgE6pZGCG', NULL, '2018-04-08 00:12:22', '2018-04-08 00:12:22'),
(78, '00918855588555', '00918855588555@ijober.com', '00918855588555', '$2y$10$xoXvzT/k8QX4w1o/rlTUd.YwqgRZ/aBtRs5ovYVKTFQ0YmQBwVMEC', NULL, '2018-04-08 11:16:18', '2018-04-08 11:16:18'),
(79, '00201067672722', '00201067672722@ijober.com', '00201067672722', '$2y$10$AzVeBZo1x7R.mv0VMQa2XeXrBtUv0FzP11NAe8sj9m.OnxpZR/xWq', NULL, '2018-04-08 16:45:02', '2018-04-08 16:45:02'),
(80, '0020123456124', '0020123456124@ijober.com', '0020123456124', '$2y$10$DTLqVWYQOiIetH.YvShO9.CSFaCniRTaoOqzGyo8vTZX7jOzGJ9DO', NULL, '2018-04-09 18:27:26', '2018-04-09 18:27:26'),
(81, '0020123456456', '0020123456456@ijober.com', '0020123456456', '$2y$10$vyAgS/7VGIKo5m9slhIaD.A0/JU4E7eh6I3eg2Jje6SnM6bpR.sg.', NULL, '2018-04-09 18:36:41', '2018-04-09 18:36:41'),
(82, '00201234567878', '00201234567878@ijober.com', '00201234567878', '$2y$10$j/QeYRu62iHdjkeDyeS6pOZoxLQ359MP87Qz17CbsiHwJ2GOaB6Sy', NULL, '2018-04-09 18:45:12', '2018-04-09 18:45:12'),
(83, '0020123456963', '0020123456963@ijober.com', '0020123456963', '$2y$10$jcnQzhSHeMV3cJB7F6xSfenbTXRQ.YYpFzYjmmSqfg8rSav88xF06', NULL, '2018-04-09 18:58:49', '2018-04-09 18:58:49'),
(84, '0020123456741', '0020123456741@ijober.com', '0020123456741', '$2y$10$u/k1kW/Fb7avhwpvjcIIReyBFJoDff4enE8aZ6j5M/BtNQwxhCjli', NULL, '2018-04-09 19:13:06', '2018-04-09 19:13:06'),
(85, '0020123654159', '0020123654159@ijober.com', '0020123654159', '$2y$10$8FVlnsMzrItLtVH9QL6CIuC3BsrX29xbGuEb3vHB8krcJTdE5gIBO', NULL, '2018-04-09 19:21:30', '2018-04-09 19:21:30'),
(86, '0020123456781', '0020123456781@ijober.com', '0020123456781', '$2y$10$h6lcTiyvse9QRVsQwNSYy.SNf4wvC1GDFO/vIpJlPILXwJEqtT4G2', NULL, '2018-04-09 19:28:55', '2018-04-09 19:28:55'),
(87, '00201067672723', '00201067672723@ijober.com', '00201067672723', '$2y$10$W5BQciqGI0cppo4o51reP.i3DlGkFRSrOkPJOMUEImS7KZxoI/0fe', NULL, '2018-04-13 10:19:45', '2018-04-13 10:19:45'),
(88, '002068900988855', '002068900988855@ijober.com', '002068900988855', '$2y$10$BFXDEY3cTJm.y2KevbSUmeauOBcwZ1JglKBEztNCXV2dkdSmN0GMq', NULL, '2018-04-13 10:30:57', '2018-04-13 10:30:57'),
(89, '0091555775283558', '0091555775283558@ijober.com', '0091555775283558', '$2y$10$MAGRP4w/H77xqh1S4fStOuFVO1xZkPdFi7CeJrKP7ZIdV4qUA/OS6', NULL, '2018-04-13 10:32:38', '2018-04-13 10:32:38'),
(91, '00201067672726', '00201067672726@ijober.com', '00201067672726', '$2y$10$Q.OVV8XdjRAuIgCeTJQTweiamsY8tbsxwZdcTAYN5SlZxhVFJ72AG', NULL, '2018-04-13 16:43:33', '2018-04-13 16:43:33'),
(92, '00201067672729', '00201067672729@ijober.com', '00201067672729', '$2y$10$FRrICXUiRqdx3.T//5.0he6B/kDadj1CU.X37jWf5vUOSrfW7kCgS', NULL, '2018-04-13 20:52:40', '2018-04-13 20:52:40'),
(93, '0020123456525', '0020123456525@ijober.com', '0020123456525', '$2y$10$AoZCfK9CLwiin/qbEpavR.nQbcXAOWTrzeqyWj7jjqp/WAke2B7Sa', NULL, '2018-04-14 12:32:16', '2018-04-14 12:32:16'),
(95, '0020123456369', '0020123456369@ijober.com', '0020123456369', '$2y$10$1TB4PRsXhhn99PtSwAL3aO6MJgjRdnHS3BGW3Q6/IHFZs3qBpRuXm', NULL, '2018-04-14 12:33:07', '2018-04-14 12:33:07'),
(96, '002010123456789', '002010123456789@ijober.com', '002010123456789', '$2y$10$qpWYh/Wqo1zvChZcVmIpROburq9hs2zUlTEUt0I44CFf22XBLWr1.', NULL, '2018-04-14 21:39:00', '2018-04-14 21:39:00'),
(97, '00204898959695', '00204898959695@ijober.com', '00204898959695', '$2y$10$voPTh.0vyEfH6RyegfE2Fe4/pgqUHZqxvdPBln1rDUGKS/xesnEGu', NULL, '2018-04-20 18:27:13', '2018-04-20 18:27:13'),
(98, '00966889965688656', '00966889965688656@ijober.com', '00966889965688656', '$2y$10$ep63g6GeUGssfw3OWtoGW.b2Dx4.S3pXyLgCkMfd/AQqLf0LI1HZS', NULL, '2018-04-22 11:07:14', '2018-04-22 11:07:14'),
(99, '00201019586366', '00201019586366@ijober.com', '00201019586366', '$2y$10$qAAFEHzOLjH65mIIVMfS2OwPN1ioOLxVnnGQKwk67ESQNlkP3sC/K', NULL, '2018-04-22 19:48:26', '2018-04-22 19:48:26'),
(100, '0020125434868686', '0020125434868686@ijober.com', '0020125434868686', '$2y$10$JhEDqx30K93/rx9.vO9PLOYYfX2wofsZoei.XZA9zCV8vw.PcvgfW', NULL, '2018-04-22 19:53:08', '2018-04-22 19:53:08'),
(101, '00204659898998', '00204659898998@ijober.com', '00204659898998', '$2y$10$H4OhgicWoKeV4/oAdQHTDODcJuRT5AlLhPa5fWndMQgdznK1XMSFy', NULL, '2018-04-22 19:57:57', '2018-04-22 19:57:57'),
(102, '00206589376494', '00206589376494@ijober.com', '00206589376494', '$2y$10$wpWu6YsG7LD13RfCdNXJVe6PzQRubyWPmQawPNu2B/tf3hHD1gO8G', NULL, '2018-04-22 20:24:24', '2018-04-22 20:24:24'),
(103, '0020565997767697', '0020565997767697@ijober.com', '0020565997767697', '$2y$10$hdSKlCCaq8FFAn.q9HDRSew1LgP0Q9eh4wUZOc9ZXlzKqbTXoe5jS', NULL, '2018-04-22 20:35:03', '2018-04-22 20:35:03'),
(104, '00209668252586', '00209668252586@ijober.com', '00209668252586', '$2y$10$4HbpaxcLPTIBfrro4Nzjb.3A35yknTvO1wX6ZNPw3IwkeHyygL0/S', NULL, '2018-04-22 20:38:46', '2018-04-22 20:38:46'),
(105, '009665757383535', '009665757383535@ijober.com', '009665757383535', '$2y$10$eqdNfXWJXkETcOB4BUSLieCbXy89wIgxNfKg54wE55diujY27JArm', NULL, '2018-04-23 11:13:44', '2018-04-23 11:13:44'),
(106, '00201067672725', '00201067672725@ijober.com', '00201067672725', '$2y$10$/Lq2oDvohcFFi6Wk0ctDZuPkElncxwEtBGHp1wO0Lj6rFkob5QJpu', NULL, '2018-04-23 22:23:11', '2018-04-23 22:23:11'),
(107, '00205659656565', '00205659656565@ijober.com', '00205659656565', '$2y$10$croZGLNJnOg66FQSDJIVeu.Gb54OAsysDs1HmgDS3UpLLnz974u2C', NULL, '2018-04-24 20:51:45', '2018-04-24 20:51:45'),
(108, '009660546628911', '009660546628911@ijober.com', '009660546628911', '$2y$10$9WEytkka1EVxIKa9vRt91udgh/N.TFpoEgnLQnpmvV91fJd97GFr2', NULL, '2018-04-25 22:14:25', '2018-04-25 22:14:25'),
(109, '0020111111112', '0020111111112@ijober.com', '0020111111112', '$2y$10$RoevM6YMeJbZ9fpseljzhegLQQ5gup29jn8GWyMfa..joK3M.DAmG', NULL, '2018-04-26 10:37:01', '2018-04-26 10:37:01'),
(110, '0020111111113', '0020111111113@ijober.com', '0020111111113', '$2y$10$mUtpLn9kMrXYde/6QTc7Y.L1iWSZUF8RazilR5NmoI..j1EO80dKG', NULL, '2018-04-26 10:47:53', '2018-04-26 10:47:53'),
(111, '00null', '00null@ijober.com', '00null', '$2y$10$IIpx3tw2uO.r9f4XVPItX.fjhL6C9trLPVk9HaAinSk7pZY80fbC.', NULL, '2018-04-26 10:55:59', '2018-04-26 10:55:59'),
(112, '0020894994979894', '0020894994979894@ijober.com', '0020894994979894', '$2y$10$e6quHkoZ/3VlKHR/cY0e8Om23KJeD4Nii3sS/pWQKb2pJTU4VlGWu', NULL, '2018-04-26 14:07:22', '2018-04-26 14:07:22'),
(113, '00201067672770', '00201067672770@ijober.com', '00201067672770', '$2y$10$LshvOAwM7BHGufrotO.HU.mx3Y8D/X5jOgoPAzpHrsplOIJaWXjbS', NULL, '2018-04-26 16:06:28', '2018-04-26 16:06:28'),
(114, '00201067672420', '00201067672420@ijober.com', '00201067672420', '$2y$10$f0SUJ.6xX9jfoDIKxmQaJ.3zOXTHGy48WSutZAqdt7j9kmm9hnLDu', NULL, '2018-04-26 16:07:37', '2018-04-26 16:07:37'),
(115, '0020235698865666', '0020235698865666@ijober.com', '0020235698865666', '$2y$10$jXm68DbNoRHaom3Zn7DRKeZvAMge4uAR0tc9Vr0812vrjl5ocSIVK', NULL, '2018-04-26 21:48:46', '2018-04-26 21:48:46'),
(116, '0020123456852', '0020123456852@ijober.com', '0020123456852', '$2y$10$nQ2ZIXHgwfRbx0gUmxCdeuR6o1DfKMxze4CTXY.dGQTQlZq3yHy.m', NULL, '2018-04-26 21:51:03', '2018-04-26 21:51:03'),
(117, '00201275922279', '00201275922279@ijober.com', '00201275922279', '$2y$10$PlijAoC31ThhGYQU2oRIRefl3CKK491Hy1ERp.IZfsfVAbA7NUbJ.', NULL, '2018-05-07 13:51:51', '2018-05-07 13:51:51'),
(118, '0020147258369', '0020147258369@ijober.com', '0020147258369', '$2y$10$cFhtO7DODhDoiZ56wsILhO.N0MxzmfHtcruYOCRwf52QxjUntP0MS', NULL, '2018-05-08 06:48:09', '2018-05-08 06:48:09'),
(119, '00201116732526', '00201116732526@ijober.com', '00201116732526', '$2y$10$sp1OwCokUOrl2RdUCjtLE.suZ6EHg3L1lLEflFcNct/2dqZAkGEOS', NULL, '2018-05-19 19:54:39', '2018-05-19 19:54:39'),
(120, '00201117773434', '00201117773434@ijober.com', '00201117773434', '$2y$10$NNHNhuEsON8JEeN2Ilw5zuZWOprcYz3ptt3tBX4oEGJ8V09A37sWq', NULL, '2018-05-19 19:58:01', '2018-05-19 19:58:01'),
(121, '0020123456782', '0020123456782@ijober.com', '0020123456782', '$2y$10$eauj36RgrOBHuJjDT06QuOZlFfjZz.ke8QzGcgi4zHXMDEr2rQTbu', NULL, '2018-05-21 23:18:48', '2018-05-21 23:18:48'),
(122, '0020123456987', '0020123456987@ijober.com', '0020123456987', '$2y$10$FQAZsozOChzJKMiL7pUUiOYanTiX3PIL2WhV6giI3VnOFlaXgZUlS', NULL, '2018-05-22 20:10:16', '2018-05-22 20:10:16'),
(123, '0020123456147', '0020123456147@ijober.com', '0020123456147', '$2y$10$EkWIjiA6HA.d/ZLAHGp/a.lXsONx8OTi/JDjRoGEoN/dc4QLfJp4K', NULL, '2018-05-22 20:27:07', '2018-05-22 20:27:07'),
(124, '0020123456321', '0020123456321@ijober.com', '0020123456321', '$2y$10$9IGaSsmuUd6R.cIcSh/rguOj8gv3LwzkpTKcp8zm4amWwS8ceWVx.', NULL, '2018-05-22 22:24:11', '2018-05-22 22:24:11'),
(125, '0020123789456', '0020123789456@ijober.com', '0020123789456', '$2y$10$Ea7Qs1/Y2aabIg/IAttC1emzll7TtJ1ox9bJyit7SPEwqwvyvjPMK', NULL, '2018-05-22 22:54:57', '2018-05-22 22:54:57'),
(126, '00201222213564', '00201222213564@ijober.com', '00201222213564', '$2y$10$QmAGzrAC5LZtibrzGmDZyuKw4VAK.sTW.Vebx/hd58hwaPjzLtOy6', NULL, '2018-05-22 23:48:59', '2018-05-22 23:48:59'),
(127, '00966343535646868', '00966343535646868@ijober.com', '00966343535646868', '$2y$10$7NoTkze5xWDpGSnhy5Ap/uW.TYv5laDKIcb8mZJkGomwy85Gxptxm', NULL, '2018-05-23 12:59:00', '2018-05-23 12:59:00'),
(128, '0096655555588888', '0096655555588888@ijober.com', '0096655555588888', '$2y$10$c621wgVdIE/tbVBhCopwPeTBzp3N.XfGTa9WVsCvYtSGSLjo9tXp.', NULL, '2018-05-24 10:01:38', '2018-05-24 10:01:38'),
(129, '009665805822850', '009665805822850@ijober.com', '009665805822850', '$2y$10$daFWugBh4hpMmN/vXS12xeG85QeMLvJpjDg1QmAwYsS5.9V5Nmh72', NULL, '2018-05-25 09:20:34', '2018-05-25 09:20:34'),
(130, '009666858588588', '009666858588588@ijober.com', '009666858588588', '$2y$10$HH3rGQEfsF3jpGUfPLxeousniVI4fsLy/rfXnPdfrlyliF6G9BrKK', NULL, '2018-05-25 14:10:28', '2018-05-25 14:10:28'),
(131, '00966055005505058', '00966055005505058@ijober.com', '00966055005505058', '$2y$10$tnhCRl7czgHKFpVkBfezceDrbHMg3jiku401P6wLTp5v/vUdg3Asq', NULL, '2018-05-25 14:12:34', '2018-05-25 14:12:34'),
(132, '009668228505028', '009668228505028@ijober.com', '009668228505028', '$2y$10$q0bPBvfltvePTT.NB6jh4.YL1ZvFeA.kGHdrNsTojJGHkcteo1WG2', NULL, '2018-05-25 14:15:47', '2018-05-25 14:15:47'),
(133, '0020123456951', '0020123456951@ijober.com', '0020123456951', '$2y$10$gGUvGHkHkv2ANsZCFtnn6e7JY5d57EdpmscWbqsJj9/zKFDDz.1F2', NULL, '2018-05-28 23:14:28', '2018-05-28 23:14:28'),
(134, '009669999999855', '009669999999855@ijober.com', '009669999999855', '$2y$10$Sr915IA2P012kBW3J12EAuueiY53iZYhkfHawZGi9cB.zkXxAhMTS', NULL, '2018-05-30 23:54:44', '2018-05-30 23:54:44'),
(135, '009665082283860', '009665082283860@ijober.com', '009665082283860', '$2y$10$xcs7e6aI5sk0LeOb0nbjLOCrbmSCgq3bNkaPCZWdhUUFBcZ70GlQm', NULL, '2018-05-30 23:58:59', '2018-05-30 23:58:59'),
(136, '0020123456234', '0020123456234@ijober.com', '0020123456234', '$2y$10$nuszlqZ7O28nD45mBudfte1Adni1TJ48w5SWMkZLqwiLg8rYuKRsS', NULL, '2018-05-31 07:12:10', '2018-05-31 07:12:10'),
(137, '0020123456351', '0020123456351@ijober.com', '0020123456351', '$2y$10$JQ9yLAQONJvylZRUC1CnQ.texXWI.w9q.RrGdYXwxA8xY9MXDtwzK', NULL, '2018-05-31 07:16:15', '2018-05-31 07:16:15'),
(138, '0096688888552880', '0096688888552880@ijober.com', '0096688888552880', '$2y$10$ApL.RZ0Ac4B66spYJAKHDOHVg8O4/U76xA7239oFLbnqeOKc/IgA2', NULL, '2018-05-31 09:01:03', '2018-05-31 09:01:03'),
(139, '0020123456489', '0020123456489@ijober.com', '0020123456489', '$2y$10$ipKyUCa7p616UQH4U3xzYuBRmUc/dEhoqYJIiEwyIJayZAOx/dj.m', NULL, '2018-05-31 09:11:35', '2018-05-31 09:11:35'),
(140, '0020123426351', '0020123426351@ijober.com', '0020123426351', '$2y$10$Mxo2VGH9DiBUkgn5tHK3T.mv/1JqtdfposojQv5goaUXxzw2.qeha', NULL, '2018-05-31 20:49:03', '2018-05-31 20:49:03'),
(141, '0020106767272720', '0020106767272720@ijober.com', '0020106767272720', '$2y$10$G4Z.V0pX4yuWWHJS0kx9lu8bq2hfsAn8vKbtI6FGHpt/R9YGUBhxG', NULL, '2018-05-31 22:57:06', '2018-05-31 22:57:06'),
(142, '009660565720839', '009660565720839@ijober.com', '009660565720839', '$2y$10$tVNz1IMTczDd/NLzuanBpeq6dX23u5z3eZ8pyop4kdaPnjL/5Ix02', NULL, '2018-06-06 13:27:17', '2018-06-06 13:27:17'),
(143, '009661019584283', '009661019584283@ijober.com', '009661019584283', '$2y$10$LLX9liBdo37Y8PI8/70epeVgDa7xkZerw07OyexRmfdIhbPtVpyPu', NULL, '2018-06-09 22:46:33', '2018-06-09 22:46:33'),
(144, '+966546628911', '+966546628911@ijober.com', '+966546628911', '$2y$10$AMkolqK/WfPTML2rpInpjuZD5VOv0k2wFEAHMikxVFORee30GZI4C', NULL, '2018-06-09 22:51:16', '2018-06-09 22:51:16'),
(145, '+201019584283', '+201019584283@ijober.com', '+201019584283', '$2y$10$hzU5Md0Dtz7KgjTSbfu7We//JmdS2XpCMRZ4oLo.NRdlNhWwdWIuq', NULL, '2018-06-09 22:52:07', '2018-06-09 22:52:07'),
(146, '009665466289411', '009665466289411@ijober.com', '009665466289411', '$2y$10$sTZOrQcgN/vg6.gUsxihf.AtaSjETkjLTsQpfOZ/Kw7yP26YpQYrK', NULL, '2018-06-13 12:24:56', '2018-06-13 12:24:56'),
(147, '00966565720839', '00966565720839@ijober.com', '00966565720839', '$2y$10$5YnjjnxR.ZM7Cf5XOcydKuLxgivZdKhwBMvr.ItWXHKa/D1qxkGNu', NULL, '2018-06-13 15:54:06', '2018-06-13 15:54:06'),
(148, '00966561779934', '00966561779934@ijober.com', '00966561779934', '$2y$10$3kxYTbtSAn6hE90vXGU26eJuZv/GB3oA2a2QJfkCeVb9c.t1t8tb.', NULL, '2018-06-20 06:52:57', '2018-06-20 06:52:57'),
(149, '009660561779934', '009660561779934@ijober.com', '009660561779934', '$2y$10$8KNp35YAMDpRwErMHWTb7eBV93Y9WJHQKtQYyJwI1MhJWaDZreJ.q', NULL, '2018-06-20 06:54:35', '2018-06-20 06:54:35'),
(150, '00201019548283', '00201019548283@ijober.com', '00201019548283', '$2y$10$lHDR9pvOhzGK7zWQpBC1ceCo4ZkAzPqfrhg/SozfGz8aaYjglN6B6', NULL, '2018-06-23 14:06:15', '2018-06-23 14:06:15'),
(151, '002001001882649', '002001001882649@ijober.com', '002001001882649', '$2y$10$cjrfHqPSGtz5zlfXhVbGge60oKDwyQH4hUQxqguVyzFnN3A6r/BW6', NULL, '2018-06-25 00:43:09', '2018-06-25 00:43:09'),
(152, '00200106767272', '00200106767272@ijober.com', '00200106767272', '$2y$10$md.TlghWtZz69h6tBLr8fONyxWZf1kOjpIA/DJIkn7LOt8W1jk9KO', NULL, '2018-06-26 00:06:14', '2018-06-26 00:06:14'),
(153, '00249924595046', '00249924595046@ijober.com', '00249924595046', '$2y$10$8/QWQ51zNmDRNvwlDarQ6ODurjxndc0foT34NG8he9C7WnwGJr4ee', NULL, '2018-06-26 08:47:23', '2018-06-26 08:47:23'),
(154, '00966009660546628', '00966009660546628@ijober.com', '00966009660546628', '$2y$10$3LAamUtw.EbnfnAnVXIWdeKlkXfZ6OnbfEsQhUHWrwoWT40T0Y5du', NULL, '2018-06-29 13:12:52', '2018-06-29 13:12:52'),
(155, '0020123456115', '0020123456115@ijober.com', '0020123456115', '$2y$10$lWSL6hbDq3uOqHw1UHSyIePQF9oC3MvHx/Bm3KVFdsWT0lQkSHNRu', NULL, '2018-06-29 13:47:49', '2018-06-29 13:47:49'),
(156, '00201097972720', '00201097972720@ijober.com', '00201097972720', '$2y$10$up2ELVwQXFxqF/Qnmf2loefkoad2aldU6KcWpS3tffJ8WSWBmdA6O', NULL, '2018-06-29 14:05:43', '2018-06-29 14:05:43');

-- --------------------------------------------------------

--
-- Table structure for table `user_companies`
--

CREATE TABLE `user_companies` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `region_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_contacts`
--

CREATE TABLE `user_contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_contacts`
--

INSERT INTO `user_contacts` (`id`, `profile_id`, `user_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(67, 19, 29, '2018-04-02 18:33:51', '2018-04-02 18:33:51', NULL),
(98, 18, 24, '2018-04-02 20:57:55', '2018-04-02 20:57:55', NULL),
(99, 24, 18, '2018-04-03 09:08:42', '2018-04-03 09:08:42', NULL),
(100, 24, 29, '2018-04-03 09:08:42', '2018-04-03 09:08:42', NULL),
(118, 37, 29, '2018-04-04 21:08:03', '2018-04-04 21:08:03', NULL),
(141, 58, 7, '2018-04-13 10:45:14', '2018-04-13 10:45:14', NULL),
(142, 58, 29, '2018-04-13 10:45:14', '2018-04-13 10:45:14', NULL),
(157, 56, 7, '2018-04-13 16:23:50', '2018-04-13 16:23:50', NULL),
(203, 59, 29, '2018-04-15 21:30:22', '2018-04-15 21:30:22', NULL),
(210, 28, 2, '2018-04-23 16:21:33', '2018-04-23 16:21:33', NULL),
(211, 28, 10, '2018-04-23 16:21:33', '2018-04-23 16:21:33', NULL),
(212, 28, 28, '2018-04-23 16:21:33', '2018-04-23 16:21:33', NULL),
(347, 86, 7, '2018-05-07 14:12:27', '2018-05-07 14:12:27', NULL),
(348, 86, 26, '2018-05-07 14:12:27', '2018-05-07 14:12:27', NULL),
(349, 86, 59, '2018-05-07 14:12:27', '2018-05-07 14:12:27', NULL),
(519, 111, 12, '2018-06-13 15:24:07', '2018-06-13 15:24:07', NULL),
(520, 111, 12, '2018-06-13 15:24:08', '2018-06-13 15:24:08', NULL),
(521, 111, 6, '2018-06-13 15:24:09', '2018-06-13 15:24:09', NULL),
(522, 111, 6, '2018-06-13 15:24:09', '2018-06-13 15:24:09', NULL),
(649, 7, 10, '2018-06-21 20:20:19', '2018-06-21 20:20:19', NULL),
(650, 7, 28, '2018-06-21 20:20:24', '2018-06-21 20:20:24', NULL),
(651, 7, 58, '2018-06-21 20:20:25', '2018-06-21 20:20:25', NULL),
(652, 7, 86, '2018-06-21 20:20:27', '2018-06-21 20:20:27', NULL),
(653, 7, 29, '2018-06-21 20:20:34', '2018-06-21 20:20:34', NULL),
(718, 26, 65, '2018-06-23 08:30:00', '2018-06-23 08:30:00', NULL),
(719, 26, 10, '2018-06-23 08:30:00', '2018-06-23 08:30:00', NULL),
(720, 26, 24, '2018-06-23 08:30:01', '2018-06-23 08:30:01', NULL),
(721, 26, 7, '2018-06-23 08:30:01', '2018-06-23 08:30:01', NULL),
(722, 26, 6, '2018-06-23 08:30:01', '2018-06-23 08:30:01', NULL),
(723, 26, 26, '2018-06-23 08:30:02', '2018-06-23 08:30:02', NULL),
(724, 26, 29, '2018-06-23 08:30:03', '2018-06-23 08:30:03', NULL),
(849, 116, 12, '2018-06-25 22:26:52', '2018-06-25 22:26:52', NULL),
(850, 116, 6, '2018-06-25 22:26:53', '2018-06-25 22:26:53', NULL),
(851, 116, 29, '2018-06-25 22:26:56', '2018-06-25 22:26:56', NULL),
(873, 115, 29, '2018-06-25 23:35:50', '2018-06-25 23:35:50', NULL),
(874, 115, 18, '2018-06-25 23:35:55', '2018-06-25 23:35:55', NULL),
(875, 115, 7, '2018-06-25 23:35:55', '2018-06-25 23:35:55', NULL),
(876, 115, 117, '2018-06-25 23:36:02', '2018-06-25 23:36:02', NULL),
(877, 115, 116, '2018-06-25 23:36:04', '2018-06-25 23:36:04', NULL),
(878, 115, 116, '2018-06-25 23:36:04', '2018-06-25 23:36:04', NULL),
(879, 115, 12, '2018-06-25 23:36:07', '2018-06-25 23:36:07', NULL),
(880, 115, 12, '2018-06-25 23:36:07', '2018-06-25 23:36:07', NULL),
(1101, 121, 29, '2018-06-26 19:15:27', '2018-06-26 19:15:27', NULL),
(1102, 121, 29, '2018-06-26 19:15:27', '2018-06-26 19:15:27', NULL),
(1103, 121, 18, '2018-06-26 19:15:30', '2018-06-26 19:15:30', NULL),
(1104, 121, 7, '2018-06-26 19:15:30', '2018-06-26 19:15:30', NULL),
(1105, 121, 18, '2018-06-26 19:15:30', '2018-06-26 19:15:30', NULL),
(1106, 121, 7, '2018-06-26 19:15:30', '2018-06-26 19:15:30', NULL),
(1181, 12, 117, '2018-06-28 22:23:13', '2018-06-28 22:23:13', NULL),
(1182, 12, 117, '2018-06-28 22:23:13', '2018-06-28 22:23:13', NULL),
(1183, 12, 117, '2018-06-28 22:23:13', '2018-06-28 22:23:13', NULL),
(1184, 12, 109, '2018-06-28 22:23:13', '2018-06-28 22:23:13', NULL),
(1185, 12, 6, '2018-06-28 22:23:14', '2018-06-28 22:23:14', NULL),
(1186, 12, 109, '2018-06-28 22:23:14', '2018-06-28 22:23:14', NULL),
(1205, 113, 26, '2018-06-29 12:37:18', '2018-06-29 12:37:18', NULL),
(1206, 113, 7, '2018-06-29 12:37:18', '2018-06-29 12:37:18', NULL),
(1207, 113, 77, '2018-06-29 12:37:18', '2018-06-29 12:37:18', NULL),
(1208, 113, 115, '2018-06-29 12:37:18', '2018-06-29 12:37:18', NULL),
(1225, 29, 26, '2018-06-29 13:12:12', '2018-06-29 13:12:12', NULL),
(1226, 29, 7, '2018-06-29 13:12:12', '2018-06-29 13:12:12', NULL),
(1227, 29, 77, '2018-06-29 13:12:12', '2018-06-29 13:12:12', NULL),
(1228, 123, 26, '2018-06-29 13:14:46', '2018-06-29 13:14:46', NULL),
(1229, 123, 7, '2018-06-29 13:14:46', '2018-06-29 13:14:46', NULL),
(1230, 123, 77, '2018-06-29 13:14:46', '2018-06-29 13:14:46', NULL),
(1237, 124, 26, '2018-06-29 13:55:38', '2018-06-29 13:55:38', NULL),
(1238, 124, 7, '2018-06-29 13:55:38', '2018-06-29 13:55:38', NULL),
(1239, 124, 77, '2018-06-29 13:55:38', '2018-06-29 13:55:38', NULL),
(1240, 95, 26, '2018-06-29 14:21:10', '2018-06-29 14:21:10', NULL),
(1241, 95, 7, '2018-06-29 14:21:10', '2018-06-29 14:21:10', NULL),
(1242, 95, 77, '2018-06-29 14:21:10', '2018-06-29 14:21:10', NULL),
(1246, 117, 26, '2018-06-29 14:25:16', '2018-06-29 14:25:16', NULL),
(1247, 117, 7, '2018-06-29 14:25:16', '2018-06-29 14:25:16', NULL),
(1248, 117, 77, '2018-06-29 14:25:16', '2018-06-29 14:25:16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `work_experience`
--

CREATE TABLE `work_experience` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile_id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `to` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `work_experience`
--

INSERT INTO `work_experience` (`id`, `profile_id`, `title`, `company_name`, `from`, `to`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 59, 'Android', 'Wett', '2018-04-13 04:52:05', '2018-04-13 04:52:06', '2018-04-13 14:52:17', '2018-04-13 14:52:17', NULL),
(2, 60, 'ffgh', 'xcf', '2018-04-10 06:44:02', '2018-04-28 06:44:05', '2018-04-13 16:44:09', '2018-04-13 16:44:09', NULL),
(3, 61, 'gccgvhhvhv', 'g cgg', '2018-04-10 10:53:04', '2018-04-13 10:53:07', '2018-04-13 20:53:17', '2018-04-13 20:53:17', NULL),
(10, 69, 'Hghh', 'Dygg', '2018-04-22 09:53:25', '2018-04-22 09:53:26', '2018-04-22 19:53:39', '2018-04-22 19:53:39', NULL),
(11, 71, 'Ftygg', 'Fggg', '2018-04-22 10:25:30', '2018-04-22 10:25:34', '2018-04-22 20:25:40', '2018-04-22 20:25:40', NULL),
(12, 72, 'Dhdh', 'Fhfhfh', '2018-04-22 10:37:02', '2018-04-23 10:37:05', '2018-04-22 20:37:17', '2018-04-22 20:37:17', NULL),
(13, 73, 'Rtfggg', 'Fggghh', '2018-04-22 10:39:19', '2018-04-27 10:39:21', '2018-04-22 20:39:35', '2018-04-22 20:39:35', NULL),
(14, 28, 'Senior Backend Engineer', 'Bey2ollak', '2015-08-09 00:00:00', '2018-04-04 00:00:00', '2018-04-22 21:41:02', '2018-04-22 21:41:02', NULL),
(15, 28, 'Senior Backend Engineer', 'Intellisc', '2014-08-09 00:00:00', '2015-08-08 00:00:00', '2018-04-22 21:41:02', '2018-04-22 21:41:02', NULL),
(16, 74, 'gjvkv', 'dddd', '2018-04-23 01:15:58', '2018-04-27 01:16:01', '2018-04-23 11:16:01', '2018-04-23 11:16:01', NULL),
(17, 75, 'bh', 'vbn', '2018-04-19 12:23:30', '2018-04-27 12:23:32', '2018-04-23 22:24:04', '2018-04-23 22:24:04', NULL),
(22, 79, 'Ajdbdb', 'Hrjeh', '2018-04-26 12:48:16', '2018-04-26 12:48:17', '2018-04-26 11:12:38', '2018-04-26 11:12:38', NULL),
(49, 86, 'project Manager', 'worcbox', '2017-11-01 04:05:46', '2018-05-31 04:05:56', '2018-05-07 14:11:02', '2018-05-07 14:11:02', NULL),
(58, 90, 'Qrwysu', '11', '2018-05-01 01:19:10', '2018-05-08 01:19:14', '2018-05-21 23:19:34', '2018-05-21 23:19:34', NULL),
(59, 91, 'Ghh', 'Fftt', '2018-05-22 10:11:07', '2018-05-31 10:11:09', '2018-05-22 20:11:35', '2018-05-22 20:11:35', NULL),
(60, 87, 'Fyyg', 'Tyyy', '2018-05-09 10:25:31', '2018-05-22 20:25:43', '2018-05-22 20:25:43', '2018-05-22 20:25:43', NULL),
(62, 92, 'Hvhj', 'Guh', '2018-05-08 10:27:25', '2018-05-22 20:27:39', '2018-05-22 22:23:30', '2018-05-22 22:23:30', NULL),
(68, 26, '', 'fhhhh', '2018-04-26 04:56:16', '2018-04-27 04:56:18', '2018-05-24 10:28:27', '2018-05-24 10:28:27', NULL),
(69, 26, '', 'dhdh', '2018-04-26 04:57:04', '2018-04-27 04:57:05', '2018-05-24 10:28:27', '2018-05-24 10:28:27', NULL),
(70, 26, '', '1111', '2018-04-21 04:57:11', '2018-04-27 04:57:13', '2018-05-24 10:28:27', '2018-05-24 10:28:27', NULL),
(71, 26, '', 'aaa', '2018-04-29 11:13:33', '2018-04-29 21:13:45', '2018-05-24 10:28:27', '2018-05-24 10:28:27', NULL),
(72, 97, 'ggb', 'yyxyc', '2018-05-16 12:02:40', '2018-05-19 12:02:42', '2018-05-24 11:00:04', '2018-05-24 11:00:04', NULL),
(73, 101, 'f  t t ', 'vuuvuv', '2018-05-16 04:16:56', '2018-05-31 04:16:58', '2018-05-25 14:16:59', '2018-05-25 14:16:59', NULL),
(76, 102, 'Fhhg', '11', '2018-05-15 01:14:48', '2018-05-28 23:15:02', '2018-05-28 23:43:10', '2018-05-28 23:43:10', NULL),
(78, 103, 'zz', '', '2018-05-20 01:55:16', '2018-05-30 23:55:19', '2018-05-30 23:56:00', '2018-05-30 23:56:00', NULL),
(79, 104, 'yy', ' ghvj ', '2018-05-16 01:59:16', '2018-05-30 23:59:20', '2018-05-30 23:59:20', '2018-05-30 23:59:20', NULL),
(80, 107, 'vv', '', '2018-05-11 11:01:34', '2018-05-31 09:01:47', '2018-05-31 09:01:47', '2018-05-31 09:01:47', NULL),
(81, 106, 'Fyy', '', '1970-01-01 02:00:00', '1970-01-01 02:00:00', '2018-05-31 20:59:00', '2018-05-31 20:59:00', NULL),
(82, 110, 'manager', 'worcbox', '2018-06-01 12:57:35', '2018-06-30 12:57:37', '2018-05-31 22:57:47', '2018-05-31 22:57:47', NULL),
(86, 111, 'Mechanical Engineer & solar', 'Park Energy', '2017-02-01 08:41:38', '2018-06-06 17:44:46', '2018-06-10 19:18:30', '2018-06-10 19:18:30', NULL),
(87, 115, 'Biomedical engineer', 'Rehab Al-Safwa Co.', '2015-06-13 03:26:04', '2018-06-13 12:27:45', '2018-06-13 12:27:45', '2018-06-13 12:27:45', NULL),
(89, 116, 'mechnical engineer ', 'park energy', '2017-02-01 05:54:41', '2018-06-13 15:55:09', '2018-06-13 15:56:39', '2018-06-13 15:56:39', NULL),
(93, 120, '', 'I.tec ', '2014-06-01 02:54:54', '2017-12-31 02:55:11', '2018-06-25 01:03:50', '2018-06-25 01:03:50', NULL),
(94, 121, 'P', '', '1970-01-01 03:00:00', '1970-01-01 03:00:00', '2018-06-26 00:07:08', '2018-06-26 00:07:08', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `group_jobs`
--
ALTER TABLE `group_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `group_users`
--
ALTER TABLE `group_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs_appliers`
--
ALTER TABLE `jobs_appliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs_forwards`
--
ALTER TABLE `jobs_forwards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs_hidden`
--
ALTER TABLE `jobs_hidden`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_transaction`
--
ALTER TABLE `job_transaction`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `job_transaction_job_id_profile_id_unique` (`job_id`,`profile_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_token`
--
ALTER TABLE `profile_token`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_transaction`
--
ALTER TABLE `profile_transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_companies`
--
ALTER TABLE `user_companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_contacts`
--
ALTER TABLE `user_contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `work_experience`
--
ALTER TABLE `work_experience`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `group_jobs`
--
ALTER TABLE `group_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `group_users`
--
ALTER TABLE `group_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;

--
-- AUTO_INCREMENT for table `jobs_appliers`
--
ALTER TABLE `jobs_appliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `jobs_forwards`
--
ALTER TABLE `jobs_forwards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `jobs_hidden`
--
ALTER TABLE `jobs_hidden`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `job_transaction`
--
ALTER TABLE `job_transaction`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=232;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=108;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=126;

--
-- AUTO_INCREMENT for table `profile_token`
--
ALTER TABLE `profile_token`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `profile_transaction`
--
ALTER TABLE `profile_transaction`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;

--
-- AUTO_INCREMENT for table `user_companies`
--
ALTER TABLE `user_companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_contacts`
--
ALTER TABLE `user_contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1249;

--
-- AUTO_INCREMENT for table `work_experience`
--
ALTER TABLE `work_experience`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
