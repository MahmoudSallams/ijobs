-- phpMyAdmin SQL Dump
-- version 4.7.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 13, 2018 at 01:34 PM
-- Server version: 5.7.24-0ubuntu0.16.04.1
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ijobs_db_1`
--

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `region` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `status` int(10) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `members_counts` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `name`, `image`, `members_counts`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Jobs', 'https://static.easygenerator.com/wp-content/uploads/2013/09/demo.jpg', 2, 1, '2018-07-07 16:23:48', '2018-07-07 16:23:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `group_jobs`
--

CREATE TABLE `group_jobs` (
  `id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `job_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `group_users`
--

CREATE TABLE `group_users` (
  `id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `profile_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `group_users`
--

INSERT INTO `group_users` (`id`, `group_id`, `profile_id`, `status`, `is_admin`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 134, 1, 1, '2018-07-07 16:23:48', '2018-07-07 16:23:48', NULL),
(2, 1, 136, 1, 0, '2018-07-07 16:23:49', '2018-07-07 16:23:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_url` text COLLATE utf8mb4_unicode_ci,
  `applied_count` int(11) DEFAULT '0',
  `forwarded_count` int(11) DEFAULT '0',
  `shared_count` int(11) DEFAULT '0',
  `profile_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `description`, `image`, `file_url`, `applied_count`, `forwarded_count`, `shared_count`, `profile_id`, `group_id`, `parent_id`, `contact_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(235, 'title', '‏فرص وظيفية في جدة للجنسين:\n1- operations\n2- Business development\n\nالي مهتم يراسل:  cv@jakapp.co\n👆', NULL, NULL, 1, 1, 0, 134, NULL, NULL, NULL, -1, '2018-06-29 22:02:44', '2018-06-30 11:28:45', NULL),
(236, 'title', 'لمن يهمة الامر', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IMG-20180630-WA00031530312498896.jpg', NULL, 1, 2, 0, 136, NULL, NULL, NULL, 1, '2018-06-29 22:48:47', '2018-06-29 23:06:50', NULL),
(237, 'title', 'السلام عليكم\nمطلوب لشركه رائده تعمل في مجال الدعايا والإعلان منسقين عروض لشركات موبايلات\nبراتب 4000 ريال\nيشترط وجود سياره\nيشترط مصريين فقط \nمكان العمل\n( أبها - خميس مشيط - جيزان - صابيا - شار', NULL, NULL, 1, 2, 0, 134, NULL, NULL, NULL, 1, '2018-06-29 22:50:44', '2018-06-29 23:07:35', '2018-06-29 23:07:35'),
(238, 'title', 'مطلوب فنى إلكترونيات لمصنع بالعبور(اجهزة طبية)..\nالخبره : 0-1\nالمرتب يحدد فى المقابلة\nمواعيد العمل : 7:30ص -4م وجمعة وسبت اجازة\nالمواصلات : يوجد اتوبيس\nالتأمينات : يوجد تامينات إجتماعية\nيوجد', NULL, NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-06-30 13:11:13', '2018-06-30 13:11:13', NULL),
(239, 'title', 'Digital marketing', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IMG-20180702-WA00611530538008512.jpg', NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-02 13:27:08', '2018-07-02 13:27:08', NULL),
(240, 'title', 'شئون عاملين', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IMG-20180702-WA00601530538056274.jpg', NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-02 13:27:48', '2018-07-02 13:27:48', NULL),
(241, 'title', 'محاسب', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IMG-20180702-WA00591530538116640.jpg', NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-02 13:28:45', '2018-07-02 13:28:45', NULL),
(242, 'title', 'وظائف إدارية وإجتماعية', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/IMG-20180702-WA00581530538156288.jpg', NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-02 13:29:34', '2018-07-02 13:29:34', NULL),
(243, 'title', '👈 وظائف شركه Xceed\nمطلوب ممثلين خدمه عملاء #دعم_فني 🎧\n👈 المميزات :\n- المرتب : 3000 .\n- مكان العمل #مدينه_نصر .\n- فرص للترقي علي حسب الأداء الوظيفي بعد 6 شهور .\n- الشيفت 9 ساعات منهم ساعه ب', NULL, NULL, 0, 1, 0, 134, NULL, NULL, NULL, 1, '2018-07-02 23:02:06', '2018-07-08 21:15:25', NULL),
(244, 'title', 'Magic Pharma\nis a fast growing Cosmo-pharmaceutical company in Egyptian market and due to our expansion seeking to recruit qualified candidate for following position\nFull Time Medical Represe', NULL, NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-04 20:17:26', '2018-07-04 20:17:26', NULL),
(245, 'title', 'Technical support engineer', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/Screenshot_20180704-2337401530736691908.png', NULL, 1, 0, 0, 134, NULL, NULL, NULL, -1, '2018-07-04 20:38:40', '2018-07-08 21:28:26', NULL),
(246, 'title', 'N A:\nمطلوب لشركة كبرى تمتلك محطات توليد كهربا الوظائف التالية :\n1- مهندسين كهربا قوى واجهزة وتحكم  تشغيل وصيانة  خبرة من 3 الى 5 سنوات  فى مجال المحطات التوليد الكهربا  من قاطنى الاسكندرية .', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/Screenshot_20180704-2337401530736691908.png', NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-05 05:34:26', '2018-07-05 05:35:14', '2018-07-05 05:35:14'),
(247, 'title', 'N A:\nمطلوب لشركة كبرى تمتلك محطات توليد كهربا الوظائف التالية :\n1- مهندسين كهربا قوى واجهزة وتحكم  تشغيل وصيانة  خبرة من 3 الى 5 سنوات  فى مجال المحطات التوليد الكهربا  من قاطنى الاسكندرية .', 'https://s3.amazonaws.com/ijobar-userfiles-mobilehub-66294234/uploads/Screenshot_20180704-2337401530736691908.png', NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-05 05:35:00', '2018-07-05 05:35:09', '2018-07-05 05:35:09'),
(248, 'title', 'N A:\nمطلوب لشركة كبرى تمتلك محطات توليد كهربا الوظائف التالية :\n1- مهندسين كهربا قوى واجهزة وتحكم  تشغيل وصيانة  خبرة من 3 الى 5 سنوات  فى مجال المحطات التوليد الكهربا  من قاطنى الاسكندرية .\n2- مهندسين ميكانيكا صيانة  خبرة من 3 الى 5 سنوات  فى مجال المحطات التوليد الكهرباء من قاطنى الاسكندرية ..\n3- مهندسين كهرباء قوى حمابة خبرة من 3 الى 5 سنوات  فى مجال المحطات التوليد الكهربا من قاطنى الاسكندرية .\n4- مطلوب فنيين كهربا وميكانيكا واجهزة وتحكم خبرة لاتق عن 3- 10 سنوات من قاطنى الاسكندرية .\n5- مطلوب اداريين مؤهلات عليا خبرة لاتقل عن 3- 5 سنوات  فى الشئئون الادارية ,لديهم خبرة بالمصانع الكبرى  .\n6- مطلوب مهندسين مبيعات وتسويق خبرة من 5 سنوات الى 10 من قاطنى الاسكندرية والقاهرة .\n8- مطلوب مهندسين شئون فنية كهربا وميكانيكا  لديهم خبرة بالمحطات الكهربا خبرة من 3-5 سنوات من قاطنى القاهرة الكبرى .\nيرجى ارسال السيرة الذاتية على الايميل المرفق  :\nehab_hussien@kahraba.com.eg', NULL, NULL, 1, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-05 05:35:32', '2018-07-08 21:15:00', NULL),
(249, 'title', 'N A:\nمطلوب لشركة كبرى تمتلك محطات توليد كهربا الوظائف التالية :\n1- مهندسين كهربا قوى واجهزة وتحكم  تشغيل وصيانة  خبرة من 3 الى 5 سنوات  فى مجال المحطات التوليد الكهربا  من قاطنى الاسكندرية .', NULL, NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-05 05:35:43', '2018-07-05 05:35:49', '2018-07-05 05:35:49'),
(250, 'title', 'Nadeen:\nAl-Mansour Automotive is hiring for a business development opportunity in the Network Development department. \nJob Requirements:\n- Bachelor\'s degree\n- minimum 4 years experience (pref', NULL, NULL, 1, 0, 0, 134, NULL, NULL, NULL, -1, '2018-07-05 05:37:08', '2018-07-08 21:16:38', NULL),
(251, 'title', 'Required for Ministry of Health in KSA the following Medical Majors  : \nHael City :\n1- Emergency\n2- Orthopedics.\n3- Gynecologists.\n4- Anesthetist.\n5- Neurosurgery.\n6- Internists.\n7- Radiologi', NULL, NULL, 1, 0, 0, 134, NULL, NULL, NULL, -1, '2018-07-06 20:51:53', '2018-07-08 21:15:32', NULL),
(252, 'title', 'fufufuif', NULL, NULL, 0, 0, 0, 133, NULL, NULL, NULL, -1, '2018-07-08 11:56:03', '2018-07-08 11:56:12', NULL),
(253, 'title', 'yestclise', NULL, NULL, 1, 0, 0, 133, NULL, NULL, NULL, -1, '2018-07-08 20:45:06', '2018-07-08 20:50:53', NULL),
(254, 'title', 'test', NULL, NULL, 0, 0, 0, 133, NULL, NULL, NULL, -1, '2018-07-08 20:46:25', '2018-07-08 20:46:39', NULL),
(255, 'title', 'موسسه كبرى بالمملكه السعوديه تطلب التخصصات الاتيه:\nاولا: مهندسين اتصالات وفنيين وتيمات ليدر خبره فى\n( Huawei, Ericsson,NEC)\nثانيا: مهندسين و فنيين خبره فى تركيب شبكات كمبيوتر\n(Network)\nثالثا: محاسبيين خبره (مطلوب مصريين فقط )\nيقتصر الاعلان على المقيمون داخل المملكة العربية السعودية  \n( نقل كفاله)\nعلى من يرغب التقدم للوظائف الاتيه برجاء ارسال C.V\nعلى futureaset.ksa@gmail.com\nأو التواصل على الواتس آب على رقم 00201007594779\nأو الاتصال على رقم 0565393318', NULL, NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-10 13:54:28', '2018-07-10 13:54:28', NULL),
(256, 'title', 'مطلوب (مهندسة أجهزة طبية) حديثىة التخرج \nللعمل (in door) شرط من سكان القاهرة\n يرجى ارسال CV على الايميل \nالخاص بالشركة (sec@elfagr-med.com)\nمع كتابة (مهندسة اجهزة طبية) فى خانة (subject)', NULL, NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-11 15:28:39', '2018-07-11 15:28:39', NULL),
(257, 'title', 'https://careers.riyadbank.com/job-detail.php?jid=kN2qWpRMHa::CbKCnTA5U0xtRdv69OXVzuKLRSPEDqRg=', NULL, NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-16 20:10:49', '2018-07-16 20:10:49', NULL),
(258, 'title', 'Vodatech company need engineers and technicians with experience from one to two years in Huawei, Ericsson equipment.\n\nIf you are interested ,send your cv to HR@vodatechltd.com \ninfo@vodatechl', NULL, NULL, 0, 0, 0, 134, NULL, NULL, NULL, 1, '2018-07-24 07:05:13', '2018-07-24 07:05:13', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jobs_appliers`
--

CREATE TABLE `jobs_appliers` (
  `id` int(11) NOT NULL,
  `job_id` int(11) DEFAULT NULL,
  `profile_id` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jobs_appliers`
--

INSERT INTO `jobs_appliers` (`id`, `job_id`, `profile_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(104, 235, 136, 0, '2018-06-29 22:38:16', NULL, NULL),
(105, 237, 136, 0, '2018-06-29 22:51:35', NULL, NULL),
(106, 236, 134, 0, '2018-06-29 23:05:08', NULL, NULL),
(107, 251, 136, 0, '2018-07-07 16:33:02', NULL, NULL),
(108, 253, 131, 0, '2018-07-08 20:50:26', NULL, NULL),
(109, 248, 136, 0, '2018-07-08 21:15:00', NULL, NULL),
(110, 245, 136, 0, '2018-07-08 21:15:09', NULL, NULL),
(111, 250, 136, 0, '2018-07-08 21:16:19', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jobs_forwards`
--

CREATE TABLE `jobs_forwards` (
  `id` int(10) UNSIGNED NOT NULL,
  `job_id` int(11) NOT NULL DEFAULT '0',
  `profile_id` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `jobs_forwards`
--

INSERT INTO `jobs_forwards` (`id`, `job_id`, `profile_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(91, 235, -1, '2018-06-29 22:45:44', NULL, NULL),
(92, 236, 134, '2018-06-29 22:48:59', NULL, NULL),
(93, 237, -1, '2018-06-29 22:50:58', NULL, NULL),
(94, 237, 136, '2018-06-29 23:02:49', NULL, NULL),
(95, 236, -1, '2018-06-29 23:06:50', NULL, NULL),
(96, 243, 134, '2018-07-08 21:15:25', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jobs_hidden`
--

CREATE TABLE `jobs_hidden` (
  `id` int(10) UNSIGNED NOT NULL,
  `job_id` int(11) NOT NULL DEFAULT '0',
  `profile_id` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_transaction`
--

CREATE TABLE `job_transaction` (
  `id` int(10) UNSIGNED NOT NULL,
  `job_id` int(11) NOT NULL,
  `profile_id` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `job_transaction`
--

INSERT INTO `job_transaction` (`id`, `job_id`, `profile_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(253, 235, 136, 2, '2018-06-29 22:38:16', '2018-06-29 22:38:16', NULL),
(256, 237, 136, 2, '2018-06-29 22:51:35', '2018-06-29 22:51:35', NULL),
(259, 236, 134, 2, '2018-06-29 23:05:08', '2018-06-29 23:05:08', NULL),
(260, 251, 136, 2, '2018-07-07 16:33:02', '2018-07-07 16:33:02', NULL),
(261, 253, 131, 2, '2018-07-08 20:50:26', '2018-07-08 20:50:26', NULL),
(264, 248, 136, 3, '2018-07-08 21:15:00', '2018-07-08 21:15:00', NULL),
(265, 245, 136, 2, '2018-07-08 21:15:09', '2018-07-08 21:15:09', NULL),
(267, 250, 136, 2, '2018-07-08 21:16:19', '2018-07-08 21:16:19', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(19, '2014_10_12_000000_create_users_table', 1),
(20, '2014_10_12_100000_create_password_resets_table', 1),
(21, '2018_01_24_092135_create_pages_table', 1),
(22, '2018_01_24_153934_create_profiles_table', 1),
(23, '2018_01_24_155122_create_jobs_table', 1),
(24, '2018_01_24_155417_create_groups_table', 1),
(25, '2018_03_15_000552_add_is_admin_column', 2),
(26, '2018_03_25_014752_change_jobs_counts_default_values', 3),
(27, '2018_03_25_020823_create_table_job_forwards', 3),
(28, '2018_03_25_030619_create_table_jobs_hidden', 3),
(29, '2018_03_25_223710_create_table_jobs_transactions', 4),
(30, '2018_03_26_231152_change_profile_columns', 5),
(31, '2018_03_26_235318_create_user_contacts_table', 5),
(32, '2018_04_02_025603_create_profile_transaction_table', 6),
(33, '2018_04_04_193743_add_columns_to_profiles', 7),
(34, '2018_04_04_200512_create_work_experience_table', 7),
(35, '2018_04_05_061842_create_profile_tokens_table', 7),
(36, '2018_04_28_224446_create_notifications_table', 8);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile_id` int(11) NOT NULL,
  `token_id` int(11) NOT NULL,
  `body` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_type` int(11) NOT NULL DEFAULT '0',
  `action_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `success` int(11) NOT NULL DEFAULT '0',
  `sending_result` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_new` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`id`, `profile_id`, `token_id`, `body`, `action_type`, `action_value`, `success`, `sending_result`, `is_new`, `created_at`, `updated_at`, `deleted_at`) VALUES
(149, 134, 125, 'Shady helmy has applied to a new job', 1, '[\"235\"]', 1, '[{\"message_id\":\"0:1530311896205035%378826f2f9fd7ecd\"}]', 0, '2018-06-29 22:38:16', '2018-06-29 22:38:16', NULL),
(150, 134, 125, 'New Job Forwarded to you', 1, '[\"236\"]', 1, '[{\"message_id\":\"0:1530312539159353%378826f2f9fd7ecd\"}]', 0, '2018-06-29 22:48:59', '2018-06-29 22:48:59', NULL),
(151, 134, 125, 'Shady helmy has applied to a new job', 1, '[\"237\"]', 1, '[{\"message_id\":\"0:1530312695731289%378826f2f9fd7ecd\"}]', 0, '2018-06-29 22:51:35', '2018-06-29 22:51:35', NULL),
(152, 136, 129, 'New Job Forwarded to you', 1, '[\"237\"]', 1, '[{\"message_id\":\"0:1530313369722665%378826f2f9fd7ecd\"}]', 0, '2018-06-29 23:02:49', '2018-06-29 23:02:49', NULL),
(153, 136, 129, 'Mohamed Salah has applied to a new job', 1, '[\"236\"]', 1, '[{\"message_id\":\"0:1530313508171750%378826f2f9fd7ecd\"}]', 0, '2018-06-29 23:05:08', '2018-06-29 23:05:08', NULL),
(154, 136, 129, 'The Job has been deleted', 0, '[]', 1, '[{\"message_id\":\"0:1530313655066044%378826f2f9fd7ecd\"}]', 0, '2018-06-29 23:07:35', '2018-06-29 23:07:35', NULL),
(155, 136, 129, 'The Job has been closed', 0, '[]', 1, '[{\"message_id\":\"0:1530358125519799%378826f2f9fd7ecd\"}]', 0, '2018-06-30 11:28:45', '2018-06-30 11:28:45', NULL),
(156, 136, 129, 'You have been added to a group', 2, '[\"1\"]', 1, '[{\"message_id\":\"0:1530980630116489%378826f2f9fd7ecd\"}]', 0, '2018-07-07 16:23:50', '2018-07-07 16:23:50', NULL),
(157, 134, 125, 'Shady helmy has applied to a new job', 1, '[\"251\"]', 1, '[{\"message_id\":\"0:1530981183242325%378826f2f9fd7ecd\"}]', 0, '2018-07-07 16:33:03', '2018-07-07 16:33:03', NULL),
(158, 136, 129, 'The Job has been closed', 0, '[]', 1, '[{\"message_id\":\"0:1531039795314957%378826f2f9fd7ecd\"}]', 0, '2018-07-08 08:49:55', '2018-07-08 08:49:55', NULL),
(159, 133, 128, 'Hesham Abboud has applied to a new job', 1, '[\"253\"]', 1, '[{\"message_id\":\"0:1531083027340936%378826f2f9fd7ecd\"}]', 0, '2018-07-08 20:50:27', '2018-07-08 20:50:27', NULL),
(160, 131, 122, 'The Job has been closed', 0, '[]', 1, '[{\"message_id\":\"0:1531083053574405%378826f2f9fd7ecd\"}]', 1, '2018-07-08 20:50:53', '2018-07-08 20:50:53', NULL),
(161, 134, 125, 'Shady helmy has applied to a new job', 1, '[\"248\"]', 1, '[{\"message_id\":\"0:1531084501297729%378826f2f9fd7ecd\"}]', 0, '2018-07-08 21:15:01', '2018-07-08 21:15:01', NULL),
(162, 134, 125, 'Shady helmy has applied to a new job', 1, '[\"245\"]', 1, '[{\"message_id\":\"0:1531084509847976%378826f2f9fd7ecd\"}]', 0, '2018-07-08 21:15:09', '2018-07-08 21:15:09', NULL),
(163, 134, 125, 'New Job Forwarded to you', 1, '[\"243\"]', 1, '[{\"message_id\":\"0:1531084525642218%378826f2f9fd7ecd\"}]', 0, '2018-07-08 21:15:25', '2018-07-08 21:15:25', NULL),
(164, 136, 129, 'The Job has been closed', 0, '[]', 1, '[{\"message_id\":\"0:1531084532288791%378826f2f9fd7ecd\"}]', 0, '2018-07-08 21:15:32', '2018-07-08 21:15:32', NULL),
(165, 134, 125, 'Shady helmy has applied to a new job', 1, '[\"250\"]', 1, '[{\"message_id\":\"0:1531084580218572%378826f2f9fd7ecd\"}]', 0, '2018-07-08 21:16:20', '2018-07-08 21:16:20', NULL),
(166, 136, 129, 'The Job has been closed', 0, '[]', 1, '[{\"message_id\":\"0:1531084598278655%378826f2f9fd7ecd\"}]', 0, '2018-07-08 21:16:38', '2018-07-08 21:16:38', NULL),
(167, 136, 129, 'The Job has been closed', 0, '[]', 1, '[{\"message_id\":\"0:1531085307074611%378826f2f9fd7ecd\"}]', 0, '2018-07-08 21:28:27', '2018-07-08 21:28:27', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `title`, `slug`, `description`, `deleted_at`, `updated_at`, `created_at`) VALUES
(1, 'About ijobar', 'en', 'I Jobar is an interactive platform designed specifically for users who have jobs in their company or in their field to share with Their friends are in the list of names where most of them are mostly in Your domain is registered in your phone contact list as a user Of the owners of companies, clients and business friends and these are the most people who deal with the user in the labor market and therefore are more aware of your abilities and your scientific and practical possibilities.\r\n\r\nTherefore, the application of ijobar works on several axes are as follows:\r\n1 - A brief profile, simple and easy user and the nature of his work.\r\n2. Possibility to add functionality easily if you are looking for an employee.\r\n3 - The possibility of applying for the job through the same application.\r\n4. Alert users from the list of names you have in your job status which may give you a very suitable job once you leave your job at any time.\r\n5 - The possibility of sending a job to a friend.\r\n6- Possibility of working in the same field of work.\r\n7 - Diversity of job status options in respect of your experience and your scientific and practical abilities when you leave a job between the option of \'free\' and is an option for those with high positions and the great experience and the aspiration to work for many companies ... The option \'wants work\' for new graduates and those who want to form New practical experiences and in need of suitable work for them.\r\n\r\nThen, the application of iJobar can as a user obtain the following:\r\n1 - You may get a very suitable job once you change your career in the application of iJobar and this is really wonderful.\r\n1. Do not miss a job that may be closer to you than you imagine and this will save you a lot of trouble.\r\n2 - As you are looking for a job you will get a job suitable for your abilities and your scientific and practical experience and this saves you some time and effort in the search for a suitable job.\r\n3 - As advertised for a job you will find an efficient employee for this job suitable for your business environment and the nature of your company or your origin.\r\n4 - As a user you can send the post to a friend may be suitable for this post.\r\n5. As a user, you can create business groups between your friends and hence more diverse business functions in your field.\r\n\r\n\r\n\r\nOur vision\r\nOur vision in iJobar is to be a good choice for the user looking for a job that suits his ambitions and the user who is looking for a competent employee suitable for his company or its origin.\r\n\r\nOur goal\r\nOne of the objectives of Egobar:\r\n1. Do not miss a job opportunity that may be close to the user.\r\n2 - benefit the user from the circle of acquaintances and friends of work to obtain a job suited to his ambitions.\r\n3 - To provide the time and effort of the user to obtain a suitable job has a material return to suit his own.\r\n4 - to find the user the appropriate job in his specially even in the most specialized disciplines, whatever this specialty rare or a few of those working in it.\r\n5. The society should benefit from all scientific and practical expertise and specialization and put all human energy in its proper place in order to achieve maximum benefit for society.', NULL, '2018-07-08 23:21:47', '2018-07-08 23:21:54'),
(2, 'عن آي جوبار', 'ar', 'آي جوبار هو منصة تفاعلية صممت خصيصا للمستخدمين الذين لديهم وظائف فى شركاتهم او فى مجال عملهم لمشاركتها مع\r\nأصدقائهم فى قائمة الأسماء حيث فى الأغلب معظم الذيين فى\r\nمجال عملك يكونون مسجليين فى قائمة الأسماء لديك كمستخدم\r\nمن أصحاب شركات وعملاء وأصدقاء عمل وهؤلاء هم اكثر الناس  الذين يتعامل معهم المستخدم فى سوق العمل وبالتالى هم اكثر معرفة بقدراتك وامكانياتك العلمية والعملية .\r\nلذلك تطبيق آي جوبار يعمل على عدة محاور هى كالتالى:\r\n1-ملف تعريفى مختصر,بسيط وسهل بالمستخدم وطبيعة عمله.\r\n2-امكانية إضافة وظيفة بسهولة ويسر إذا كنت تبحث عن موظف .\r\n3-إمكانية التقدم للوظيفة عن طريق التطبيق نفسه.\r\n4-تنبيه المستخدمين من قائمة الاسماء لديك بحالتك الوظيفة وهو ما قد يتيح لك وظيفة مناسبة جدا بمجرد تركك عملك فى اى وقت.\r\n5- إمكانية إرسال وظيفة لصديق.\r\n6-إمكانية عمل جروبات عمل فى نفس مجال عملك.\r\n7- تنوع خيارات الحالة الوظيفة احتراما لخبراتك  وقدراتك العلمية والعملية عند تركك وظيفة ما ما بين خيار انك\" حر\" وهو خيار لذوى المناصب الرفيعة والخبرات الكبيرة و المطلوبيين  للعمل لدى كثير من الشركات.... وخيار\" يريد عمل\" للخريجيين الجدد  والذيين يريدون تكوين خبرات عملية جديدة وفى حاجة الى عمل مناسب لهم. \r\n وبالتالى من تطبيق آي جوبار تستطيع كمستخدم أن تحصل على الآتى:\r\n1-قد تحصل على وظيفة مناسبة جدا بمجرد تغير حالتك الوظيفية فى تطبيق إيجوبار وهذا رائع حقا.\r\n1-ان لا تفوت فرصة عمل قد تكون قريبة منك أكثر مما تتخيل وهذا يوفر لك كثير من العناء.\r\n2-كونك تبحث عن وظيفة ستحصل على وظيفة مناسبة لقدراتك وخبراتك العلمية والعملية وهذا يوفر عليك بعض الوقت والجهد فى البحث عن وظيفة مناسبة.\r\n3-كمعلن عن وظيفة ستجد الموظف الكفء لهذه الوظيفة المناسب لبيئة عملك و طبيعة شركتك او منشئتك .\r\n4-كمستخدم تستطيع ان ترسل الوظيفة الى صديق اليك قد يكون مناسب لهذه الوظيفة . \r\n5- تستطيع كمستخدم ان تنشاء مجموعات عمل بين اصدقائك وبالتالى مزيد من وظائف العمل المتنوعة فى مجال عملك.\r\n\r\nرؤيتنا\r\nرؤيتنا فى آي جوبار أن نكون الخيار الجيد للمستخدم الباحث عن وظيفة تلائم طموحاته والمستخدم الذى يبحث عن موظف كفء مناسب لشركته أو مناشئته.\r\n\r\nهدفنا \r\nمن أهداف إيجوبار :\r\n1-أن لا نفوت فرصة عمل قد تكون قريبة من المستخدم .\r\n2- أستفادة المستخدم من دائرة معارفة وأصدقاء العمل فى الحصول على فرصة عمل تلائم طموحاته.\r\n3-توفير وقت وجهد المستخدم فى الحصول على وظيفة مناسبة له ذات عائد مادى يلائم تطلاعاته.\r\n4-أن يجد المستخدم الوظيفة المناسبة فى تخصصه حتى فى ادق التخصصات مهما كان هذا التخصص نادر أو قليل من يعملون فيه.\r\n5- ان يستفيد المجتمع من كل الخبرات والتخصصات العلمية والعملية ووضع كل طاقة بشرية فى مكانها المناسب بما يحقق الاستفادة القصوى للمجتمع .', NULL, '2018-07-08 23:21:47', '2018-07-08 23:21:54'),
(3, 'Privacy Policy', 'en', 'Privacy Statement\r\nWe appreciate your interest and your concerns about the privacy of your data on the Internet.\r\nThis policy is designed to help you understand the nature of the data we collect from you when\r\nyou installed ijobar App. and how we handle this personal data.\r\nBrowsing\r\nWe did not design this application to collect your personal data from your mobile phone or tablet\r\ndevice during your use of the application, but only the data provided by you will be used with\r\nyour knowledge and of your own free will.\r\nInternet Protocol (IP) address\r\nAnytime the application is used, the host server will register your IP address,\r\ndate and time of visit.\r\nNetwork surveys\r\nOur online surveys enable us to collect specific data such as the data required of you regarding\r\nyour view and feel about our application. Your feedback is of paramount importance and is\r\nappreciated as it enables us to improve the application level, and you are free to choose other\r\ndata.\r\nLinks to other sites on the Internet\r\nThe application may include links to other sites on the Internet. Or banners from other sites such\r\nas Google AdSens we are not responsible for the data collection practices of such sites you can\r\nsee the privacy and content policies for those sites accessed through any link within that app.\r\nDisclosure of information\r\nAt all times we will maintain the privacy and confidentiality of all personal data we receive.\r\nThis information will only be disclosed if required under any law or when we believe in good\r\nfaith that such action will be required or desirable to comply with the law or to defend or protect\r\nthe property rights of such application or its beneficiaries.\r\nData required performing transactions required by you\r\nWhen we need any data of your own, we will ask you to submit it of your own volition. This\r\ninformation will help us to contact you, improve the service provided by the application and\r\nimplement your requests wherever possible.\r\nThe data provided by you to any third party will not be sold for marketing without the prior\r\nconsent of you, provided that it is a collective data used for statistical purposes and research\r\nwithout including any data that may be used to introduce you.\r\n\r\nWhen you contact us\r\nAll data provided by you will be treated as confidential.\r\nThe data provided by you will be used to respond to all your inquiries, feedback or requests\r\nsubmitted to us by e-mail.\r\nModifications to the privacy policy and privacy of information\r\nWe reserve the right to modify the terms and conditions of the privacy policy and the privacy of\r\nthe information if necessary and when appropriate.\r\nThe amendments will be implemented here or on the main privacy policy page and you will be\r\nconstantly informed of the data we have obtained, how we will use it and who will provide it\r\nwith this data.\r\nFinally\r\nYour concerns about privacy and confidentiality are very important to us. We hope that this will\r\nbe achieved through this policy.', NULL, '2018-07-08 23:22:11', '2018-07-08 23:22:11'),
(4, 'سياسة الخصوصية', 'ar', 'الخصوصية وبيان سريّة المعلومات\r\nنقدر مخاوفكم واهتمامكم بشأن خصوصية بياناتكم على شبكة الإنترنت.\r\nلقد تم إعداد هذه السياسة لمساعدتكم في تفهم طبيعة البيانات التي نقوم بتجميعها منكم عند تنزيلكم تطبيق آي\r\nجوبار و كيفية تعاملنا مع هذه البيانات الشخصية.\r\nالتصفح\r\nلم نقم بتصميم هذا التطبيق من أجل تجميع بياناتك الشخصية من على هاتفك الجوال او جهازك اللوحى الخاص بك\r\nأثناءأثناء أستخدامك للتطبيق, وإنما سيتم فقط استخدام البيانات المقدمة من قبلك بمعرفتك ومحض إرادتك.\r\nعنوان بروتوكول شبكة الإنترنت (IP)\r\nفي أي وقت تستخد فيه التطبيق , سيقوم السيرفر المضيف بتسجيل عنوان بروتوكول شبكة الانترنت الخاص بك\r\nتاريخ ووقت الزيارة.(IP)\r\nعمليات المسح على الشبكة\r\nإن عمليات المسح التي نقوم بها مباشرة على الشبكة تمكننا من تجميع بيانات محددة مثل البيانات المطلوبة منك\r\nبخصوص نظرتك وشعورك تجاه التطبيق.تعتبر ردودك ذات أهمية قصوى , ومحل تقديرنا حيث أنها تمكننا من تحسين\r\nمستوى التطبيق, ولك كامل الحرية والإختيار البيانات الأخرى.\r\nالروابط بالمواقع الأخرى على شبكة الإنترنت\r\nقد يشتمل التطبيق على روابط بالمواقع الأخرى على شبكة الإنترنت. او علانات من مواقع اخرى مثل\r\nولا نعتبر مسئولين عن أساليب جمع البيانات من قبل تلك المواقع https://www.google.com/adsenseمثل\r\n, يمكنك الاطلاع على سياسات السرية والمحتويات الخاصة بتلك المواقع التي يتم الدخول إليها من خلال أي رابط ضمن\r\nهذا التطبيق.\r\nإفشاء المعلومات\r\nسنحافظ في كافة الأوقات على خصوصية وسرية كافة البيانات الشخصية التي نتحصل عليها. ولن يتم إفشاء هذه\r\nالمعلومات إلا إذا كان ذلك مطلوباً بموجب أي قانون أو عندما نعتقد بحسن نية أن مثل هذا الإجراء سيكون مطلوباً أو\r\nمرغوباً فيه للتمشي مع القانون , أو للدفاع عن أو حماية حقوق الملكية الخاصة بهذا التطبيق أو الجهات المستفيدة منه.\r\nالبيانات اللازمة لتنفيذ المعاملات المطلوبة من قبلك\r\nعندما نحتاج إلى أية بيانات خاصة بك , فإننا سنطلب منك تقديمها بمحض إرادتك. حيث ستساعدنا هذه المعلومات في\r\nالاتصال بك,تحسين الخدمة التى يقدمها التطبيق وتنفيذ طلباتك حيثما كان ذلك ممكنناً. لن يتم اطلاقاً بيع البيانات\r\nالمقدمة من قبلك إلى أي طرف ثالث بغرض تسويقها لمصلحته الخاصة دون الحصول على موافقتك المسبقة ما لم يتم\r\nذلك على أساس أنها ضمن بيانات جماعية تستخدم للأغراض الإحصائية والأبحاث دون اشتمالها على أية بيانات من\r\nالممكن استخدامها للتعريف بك.\r\nعند الاتصال بنا\r\nسيتم التعامل مع كافة البيانات المقدمة من قبلك على أساس أنها سرية . سيتم استخدام البيانات التي يتم تقديمها\r\nمن قبلك في الرد على كافة استفساراتك , ملاحظاتك , أو طلباتك المقدمه الينا من قبلك عن طريق البريد الألكترونى.\r\nالتعديلات على سياسة سرية وخصوصية المعلومات\r\nنحتفظ بالحق في تعديل بنود وشروط سياسة سرية وخصوصية المعلومات إن لزم الأمر ومتى كان ذلك ملائماً. سيتم\r\nتنفيذ التعديلات هنا او على صفحة سياسة الخصوصية الرئيسية وسيتم بصفة مستمرة إخطارك بالبيانات التي حصلنا\r\nعليها , وكيف سنستخدمها والجهة التي سنقوم بتزويدها بهذه البيانات.\r\nاخيرا\r\nإن مخاوفك واهتمامك بشأن سرية وخصوصية البيانات تعتبر مسألة في غاية الأهمية بالنسبة لنا. نحن نأمل أن يتم\r\nتحقيق ذلك من خلال هذه السياسة.', NULL, '2018-07-08 23:24:36', '2018-07-08 23:24:36'),
(5, 'faq', 'en', '1-How do I add a job?\r\nWhen you press + you can add job post at the \"New Jobs\" and between the list of groups the\r\nparties and you can go to \"New Jobs\" and write a post in the bottom list to be posted among the\r\nlist of contacts on the application only.\r\n2. How to apply for a job through application?\r\nOn each job post posted there is a sign for the options when you click on the \"Apply to\" option\r\nscreen to apply to this job.\r\n3 - How to follow the status of the job you submitted?\r\nYou can go to the \"Applied Jobs\" page and see the status of the job or be \"seen\" which means\r\nthat the job publisher has already seen your profile or \"waiting\" meaning that you are waiting\r\nfor the job publisher to see your file.\r\n4. What is the difference between adding a post via the + sign and writing a\r\njob in a \"new job\"?\r\nWhen you click on the + sign, you can a job post among your contacts and choose between the\r\ngroups to publish it. Writing a job in a \"New Jobs\" is not possible to add to the groups you\r\nhave.\r\n5 - How did the group and what the laws of the group?\r\nBy clicking on the \"New Group\" tab, you can add a group and add your friends in the group.\r\nWhen you add a friend to the group, you can add your friends to the list and they will be on the\r\nwaiting list for 24 hours, and you have the right as the admin to accept or reject them and if you\r\ndon’t press anything during this period they will be in the group already. You can add up to two\r\nat most as your sub-admin but they are not entitled to change the name of the group nor the\r\ngroup picture but have the right to accept or reject the new members.\r\n6 - If you are a job publisher and only registered for this job - Log in to the\r\njob while maintaining the file of registrants for the current job?\r\nYou can go to the \"Published Jobs\" and choose the function to disable \"Apply to\" by users and\r\nchoose \"Close\" from options, which will delete the post from \"New Jobs\" while retaining the\r\njob and the list of users they make \"Apply to\" in the \"Jobs published\"', NULL, '2018-07-08 23:46:57', '2018-07-08 23:46:57'),
(6, 'faq', 'ar', '1- كيف أضيف وظيفة ؟\r\nعند الضغط على + يمكنك كتابة الوظيفة ونشرها بين قائمة الاسماء نشرها بين المجموعات كما يمكنك أيضا الضغط على \"وظيفة جديدة\" وكتابة\r\nوظيفة فى القائمة السفلية لنشرها بين قائمة الاسماء فقط.\r\n2- كيف التقدم لوظيفة من خلال التطبيق ؟\r\nعند كل وظيفة منشورة يوجد علامة للخيارات عند الضغط عليها ستجد خيار \"سجل للوظيفه\" وذلك للتقدم الى الوظيفة .\r\n3- كيفية متابعة حالة الوظيفة التى تقدمت لها ؟\r\nيمكنك الضغط على \"الوظائف المقدم عليها\" ورؤية حالة الوظيفة اما ان تكون \"تمت رؤيتها\" وهذا يعنى ان ناشر الوظيفة قد رآى ملفك بالفعل او\r\n\"أنتظار\" ومعناها أنك فى انتظار رؤية ناشر الوظيفة لملفك .\r\n4- ما الفرق بين اضافة وظيفة عن طريق العلامة + وكتابة الوظيفة فى \"وظيفة جديدة\" ؟\r\nعند الضغط على علامة + تستطيع كتابة وظيفة نشرها بين المستخدمين لديك والاختيار ما بين الجروبات لنشرها فيه أما كتابة وظيفة فى \"وظيفة\r\nجديدة\" فليس هناك أمكانية لاضافتها للجروبات التى لديك .\r\n5- كيفية عمل جروب وماهى قوانين الجروب ؟\r\nبالضغط على علامة \"مجموعة جديدة\" يمكنك إضافة جروب وإضافة اصدقائك فى الجروب وعند أضافتك صديق للجروب تستطيع إضافى اصدقائة فى\r\nالقائمة ويكونوا على قائمة الانتظار لمدة 24 ساعة ولك الحق فى هذة المدة كأدمن للجروب قبولهم او رفضهم وفى عدم الضغط على اى شىء خلال هذة\r\nالمدة سيكونوا داخل الجروب بالفعل كما تستطيع كأدمن تعيين أثنينن على الاكثر كمساعدين لك ولكن لا يحق لهم تغير اسم المجموعة ولا صورة\r\nالمجموعة ولكن لهم الحق فى قبول الاعضاء الجدد المعلقين او رفضهم .\r\n6- أذا كنت ناشر وظيفة وتم الاكتفاء بالمسجليين لهذه الوظيفة واردت ان اغلق التسجيل للوظيفة مع الاحتفاظ\r\nبملف المسجليين للوظيفة الحاليين ؟\r\nيمكنك الذهاب الى \"الوظائف المنشورة\" وأختيار الوظيفة المراد تعطيل التسجيل لها من قبل المستخدمين وأختيار \"أغلاق\" من الخيارات والذى سوف\r\nيقوم بحذف الوظيفة من صفحة النشر مع الاحتفاظ بالوظيفة و قائمة المسجليين اليها فى \"الوظائف المنشورة\"', NULL, '2018-07-08 23:53:03', '2018-07-08 23:53:03');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` int(10) UNSIGNED NOT NULL,
  `invited_id` int(11) DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int(11) NOT NULL DEFAULT '0',
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country_code` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `local_mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_verify_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_verify_status` int(11) NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_work_from` timestamp NULL DEFAULT NULL,
  `current_work_to` timestamp NULL DEFAULT NULL,
  `region_id` int(11) NOT NULL DEFAULT '0',
  `country_id` int(11) NOT NULL DEFAULT '0',
  `city_id` int(11) NOT NULL DEFAULT '0',
  `company_updated_at` timestamp NULL DEFAULT NULL,
  `country_updated_at` timestamp NULL DEFAULT NULL,
  `region_updated_at` timestamp NULL DEFAULT NULL,
  `city_updated_at` timestamp NULL DEFAULT NULL,
  `title_updated_at` timestamp NULL DEFAULT NULL,
  `workfield` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workfieldother` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `school` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brief` text COLLATE utf8mb4_unicode_ci,
  `photo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `scientific_qualifications` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `invited_id`, `first_name`, `last_name`, `email`, `age`, `mobile`, `country_code`, `local_mobile`, `other_mobile`, `mobile_verify_code`, `mobile_verify_status`, `title`, `company_name`, `current_work_from`, `current_work_to`, `region_id`, `country_id`, `city_id`, `company_updated_at`, `country_updated_at`, `region_updated_at`, `city_updated_at`, `title_updated_at`, `workfield`, `workfieldother`, `school`, `gender`, `brief`, `photo`, `status`, `scientific_qualifications`, `created_at`, `updated_at`, `deleted_at`) VALUES
(131, NULL, 'Hesham', 'Abboud', NULL, 0, '00201223185749', '002', '01223185749', NULL, '3840', 1, 'Product Manager', 'Bey2ollak', '2015-08-09 09:34:23', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ana', NULL, 1, NULL, '2018-06-29 19:33:46', '2018-07-01 14:21:27', NULL),
(132, NULL, 'Attia', 'Gamea', NULL, 0, '00201019584283', '002', '01019584283', NULL, '0916', 1, 'Ddf', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Xggg', NULL, 3, NULL, '2018-06-29 19:36:59', '2018-06-29 21:05:37', NULL),
(133, NULL, 'sal', 'Mohamed', NULL, 0, '00201067672720', '002', '01067672720', NULL, '5464', 1, 'Project Manager', 'Worcbox', '2018-06-13 09:39:45', '2018-06-30 09:39:47', 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'bxnxnzycvubiiboh', NULL, 1, NULL, '2018-06-29 19:37:02', '2018-07-10 09:29:50', NULL),
(134, NULL, 'Mohamed', 'Salah', NULL, 0, '00966546628911', '00966', '546628911', NULL, '4205', 1, 'Biomedical engineer', NULL, NULL, NULL, 0, 966, 0, NULL, '2018-06-29 22:39:09', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Biomedical engineer service and  Application engineer at \nUltrasound and X-RAYS', NULL, 1, NULL, '2018-06-29 19:59:17', '2018-07-10 09:36:33', NULL),
(135, NULL, 'محمد', 'صلاح', NULL, 0, '00966546628944', '00966', '546628944', NULL, '1778', 1, 'مهندس كهرباء', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'عملت في مجال صيانة والتشغيل والتدريب للاجهزة الطبية \nخاصة مجال السونار والاشعة السينية', NULL, 3, NULL, '2018-06-29 20:01:46', '2018-06-29 20:04:29', NULL),
(136, NULL, 'Shady', 'helmy', NULL, 0, '00966565720839', '00966', '0565720839', '00966565720839', '2202', 1, 'mechanical engineer', 'park energy', '2017-02-01 01:36:27', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Male', 'mechanical engineer', NULL, 2, NULL, '2018-06-29 20:18:51', '2018-06-29 22:41:05', NULL),
(137, NULL, 'M', 'Abdulaziz- UAE', NULL, 0, '00971567711461', NULL, NULL, NULL, '1921', 0, 'System Engineer', NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'System Engineering', NULL, 3, NULL, '2018-07-02 19:59:07', '2018-07-03 20:59:27', NULL),
(138, NULL, NULL, NULL, NULL, 0, '00201067900332', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-07-09 20:51:17', '2018-07-09 20:51:17', NULL),
(139, NULL, NULL, NULL, NULL, 0, '0020106767272720', NULL, NULL, NULL, '4964', 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-07-09 21:27:59', '2018-07-09 21:28:00', NULL),
(140, NULL, NULL, NULL, NULL, 0, '00966546628941', NULL, NULL, NULL, '1248', 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-07-10 09:34:24', '2018-07-10 09:34:24', NULL),
(141, NULL, 'Mohammad', 'Abdulaziz', NULL, 0, '00966500176113', NULL, NULL, NULL, '5018', 1, 'System Engineer', 'BTC Networks', '2015-04-15 09:01:33', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'integration engineer', NULL, 1, NULL, '2018-07-10 18:57:59', '2018-07-10 19:01:52', NULL),
(142, NULL, NULL, NULL, NULL, 0, '0020456666888', NULL, NULL, NULL, '8900', 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-07-28 21:15:31', '2018-07-28 21:15:39', NULL),
(143, NULL, NULL, NULL, NULL, 0, '0020773185749', NULL, NULL, NULL, '3322', 0, NULL, NULL, NULL, NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, '2018-07-28 21:28:14', '2018-07-28 21:28:22', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `profile_token`
--

CREATE TABLE `profile_token` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile_id` int(11) NOT NULL DEFAULT '0',
  `token` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `device_type` tinyint(4) NOT NULL DEFAULT '1',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profile_token`
--

INSERT INTO `profile_token` (`id`, `profile_id`, `token`, `device_type`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(122, 131, 'crmHb_qyGdY:APA91bFrHpIKVcpmDpIz9boiyKkur4E8PTdvwZtnrb2BUeEDPuZGMAeSYwPOce5XzGR1deE4NrO1wOQKd9RlQe-QpZi4d6whk83gsUKEvxc0kj6mHTLQ6bjmHyzxMBMtjeLPsZjc4IACumpQ8y4yVQDqet0eKXkMgg', 1, 1, '2018-06-29 19:36:32', '2018-06-29 19:36:32', NULL),
(123, 132, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 0, '2018-06-29 19:38:30', '2018-06-29 19:38:30', NULL),
(124, 133, 'dDKQ9A1B3G4:APA91bEZLBBuNa0rDOjpHBBjpM0VO_q7gbXWUypwP7kfvvBdoVP0hiqmUcBqLw2gSxDiOi16JljUpubyhPkOUXpgdD0o50T9p0DE8z0WUrpkAnbIs8tOmEcV5bBWpRpcWEGYUfq499J5UkjicC_VQnpPhpYQg2nTqQ', 1, 0, '2018-06-29 19:40:04', '2018-06-29 19:40:04', NULL),
(125, 134, 'dDnM0ScS0Rw:APA91bFDe7aYCmdDMuGrYzfuZ8FsLhjS5efZdv8wExkuLnNkPNhHmSxKLMQuyOR5VYAcI-ZE53znMF6mRIMHiFo-mupC5jwMMuFOiD-97jPP7_QQJyYT29BPt6aYlt67Qk52URizoRB1NMgj4GUuGsFsocTtHJJSsQ', 1, 0, '2018-06-29 20:00:48', '2018-06-29 20:00:48', NULL),
(126, 135, 'dDnM0ScS0Rw:APA91bFDe7aYCmdDMuGrYzfuZ8FsLhjS5efZdv8wExkuLnNkPNhHmSxKLMQuyOR5VYAcI-ZE53znMF6mRIMHiFo-mupC5jwMMuFOiD-97jPP7_QQJyYT29BPt6aYlt67Qk52URizoRB1NMgj4GUuGsFsocTtHJJSsQ', 1, 1, '2018-06-29 20:04:30', '2018-06-29 20:04:30', NULL),
(127, 136, 'fxkpXi1K7gg:APA91bFzEUZ60pcBkR1wrJGC7Y1m9RTJob6KAKMlsyUeX1r8TmGNrY7zatfU5hmFSVLD2RcM_BYJMZ4ayNWcaEj5bOqrrD3A9xWMjiCycfBzI9wD3JCsRK2hrZMvutCmWn9QSWGAuB-cp205MUeXAK9cuMVJK-zSyg', 1, 0, '2018-06-29 20:18:52', '2018-06-29 20:18:52', NULL),
(128, 133, 'cuRdAsuM7ns:APA91bE2669XhOm0oIsfVeejSRg1BvZHJ2OaFB_ywNmrGAADfiFMKC0DYUPFy1dBsDjApZkvHomBVqEgX6LA8TwtQgTJdN7YS8V2lw5eD-X_LAKqz9s4UDTkairX_6UQ_12OS-8bvQTFO0_askwzJgDBW5Bp9OCpaw', 1, 0, '2018-06-29 21:28:29', '2018-06-29 21:28:29', NULL),
(129, 136, 'dE8hJ7RJLpA:APA91bGjv8HNM2HhXQqKmz6DAsy2Ti4Npni3seaDIZHY1gZ7gFDs1pXx_nKpartLaxg2dhxuVXMnR16QeEQj8uUiN-VpY4DRlVXNUnd82KPnk6jdttZa5xCqElGAMHJ-lkUxShGMcnHs5q2A77ebcRmF5WmTf1VGUg', 1, 1, '2018-06-29 22:36:49', '2018-06-29 22:36:49', NULL),
(130, 137, 'fCIvg2Vrp_o:APA91bHxzO_r5Ehm6-hG0wpQQFpoCvd7L0l7LyiOvbiqlJ30rdaq7wsniI8LaA16JVxfxLHsV39fnzJ_YMFr3Oa2Y1MDi2HRF4vLODJFYWZZ3sowFfpnNC1wtJUVL_q09nMQHr_fDin_zlal5l8ZkIsl1gFggbUyig', 1, 1, '2018-07-02 20:04:05', '2018-07-02 20:04:05', NULL),
(131, 132, 'crxwoUZF77U:APA91bHC8rldOi72pq1HE6IvdRf-gDJQ2PgaM7Qk7l98WB37O5OD2JgAV5CMPCK7FFIzfiFp6OoigEC7xit4nd1uH1oo4R1Z9M4KykuggKHZb7hrmYvaGVf7t3yXHGs0BBpO4yTOoh1E', 1, 0, '2018-07-09 09:39:05', '2018-07-09 09:39:05', NULL),
(132, 132, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 0, '2018-07-09 18:53:18', '2018-07-09 18:53:18', NULL),
(133, 133, 'e02fXN0oqxc:APA91bEYrTH1JzyWTITqra4WFBEqtqYycLMvpZ6W30l7aLTnjKYL3lyBBoNokPF0D9HKnvP17WK0s9t8YkMXoKvGo3q6xl1cskHDMILs5Ut2-KB6c7UVsFQapZYMDLEUlv2mcEcEZ9YKBTbLYfg5T6k1pAq5J2pvvA', 1, 0, '2018-07-09 20:52:42', '2018-07-09 20:52:42', NULL),
(134, 132, 'crxwoUZF77U:APA91bHC8rldOi72pq1HE6IvdRf-gDJQ2PgaM7Qk7l98WB37O5OD2JgAV5CMPCK7FFIzfiFp6OoigEC7xit4nd1uH1oo4R1Z9M4KykuggKHZb7hrmYvaGVf7t3yXHGs0BBpO4yTOoh1E', 1, 0, '2018-07-09 21:05:18', '2018-07-09 21:05:18', NULL),
(135, 132, 'cCGWEqroAm4:APA91bG3Jr-JRfmo8qeAEWmeoaA9zEpK7u-LSyAxepaIriScSoWmwlffU0bIGgORMSwDG5tYBIgNulRVvNTI1e7UTrmiBra-L15z3TnEHGsUV9PxqqN9APnAsFdnQjfEvHX6Z4uWelBr', 1, 1, '2018-07-09 21:06:04', '2018-07-09 21:06:04', NULL),
(136, 133, 'ffMfFUbL_k8:APA91bFB65Mt6kS-8vw8vX7K-m69eDKa1DH31mVbpX5WAcknsxqZh8rfNM_aFp2kaIW1harXUFCZggwSbDbhcibgGU9elVxPg5hD9E3rqK9XCkCgLwx2mZAuOsZZUwtq3E1F2UFgpifzYnXLn9xdes2twGCnMMzjqQ', 1, 0, '2018-07-09 22:36:12', '2018-07-09 22:36:12', NULL),
(137, 134, 'dYKCerEDPtU:APA91bFgRoqulXHmhgt0XodM3oOqCXPFvx_GJ-28XreG3YI7Rj1WSkDT2TVh0SZK7YDSd3-YTOjaAvNwgFhmTgkdASYg7vyWXJeCTX0y1zTi2Ar-zTVrwOXjDFRE-z3prxk135PpwkX8BIn8AuPIybm9aWSchvri5g', 1, 0, '2018-07-09 22:45:42', '2018-07-09 22:45:42', NULL),
(138, 133, 'co-XSP1TMEM:APA91bHngDauANjlTCAv0XuNrpf7C3nsnPZivxqzc_FZF368AX2UxBzJQmkfGo9-GWNt_qKuFLvXtCZdGEnM_Fsz9jHMkIeWEUTDf8gLEg0yANzvsliVigVu799uJ5vGfgZ5DrQ9H6JzFbg2tGlLcyU1EsrV8RGo-Q', 1, 0, '2018-07-10 08:06:29', '2018-07-10 08:06:29', NULL),
(139, 133, 'cRiddNKCt8E:APA91bGN-awr5CoDxX8FSHdkYfILitZfYXl4Lk2GSKnGIE8bJWubvQ-UsbfZHE5WGQikSO30Tl25L5eRE_JyvbldUkF8QqQgt1BaXi035a2mqvgUbd6IE7kh8Rxmhq7pZnRM54XgJfCQ4F_GKsPVu74rI81D1BmQvw', 1, 1, '2018-07-10 09:29:50', '2018-07-10 09:29:50', NULL),
(140, 134, 'e5hI_d24CEI:APA91bFYaOjnTMDAXWassqFG_Q1f2Rk8BQZdk1CYOM4xs-lWrOBcrOH2L8ZYgCuAVLZiLW0SYSCd50e0Bo3om-TdVIlFsefohP_OCFMF18FQudWMTE7fqxoB3M-SYZDcaNK2GPWWVhcfcMAfM-tOwTmoR-TBLhpO9A', 1, 1, '2018-07-10 09:36:34', '2018-07-10 09:36:34', NULL),
(141, 141, 'fCIvg2Vrp_o:APA91bHxzO_r5Ehm6-hG0wpQQFpoCvd7L0l7LyiOvbiqlJ30rdaq7wsniI8LaA16JVxfxLHsV39fnzJ_YMFr3Oa2Y1MDi2HRF4vLODJFYWZZ3sowFfpnNC1wtJUVL_q09nMQHr_fDin_zlal5l8ZkIsl1gFggbUyig', 1, 1, '2018-07-10 19:01:56', '2018-07-10 19:01:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `profile_transaction`
--

CREATE TABLE `profile_transaction` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile_id` int(11) NOT NULL,
  `transaction_type` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profile_transaction`
--

INSERT INTO `profile_transaction` (`id`, `profile_id`, `transaction_type`, `created_at`, `updated_at`, `deleted_at`) VALUES
(56, 136, 1, '2018-06-29 22:38:49', '2018-06-29 22:38:49', NULL),
(57, 134, 1, '2018-06-29 22:39:09', '2018-06-29 22:39:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `mobile`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(162, '00201223185749', '00201223185749@ijober.com', '00201223185749', '$2y$10$lIyFTfKcBtp/U7DNumMzJe/RmmQ9H5wHjUPnC5tB3/Pzn929qj8SO', NULL, '2018-06-29 19:33:46', '2018-06-29 19:33:46'),
(163, '00201019584283', '00201019584283@ijober.com', '00201019584283', '$2y$10$K1cPM7vPS6zIchGir2u1ZuAqY23.2w0Z2VanNsmCl13yfUirhuU82', NULL, '2018-06-29 19:37:00', '2018-06-29 19:37:00'),
(164, '00201067672720', '00201067672720@ijober.com', '00201067672720', '$2y$10$MXEKRIf/aopxdPtvZjkAle0SPdN3hzO35oC65VVyqRhJZY4oKt0Ai', NULL, '2018-06-29 19:37:02', '2018-06-29 19:37:02'),
(165, '00966546628911', '00966546628911@ijober.com', '00966546628911', '$2y$10$vLzAtIWrBVkbm0MbdEWXKuBKRraUUnrmnE1VrMvj1W93kBV1zSvae', NULL, '2018-06-29 19:59:17', '2018-07-03 19:40:09'),
(166, '00966546628944', '00966546628944@ijober.com', '00966546628944', '$2y$10$F.HznRv.WeQcBgoxCOYRaO0yT30FCFn5dk/7uDzSl36aULRq.U/L2', NULL, '2018-06-29 20:01:46', '2018-06-29 20:01:46'),
(167, '009660565720839', '009660565720839@ijober.com', '00966565720839', '$2y$10$3A0l0TTOq.AXXtUKd2XAE.DngAaJudM.9XLBZPtJWBr8lFMmF7umC', NULL, '2018-06-29 20:18:51', '2018-06-29 22:40:52'),
(168, '00971567711461', '00971567711461@ijober.com', '00971567711461', '$2y$10$Z6A1gfpQWK9jZDxQXWueCOZNN1O1IqrESTsMkxFWznxpOdIIHLPs.', NULL, '2018-07-02 19:59:07', '2018-07-02 19:59:07'),
(169, '00201067900332', '00201067900332@ijober.com', '00201067900332', '$2y$10$QUU3uGkBY4oAwyF6/Q06p.2mUvYHT/sv24uO.PQv6c6VXsDQ/Lcv6', NULL, '2018-07-09 20:51:19', '2018-07-09 20:51:19'),
(170, '0020106767272720', '0020106767272720@ijober.com', '0020106767272720', '$2y$10$QUQ9qWEQp8XKZXpaWzLhQuuPMT8hRTVl45T7t2AByqZDBXYbsc7Uu', NULL, '2018-07-09 21:27:59', '2018-07-09 21:27:59'),
(171, '00966546628941', '00966546628941@ijober.com', '00966546628941', '$2y$10$tYNtgr8z6aKKC2hNHMPdOOMeOxbJZdFeRMIAmYT8S.NQlV44wAVlu', NULL, '2018-07-10 09:34:24', '2018-07-10 09:34:24'),
(172, '00966500176113', '00966500176113@ijober.com', '00966500176113', '$2y$10$f/lLnrFYpvT/4U3SqolwxusZaVe/teqjL96idNzzaRZagBxoXF7Ty', NULL, '2018-07-10 18:58:01', '2018-07-10 18:58:01'),
(173, '0020456666888', '0020456666888@ijober.com', '0020456666888', '$2y$10$7fXvQfdg1sbCkDjQzY0Mf.GRfWyjCPZ9oeWlJzpXO5SxGmQ4ar48q', NULL, '2018-07-28 21:15:33', '2018-07-28 21:15:33'),
(174, '0020773185749', '0020773185749@ijober.com', '0020773185749', '$2y$10$UbwhY0E17imfypgEHMQUO.qD5j3NynQMXnmsOPYgOOwJMWce8J48e', NULL, '2018-07-28 21:28:16', '2018-07-28 21:28:16');

-- --------------------------------------------------------

--
-- Table structure for table `user_companies`
--

CREATE TABLE `user_companies` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `company_id` int(11) NOT NULL,
  `region_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `user_contacts`
--

CREATE TABLE `user_contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_contacts`
--

INSERT INTO `user_contacts` (`id`, `profile_id`, `user_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1425, 132, 131, '2018-06-29 19:38:52', '2018-06-29 19:38:52', NULL),
(1426, 132, 132, '2018-06-29 19:38:52', '2018-06-29 19:38:52', NULL),
(1437, 131, 132, '2018-06-29 19:40:21', '2018-06-29 19:40:21', NULL),
(1438, 131, 133, '2018-06-29 19:40:23', '2018-06-29 19:40:23', NULL),
(1510, 133, 132, '2018-06-30 14:06:53', '2018-06-30 14:06:53', NULL),
(1511, 133, 131, '2018-06-30 14:06:53', '2018-06-30 14:06:53', NULL),
(1512, 133, 136, '2018-06-30 14:06:53', '2018-06-30 14:06:53', NULL),
(1516, 137, 136, '2018-07-02 20:04:48', '2018-07-02 20:04:48', NULL),
(1517, 137, 137, '2018-07-02 20:04:49', '2018-07-02 20:04:49', NULL),
(1518, 137, 133, '2018-07-02 20:04:49', '2018-07-02 20:04:49', NULL),
(1617, 136, 134, '2018-07-04 20:17:51', '2018-07-04 20:17:51', NULL),
(1618, 136, 133, '2018-07-04 20:18:01', '2018-07-04 20:18:01', NULL),
(1619, 136, 134, '2018-07-04 20:18:13', '2018-07-04 20:18:13', NULL),
(1620, 136, 134, '2018-07-04 20:18:15', '2018-07-04 20:18:15', NULL),
(1630, 134, 133, '2018-08-01 11:35:26', '2018-08-01 11:35:26', NULL),
(1631, 134, 133, '2018-08-01 11:35:30', '2018-08-01 11:35:30', NULL),
(1632, 134, 133, '2018-08-01 11:35:31', '2018-08-01 11:35:31', NULL),
(1633, 134, 133, '2018-08-01 11:35:32', '2018-08-01 11:35:32', NULL),
(1634, 134, 133, '2018-08-01 11:35:34', '2018-08-01 11:35:34', NULL),
(1635, 134, 133, '2018-08-01 11:35:39', '2018-08-01 11:35:39', NULL),
(1636, 134, 133, '2018-08-01 11:35:40', '2018-08-01 11:35:40', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `work_experience`
--

CREATE TABLE `work_experience` (
  `id` int(10) UNSIGNED NOT NULL,
  `profile_id` int(11) NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `to` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `work_experience`
--

INSERT INTO `work_experience` (`id`, `profile_id`, `title`, `company_name`, `from`, `to`, `created_at`, `updated_at`, `deleted_at`) VALUES
(98, 131, 'Product Manager ', 'Bey2ollak ', '2015-08-09 09:34:23', '2018-06-29 19:36:31', '2018-06-29 19:36:31', '2018-06-29 19:36:31', NULL),
(100, 133, 'Project Manager', 'Worcbox', '2018-06-13 09:39:45', '2018-06-30 09:39:47', '2018-06-29 19:41:16', '2018-06-29 19:41:16', NULL),
(101, 141, 'System Engineer', 'BTC Networks', '2015-04-15 09:01:33', '2018-07-10 19:01:53', '2018-07-10 19:01:53', '2018-07-10 19:01:53', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `group_jobs`
--
ALTER TABLE `group_jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `group_users`
--
ALTER TABLE `group_users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs_appliers`
--
ALTER TABLE `jobs_appliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs_forwards`
--
ALTER TABLE `jobs_forwards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs_hidden`
--
ALTER TABLE `jobs_hidden`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_transaction`
--
ALTER TABLE `job_transaction`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `job_transaction_job_id_profile_id_unique` (`job_id`,`profile_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_token`
--
ALTER TABLE `profile_token`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile_transaction`
--
ALTER TABLE `profile_transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `user_companies`
--
ALTER TABLE `user_companies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_contacts`
--
ALTER TABLE `user_contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `work_experience`
--
ALTER TABLE `work_experience`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `group_jobs`
--
ALTER TABLE `group_jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `group_users`
--
ALTER TABLE `group_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=259;

--
-- AUTO_INCREMENT for table `jobs_appliers`
--
ALTER TABLE `jobs_appliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=112;

--
-- AUTO_INCREMENT for table `jobs_forwards`
--
ALTER TABLE `jobs_forwards`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `jobs_hidden`
--
ALTER TABLE `jobs_hidden`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `job_transaction`
--
ALTER TABLE `job_transaction`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=268;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=168;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=144;

--
-- AUTO_INCREMENT for table `profile_token`
--
ALTER TABLE `profile_token`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT for table `profile_transaction`
--
ALTER TABLE `profile_transaction`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;

--
-- AUTO_INCREMENT for table `user_companies`
--
ALTER TABLE `user_companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_contacts`
--
ALTER TABLE `user_contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1637;

--
-- AUTO_INCREMENT for table `work_experience`
--
ALTER TABLE `work_experience`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=102;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
